import { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, useNavigate } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { Toaster } from '@/components/ui/sonner';
import { cn } from '@/lib/utils';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { useAuth, getDashboardRoute, type UserRole } from '@/hooks/useAuth';

// Auth Pages
import Login from '@/pages/auth/Login';
import Register from '@/pages/auth/Register';
import Landing from '@/pages/Landing';

// Admin Dashboard Pages
import Dashboard from '@/pages/Dashboard';
import Properties from '@/pages/Properties';

// Users Pages
import Brokers from '@/pages/users/Brokers';
import Clients from '@/pages/users/Clients';
import Developers from '@/pages/users/Developers';

// Companies Pages
import Companies from '@/pages/companies/Companies';

// Deals Pages
import Deals from '@/pages/deals/Deals';

// Requests Pages
import ClientRequests from '@/pages/requests/ClientRequests';

// Commissions Pages
import Commissions from '@/pages/commissions/Commissions';

// Role-Based Dashboards
import BrokerDashboard from '@/pages/broker/BrokerDashboard';
import DeveloperDashboard from '@/pages/developer/DeveloperDashboard';
import OwnerDashboard from '@/pages/owner/OwnerDashboard';
import ClientDashboard from '@/pages/client/ClientDashboard';

// Broker Pages
import MyProperties from '@/pages/broker/MyProperties';
import AddProperty from '@/pages/broker/AddProperty';
import MyCommissions from '@/pages/broker/MyCommissions';
import BrokerClientRequests from '@/pages/broker/ClientRequests';

// Shared Pages
import Profile from '@/pages/Profile';

// Admin Settings
import Settings from '@/pages/admin/Settings';
import AddUser from '@/pages/admin/AddUser';
import UserPermissions from '@/pages/admin/UserPermissions';
import ClientAssignments from '@/pages/admin/ClientAssignments';

// Client Pages
import PropertySearch from '@/pages/client/PropertySearch';
import SubmitRequest from '@/pages/client/SubmitRequest';
import MyRequests from '@/pages/client/MyRequests';

// Placeholder pages for routes
function PlaceholderPage({ title, description }: { title: string; description?: string }) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
      <div className="w-20 h-20 rounded-2xl bg-emerald-100 flex items-center justify-center mb-6">
        <span className="text-4xl">🚧</span>
      </div>
      <h1 className="text-2xl font-bold text-slate-900 mb-2">{title}</h1>
      <p className="text-slate-500 max-w-md">
        {description || 'هذه الصفحة قيد التطوير، سيتم إطلاقها قريباً'}
      </p>
    </div>
  );
}

// Protected Route Component
function ProtectedRoute({ 
  children, 
  allowedRoles 
}: { 
  children: React.ReactNode; 
  allowedRoles?: UserRole[];
}) {
  const { isAuthenticated, isLoading, user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate('/login');
    }
    
    if (!isLoading && isAuthenticated && user && allowedRoles) {
      if (!allowedRoles.includes(user.role)) {
        // Redirect to appropriate dashboard
        navigate(getDashboardRoute(user.role));
      }
    }
  }, [isAuthenticated, isLoading, user, allowedRoles, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-16 h-16 rounded-xl bg-emerald-600 flex items-center justify-center animate-pulse">
          <span className="text-2xl font-bold text-white">إ</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return <>{children}</>;
}

// Admin Layout Component
function AdminLayout({ children }: { children: React.ReactNode }) {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar
        userRole={user?.role || 'super_admin'}
        isCollapsed={isSidebarCollapsed}
        onToggle={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        isMobileOpen={isMobileSidebarOpen}
        onMobileClose={() => setIsMobileSidebarOpen(false)}
      />
      <Header
        onMenuClick={() => setIsMobileSidebarOpen(true)}
        isSidebarCollapsed={isSidebarCollapsed}
      />
      <main
        className={cn(
          'transition-all duration-300 pt-16 min-h-screen',
          isSidebarCollapsed ? 'lg:mr-20' : 'lg:mr-72'
        )}
      >
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  );
}

// Broker Layout Component
function BrokerLayout({ children }: { children: React.ReactNode }) {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar
        userRole="broker"
        isCollapsed={isSidebarCollapsed}
        onToggle={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        isMobileOpen={isMobileSidebarOpen}
        onMobileClose={() => setIsMobileSidebarOpen(false)}
      />
      <Header
        onMenuClick={() => setIsMobileSidebarOpen(true)}
        isSidebarCollapsed={isSidebarCollapsed}
      />
      <main
        className={cn(
          'transition-all duration-300 pt-16 min-h-screen',
          isSidebarCollapsed ? 'lg:mr-20' : 'lg:mr-72'
        )}
      >
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  );
}

// Developer Layout Component
function DeveloperLayout({ children }: { children: React.ReactNode }) {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar
        userRole="developer"
        isCollapsed={isSidebarCollapsed}
        onToggle={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        isMobileOpen={isMobileSidebarOpen}
        onMobileClose={() => setIsMobileSidebarOpen(false)}
      />
      <Header
        onMenuClick={() => setIsMobileSidebarOpen(true)}
        isSidebarCollapsed={isSidebarCollapsed}
      />
      <main
        className={cn(
          'transition-all duration-300 pt-16 min-h-screen',
          isSidebarCollapsed ? 'lg:mr-20' : 'lg:mr-72'
        )}
      >
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  );
}

// Owner Layout Component
function OwnerLayout({ children }: { children: React.ReactNode }) {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar
        userRole="owner"
        isCollapsed={isSidebarCollapsed}
        onToggle={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        isMobileOpen={isMobileSidebarOpen}
        onMobileClose={() => setIsMobileSidebarOpen(false)}
      />
      <Header
        onMenuClick={() => setIsMobileSidebarOpen(true)}
        isSidebarCollapsed={isSidebarCollapsed}
      />
      <main
        className={cn(
          'transition-all duration-300 pt-16 min-h-screen',
          isSidebarCollapsed ? 'lg:mr-20' : 'lg:mr-72'
        )}
      >
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  );
}

// Client Layout (simpler header)
function ClientLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="fixed top-0 left-0 right-0 h-16 bg-white border-b border-slate-200 z-40">
        <div className="h-full px-4 flex items-center justify-between max-w-7xl mx-auto">
          <a href="/landing.html" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-emerald-600 flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
            </div>
            <span className="font-bold text-slate-900">إنابة المستقبل</span>
          </a>
          
          <nav className="hidden md:flex items-center gap-6">
            <a href="/properties-search" className="text-slate-600 hover:text-emerald-600">البحث</a>
            <a href="/my-requests" className="text-slate-600 hover:text-emerald-600">طلباتي</a>
            <a href="/submit-request" className="text-slate-600 hover:text-emerald-600">طلب عقار</a>
          </nav>
          
          <div className="flex items-center gap-2">
            <a href="/login" className="text-slate-600 hover:text-emerald-600">تسجيل الدخول</a>
            <a href="/register" className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700">
              حساب جديد
            </a>
          </div>
        </div>
      </header>

      <main className="pt-16 min-h-screen">
        {children}
      </main>
    </div>
  );
}

// Role-Based Dashboard Redirect
function DashboardRedirect() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated) {
        navigate('/login');
      } else if (user) {
        navigate(getDashboardRoute(user.role));
      }
    }
  }, [isAuthenticated, isLoading, user, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-16 h-16 rounded-xl bg-emerald-600 flex items-center justify-center animate-pulse">
        <span className="text-2xl font-bold text-white">إ</span>
      </div>
    </div>
  );
}

function App() {
  return (
    <HelmetProvider>
      <HashRouter>
        <Toaster position="top-center" richColors />
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          
          {/* Dashboard Redirect */}
          <Route path="/dashboard" element={<DashboardRedirect />} />
          
          {/* Admin Routes - Legacy paths (redirect to new paths) */}
          <Route
            path="/admin/dashboard"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Dashboard />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/properties"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Properties />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/users/brokers"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Brokers />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/users/clients"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Clients />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/users/developers"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Developers />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/companies"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Companies />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/deals"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Deals />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/commissions"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Commissions />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/requests"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <ClientRequests />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/profile"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Profile />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/settings"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Settings />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/users/add"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <AddUser />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/users/permissions"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <UserPermissions />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          
          {/* Admin Routes - Sidebar paths */}
          <Route
            path="/users"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Brokers />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/users/brokers"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Brokers />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/users/clients"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Clients />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/users/developers"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Developers />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/properties"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin', 'broker']}>
                <AdminLayout>
                  <Properties />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/properties/add"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin', 'broker']}>
                <AdminLayout>
                  <AddProperty />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/properties/pending"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="عقارات بانتظار الموافقة" description="قائمة بالعقارات التي تنتظر موافقة الإدارة" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/properties/featured"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="العقارات المميزة" description="قائمة بالعقارات المميزة على المنصة" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/companies"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Companies />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/deals"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin', 'broker']}>
                <AdminLayout>
                  <Deals />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/deals/pending"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="صفقات بانتظار الموافقة" description="قائمة بالصفقات التي تنتظر الموافقة" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/deals/completed"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin', 'broker']}>
                <AdminLayout>
                  <PlaceholderPage title="الصفقات المكتملة" description="قائمة بالصفقات المكتملة" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/commissions"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin', 'broker']}>
                <AdminLayout>
                  <Commissions />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/commissions/rules"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="قواعد العمولات" description="إدارة قواعد ونسب العمولات" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/commissions/settlements"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="تسويات العمولات" description="إدارة تسويات العمولات والمدفوعات" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/requests"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin', 'broker']}>
                <AdminLayout>
                  <ClientRequests />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/files"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin', 'broker']}>
                <AdminLayout>
                  <PlaceholderPage title="الملفات" description="إدارة الملفات والمستندات" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/ads"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="الإعلانات" description="إدارة الإعلانات والحملات التسويقية" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/reports"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="التقارير" description="لوحة تحكم التقارير والإحصائيات" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/reports/brokers"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="أداء الوسطاء" description="تقارير أداء الوسطاء" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/reports/deals"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="تقارير الصفقات" description="تقارير مفصلة عن الصفقات" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/reports/revenue"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="تقارير الإيرادات" description="تقارير الإيرادات والعمولات" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/corporate"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="الهوية المؤسسية" description="إدارة الهوية المؤسسية" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/corporate/certificates"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="الشهادات" description="شهادات الشركة والاعتمادات" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/corporate/licenses"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="التراخيص" description="تراخيص الشركة والتصاريح" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/corporate/partners"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="الشراكات" description="شركاء الشركة والتعاونات" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/corporate/achievements"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <PlaceholderPage title="الإنجازات" description="إنجازات الشركة والجوائز" />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/settings"
            element={
              <ProtectedRoute allowedRoles={['super_admin', 'admin']}>
                <AdminLayout>
                  <Settings />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          
          {/* Broker Routes */}
          <Route
            path="/broker/dashboard"
            element={
              <ProtectedRoute allowedRoles={['broker']}>
                <BrokerLayout>
                  <BrokerDashboard />
                </BrokerLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/broker/properties"
            element={
              <ProtectedRoute allowedRoles={['broker']}>
                <BrokerLayout>
                  <MyProperties />
                </BrokerLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/broker/properties/add"
            element={
              <ProtectedRoute allowedRoles={['broker']}>
                <BrokerLayout>
                  <AddProperty />
                </BrokerLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/broker/deals"
            element={
              <ProtectedRoute allowedRoles={['broker']}>
                <BrokerLayout>
                  <PlaceholderPage title="صفقاتي" />
                </BrokerLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/broker/commissions"
            element={
              <ProtectedRoute allowedRoles={['broker']}>
                <BrokerLayout>
                  <MyCommissions />
                </BrokerLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/broker/requests"
            element={
              <ProtectedRoute allowedRoles={['broker']}>
                <BrokerLayout>
                  <BrokerClientRequests />
                </BrokerLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/broker/profile"
            element={
              <ProtectedRoute allowedRoles={['broker']}>
                <BrokerLayout>
                  <Profile />
                </BrokerLayout>
              </ProtectedRoute>
            }
          />
          
          {/* Developer Routes */}
          <Route
            path="/developer/dashboard"
            element={
              <ProtectedRoute allowedRoles={['developer']}>
                <DeveloperLayout>
                  <DeveloperDashboard />
                </DeveloperLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/developer/projects"
            element={
              <ProtectedRoute allowedRoles={['developer']}>
                <DeveloperLayout>
                  <PlaceholderPage title="مشاريعي" />
                </DeveloperLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/developer/properties"
            element={
              <ProtectedRoute allowedRoles={['developer']}>
                <DeveloperLayout>
                  <PlaceholderPage title="وحداتي" />
                </DeveloperLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/developer/reports"
            element={
              <ProtectedRoute allowedRoles={['developer']}>
                <DeveloperLayout>
                  <PlaceholderPage title="تقاريري" />
                </DeveloperLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/developer/profile"
            element={
              <ProtectedRoute allowedRoles={['developer']}>
                <DeveloperLayout>
                  <Profile />
                </DeveloperLayout>
              </ProtectedRoute>
            }
          />
          
          {/* Owner Routes */}
          <Route
            path="/owner/dashboard"
            element={
              <ProtectedRoute allowedRoles={['owner']}>
                <OwnerLayout>
                  <OwnerDashboard />
                </OwnerLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/owner/properties"
            element={
              <ProtectedRoute allowedRoles={['owner']}>
                <OwnerLayout>
                  <PlaceholderPage title="عقاراتي" />
                </OwnerLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/owner/requests"
            element={
              <ProtectedRoute allowedRoles={['owner']}>
                <OwnerLayout>
                  <PlaceholderPage title="طلباتي" />
                </OwnerLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/owner/profile"
            element={
              <ProtectedRoute allowedRoles={['owner']}>
                <OwnerLayout>
                  <Profile />
                </OwnerLayout>
              </ProtectedRoute>
            }
          />
          
          {/* Client Routes */}
          <Route
            path="/client/dashboard"
            element={
              <ProtectedRoute allowedRoles={['client']}>
                <ClientLayout>
                  <ClientDashboard />
                </ClientLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/properties-search"
            element={
              <ClientLayout>
                <PropertySearch />
              </ClientLayout>
            }
          />
          <Route
            path="/submit-request"
            element={
              <ClientLayout>
                <SubmitRequest />
              </ClientLayout>
            }
          />
          <Route
            path="/my-requests"
            element={
              <ClientLayout>
                <MyRequests />
              </ClientLayout>
            }
          />
          <Route
            path="/client/profile"
            element={
              <ProtectedRoute allowedRoles={['client']}>
                <ClientLayout>
                  <Profile />
                </ClientLayout>
              </ProtectedRoute>
            }
          />
          
          {/* 404 Route */}
          <Route
            path="*"
            element={
              <div className="flex flex-col items-center justify-center min-h-screen text-center bg-slate-50">
                <div className="w-24 h-24 rounded-2xl bg-slate-100 flex items-center justify-center mb-6">
                  <span className="text-5xl">😕</span>
                </div>
                <h1 className="text-3xl font-bold text-slate-900 mb-2">404</h1>
                <p className="text-slate-500 mb-6">الصفحة غير موجودة</p>
                <a href="/" className="px-6 py-3 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors">
                  العودة للرئيسية
                </a>
              </div>
            }
          />
        </Routes>
      </HashRouter>
    </HelmetProvider>
  );
}

export default App;
