import { useState, useEffect, useCallback } from 'react';
import { users, currentUser } from '@/data/mockData';

export type UserRole = 'super_admin' | 'admin' | 'broker' | 'client' | 'developer' | 'owner';

export interface AuthUser {
  id: string;
  email: string;
  phone?: string;
  fullName: string;
  fullNameEn?: string;
  avatarUrl?: string;
  role: UserRole;
  companyId?: string;
  isActive: boolean;
  createdAt: string;
}

interface AuthState {
  user: AuthUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

// Permission definitions
export const PERMISSIONS = {
  // Dashboard
  VIEW_ADMIN_DASHBOARD: 'view_admin_dashboard',
  VIEW_BROKER_DASHBOARD: 'view_broker_dashboard',
  VIEW_DEVELOPER_DASHBOARD: 'view_developer_dashboard',
  VIEW_OWNER_DASHBOARD: 'view_owner_dashboard',
  VIEW_CLIENT_DASHBOARD: 'view_client_dashboard',
  
  // Properties
  VIEW_ALL_PROPERTIES: 'view_all_properties',
  VIEW_OWN_PROPERTIES: 'view_own_properties',
  VIEW_DEVELOPER_PROPERTIES: 'view_developer_properties',
  VIEW_COMPANY_PROPERTIES: 'view_company_properties',
  CREATE_PROPERTY: 'create_property',
  EDIT_PROPERTY: 'edit_property',
  DELETE_PROPERTY: 'delete_property',
  APPROVE_PROPERTY: 'approve_property',
  
  // Projects
  VIEW_ALL_PROJECTS: 'view_all_projects',
  VIEW_DEVELOPER_PROJECTS: 'view_developer_projects',
  CREATE_PROJECT: 'create_project',
  EDIT_PROJECT: 'edit_project',
  DELETE_PROJECT: 'delete_project',
  
  // Users
  VIEW_ALL_USERS: 'view_all_users',
  VIEW_BROKERS: 'view_brokers',
  VIEW_CLIENTS: 'view_clients',
  VIEW_DEVELOPERS: 'view_developers',
  CREATE_USER: 'create_user',
  EDIT_USER: 'edit_user',
  DELETE_USER: 'delete_user',
  
  // Companies
  VIEW_ALL_COMPANIES: 'view_all_companies',
  VIEW_OWN_COMPANY: 'view_own_company',
  CREATE_COMPANY: 'create_company',
  EDIT_COMPANY: 'edit_company',
  DELETE_COMPANY: 'delete_company',
  
  // Deals
  VIEW_ALL_DEALS: 'view_all_deals',
  VIEW_OWN_DEALS: 'view_own_deals',
  VIEW_DEVELOPER_DEALS: 'view_developer_deals',
  CREATE_DEAL: 'create_deal',
  EDIT_DEAL: 'edit_deal',
  APPROVE_DEAL: 'approve_deal',
  
  // Commissions
  VIEW_ALL_COMMISSIONS: 'view_all_commissions',
  VIEW_OWN_COMMISSIONS: 'view_own_commissions',
  PAY_COMMISSION: 'pay_commission',
  
  // Requests
  VIEW_ALL_REQUESTS: 'view_all_requests',
  VIEW_ASSIGNED_REQUESTS: 'view_assigned_requests',
  VIEW_OWN_REQUESTS: 'view_own_requests',
  ASSIGN_REQUEST: 'assign_request',
  
  // CRM
  VIEW_CRM: 'view_crm',
  MANAGE_CRM: 'manage_crm',
  
  // Reports
  VIEW_ALL_REPORTS: 'view_all_reports',
  VIEW_OWN_REPORTS: 'view_own_reports',
  VIEW_DEVELOPER_REPORTS: 'view_developer_reports',
  
  // Settings
  VIEW_SETTINGS: 'view_settings',
  MANAGE_SETTINGS: 'manage_settings',
} as const;

// Role-based permissions
const ROLE_PERMISSIONS: Record<UserRole, string[]> = {
  super_admin: Object.values(PERMISSIONS),
  
  admin: [
    PERMISSIONS.VIEW_ADMIN_DASHBOARD,
    PERMISSIONS.VIEW_ALL_PROPERTIES,
    PERMISSIONS.CREATE_PROPERTY,
    PERMISSIONS.EDIT_PROPERTY,
    PERMISSIONS.APPROVE_PROPERTY,
    PERMISSIONS.VIEW_ALL_PROJECTS,
    PERMISSIONS.CREATE_PROJECT,
    PERMISSIONS.EDIT_PROJECT,
    PERMISSIONS.VIEW_ALL_USERS,
    PERMISSIONS.VIEW_BROKERS,
    PERMISSIONS.VIEW_CLIENTS,
    PERMISSIONS.VIEW_DEVELOPERS,
    PERMISSIONS.CREATE_USER,
    PERMISSIONS.EDIT_USER,
    PERMISSIONS.VIEW_ALL_COMPANIES,
    PERMISSIONS.CREATE_COMPANY,
    PERMISSIONS.EDIT_COMPANY,
    PERMISSIONS.VIEW_ALL_DEALS,
    PERMISSIONS.CREATE_DEAL,
    PERMISSIONS.EDIT_DEAL,
    PERMISSIONS.APPROVE_DEAL,
    PERMISSIONS.VIEW_ALL_COMMISSIONS,
    PERMISSIONS.PAY_COMMISSION,
    PERMISSIONS.VIEW_ALL_REQUESTS,
    PERMISSIONS.ASSIGN_REQUEST,
    PERMISSIONS.VIEW_CRM,
    PERMISSIONS.MANAGE_CRM,
    PERMISSIONS.VIEW_ALL_REPORTS,
    PERMISSIONS.VIEW_SETTINGS,
  ],
  
  broker: [
    PERMISSIONS.VIEW_BROKER_DASHBOARD,
    PERMISSIONS.VIEW_OWN_PROPERTIES,
    PERMISSIONS.CREATE_PROPERTY,
    PERMISSIONS.EDIT_PROPERTY,
    PERMISSIONS.VIEW_OWN_DEALS,
    PERMISSIONS.CREATE_DEAL,
    PERMISSIONS.VIEW_OWN_COMMISSIONS,
    PERMISSIONS.VIEW_ASSIGNED_REQUESTS,
    PERMISSIONS.VIEW_OWN_REPORTS,
    PERMISSIONS.VIEW_SETTINGS,
  ],
  
  developer: [
    PERMISSIONS.VIEW_DEVELOPER_DASHBOARD,
    PERMISSIONS.VIEW_DEVELOPER_PROPERTIES,
    PERMISSIONS.CREATE_PROPERTY,
    PERMISSIONS.EDIT_PROPERTY,
    PERMISSIONS.VIEW_DEVELOPER_PROJECTS,
    PERMISSIONS.CREATE_PROJECT,
    PERMISSIONS.EDIT_PROJECT,
    PERMISSIONS.VIEW_DEVELOPER_DEALS,
    PERMISSIONS.VIEW_DEVELOPER_REPORTS,
    PERMISSIONS.VIEW_SETTINGS,
  ],
  
  owner: [
    PERMISSIONS.VIEW_OWNER_DASHBOARD,
    PERMISSIONS.VIEW_OWN_PROPERTIES,
    PERMISSIONS.CREATE_PROPERTY,
    PERMISSIONS.EDIT_PROPERTY,
    PERMISSIONS.VIEW_OWN_REPORTS,
    PERMISSIONS.VIEW_SETTINGS,
  ],
  
  client: [
    PERMISSIONS.VIEW_CLIENT_DASHBOARD,
    PERMISSIONS.VIEW_OWN_REQUESTS,
    PERMISSIONS.VIEW_SETTINGS,
  ],
};

export function useAuth() {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
  });

  // Load user from localStorage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('inabah_user');
    if (storedUser) {
      try {
        const user = JSON.parse(storedUser);
        setAuthState({
          user,
          isAuthenticated: true,
          isLoading: false,
        });
      } catch {
        localStorage.removeItem('inabah_user');
        setAuthState({
          user: null,
          isAuthenticated: false,
          isLoading: false,
        });
      }
    } else {
      setAuthState({
        user: null,
        isAuthenticated: false,
        isLoading: false,
      });
    }
  }, []);

  const login = useCallback((email: string, _password: string): boolean => {
    // Find user by email
    const user = users.find((u) => u.email === email);
    
    if (user && user.isActive) {
      const authUser: AuthUser = {
        id: user.id,
        email: user.email,
        phone: user.phone,
        fullName: user.fullName,
        fullNameEn: user.fullNameEn,
        avatarUrl: user.avatarUrl,
        role: user.role as UserRole,
        companyId: user.companyId,
        isActive: user.isActive,
        createdAt: user.createdAt,
      };
      
      localStorage.setItem('inabah_user', JSON.stringify(authUser));
      setAuthState({
        user: authUser,
        isAuthenticated: true,
        isLoading: false,
      });
      return true;
    }
    return false;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('inabah_user');
    setAuthState({
      user: null,
      isAuthenticated: false,
      isLoading: false,
    });
  }, []);

  const hasPermission = useCallback((permission: string): boolean => {
    if (!authState.user) return false;
    const userPermissions = ROLE_PERMISSIONS[authState.user.role] || [];
    return userPermissions.includes(permission);
  }, [authState.user]);

  const hasAnyPermission = useCallback((permissions: string[]): boolean => {
    return permissions.some((p) => hasPermission(p));
  }, [hasPermission]);

  const hasAllPermissions = useCallback((permissions: string[]): boolean => {
    return permissions.every((p) => hasPermission(p));
  }, [hasPermission]);

  // Quick login for demo
  const quickLogin = useCallback((role: UserRole) => {
    let user;
    switch (role) {
      case 'super_admin':
        user = users.find((u) => u.role === 'super_admin');
        break;
      case 'broker':
        user = users.find((u) => u.role === 'broker');
        break;
      case 'client':
        user = users.find((u) => u.role === 'client');
        break;
      case 'developer':
        user = users.find((u) => u.role === 'developer');
        break;
      default:
        user = currentUser;
    }

    if (user) {
      const authUser: AuthUser = {
        id: user.id,
        email: user.email,
        phone: user.phone,
        fullName: user.fullName,
        fullNameEn: user.fullNameEn,
        avatarUrl: user.avatarUrl,
        role: user.role as UserRole,
        companyId: user.companyId,
        isActive: user.isActive,
        createdAt: user.createdAt,
      };
      
      localStorage.setItem('inabah_user', JSON.stringify(authUser));
      setAuthState({
        user: authUser,
        isAuthenticated: true,
        isLoading: false,
      });
      return true;
    }
    return false;
  }, []);

  return {
    ...authState,
    login,
    logout,
    quickLogin,
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    permissions: authState.user ? ROLE_PERMISSIONS[authState.user.role] || [] : [],
  };
}

// Helper to get dashboard route based on role
export function getDashboardRoute(role: UserRole): string {
  switch (role) {
    case 'super_admin':
    case 'admin':
      return '/admin/dashboard';
    case 'broker':
      return '/broker/dashboard';
    case 'developer':
      return '/developer/dashboard';
    case 'owner':
      return '/owner/dashboard';
    case 'client':
      return '/client/dashboard';
    default:
      return '/admin/dashboard';
  }
}

// Helper to check if user can view property
export function canViewProperty(
  userRole: UserRole,
  userId: string,
  propertyListedBy: string,
  propertyCompanyId?: string,
  userCompanyId?: string
): boolean {
  switch (userRole) {
    case 'super_admin':
    case 'admin':
      return true;
    case 'broker':
      return propertyListedBy === userId;
    case 'developer':
      return propertyCompanyId === userCompanyId;
    case 'owner':
      return propertyListedBy === userId;
    case 'client':
      return true; // Clients can view all active properties
    default:
      return false;
  }
}

// Helper to check if user can edit property
export function canEditProperty(
  userRole: UserRole,
  userId: string,
  propertyListedBy: string,
  propertyCompanyId?: string,
  userCompanyId?: string
): boolean {
  switch (userRole) {
    case 'super_admin':
    case 'admin':
      return true;
    case 'broker':
      return propertyListedBy === userId;
    case 'developer':
      return propertyCompanyId === userCompanyId;
    case 'owner':
      return propertyListedBy === userId;
    default:
      return false;
  }
}
