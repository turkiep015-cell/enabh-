import { useState, useRef } from 'react';
import { Helmet } from 'react-helmet-async';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import {
  User,
  Mail,
  Phone,
  Camera,
  Lock,
  Bell,
  Shield,
  Globe,
  Moon,
  Smartphone,
  Building,
  MapPin,
  Edit,
  Save,
  X
} from 'lucide-react';
import { formatDate } from '@/lib/utils';

export default function Profile() {
  const { toast } = useToast();
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isEditing, setIsEditing] = useState(false);
  const [avatar, setAvatar] = useState(user?.avatarUrl || '');
  
  const [profileData, setProfileData] = useState({
    fullName: user?.fullName || '',
    email: user?.email || '',
    phone: user?.phone || '',
    bio: '',
    address: '',
  });

  const [securityData, setSecurityData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const [notifications, setNotifications] = useState({
    email: true,
    sms: false,
    push: true,
    deals: true,
    commissions: true,
    requests: true,
    marketing: false,
  });

  const [preferences, setPreferences] = useState({
    language: 'ar',
    darkMode: false,
    compactView: false,
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatar(reader.result as string);
        toast({
          title: 'تم تحديث الصورة',
          description: 'تم تحديث الصورة الشخصية بنجاح',
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = () => {
    toast({
      title: 'تم الحفظ',
      description: 'تم تحديث الملف الشخصي بنجاح',
    });
    setIsEditing(false);
  };

  const handleChangePassword = () => {
    if (securityData.newPassword !== securityData.confirmPassword) {
      toast({
        title: 'خطأ',
        description: 'كلمات المرور غير متطابقة',
        variant: 'destructive',
      });
      return;
    }
    
    toast({
      title: 'تم التغيير',
      description: 'تم تغيير كلمة المرور بنجاح',
    });
    setSecurityData({ currentPassword: '', newPassword: '', confirmPassword: '' });
  };

  const getRoleLabel = (role?: string) => {
    switch (role) {
      case 'super_admin': return 'مدير النظام';
      case 'admin': return 'مدير';
      case 'broker': return 'وسيط عقاري';
      case 'developer': return 'مطور عقاري';
      case 'owner': return 'مالك عقار';
      case 'client': return 'عميل';
      default: return 'مستخدم';
    }
  };

  const getRoleColor = (role?: string) => {
    switch (role) {
      case 'super_admin': return 'bg-purple-100 text-purple-700';
      case 'admin': return 'bg-blue-100 text-blue-700';
      case 'broker': return 'bg-emerald-100 text-emerald-700';
      case 'developer': return 'bg-amber-100 text-amber-700';
      case 'owner': return 'bg-rose-100 text-rose-700';
      case 'client': return 'bg-slate-100 text-slate-700';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  return (
    <>
      <Helmet>
        <title>الملف الشخصي | إنابة المستقبل</title>
      </Helmet>

      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">الملف الشخصي</h1>
            <p className="text-slate-500">إدارة معلوماتك الشخصية والإعدادات</p>
          </div>
        </div>

        {/* Profile Header Card */}
        <Card className="overflow-hidden">
          <div className="h-32 bg-gradient-to-r from-emerald-500 to-emerald-600" />
          <CardContent className="relative pt-0">
            <div className="flex flex-col md:flex-row md:items-end -mt-16 mb-6 gap-4">
              {/* Avatar */}
              <div className="relative">
                <div className="w-32 h-32 rounded-2xl border-4 border-white overflow-hidden bg-slate-100">
                  {avatar ? (
                    <img src={avatar} alt={profileData.fullName} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <User className="w-16 h-16 text-slate-400" />
                    </div>
                  )}
                </div>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute -bottom-2 -left-2 w-10 h-10 bg-emerald-600 text-white rounded-full flex items-center justify-center hover:bg-emerald-700 transition-colors shadow-lg"
                >
                  <Camera className="w-5 h-5" />
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>

              {/* Info */}
              <div className="flex-1 mb-2">
                <h2 className="text-2xl font-bold text-slate-900">{profileData.fullName}</h2>
                <div className="flex items-center gap-2 mt-1">
                  <Badge className={getRoleColor(user?.role)}>
                    {getRoleLabel(user?.role)}
                  </Badge>
                  <span className="text-slate-500 text-sm">•</span>
                  <span className="text-slate-500 text-sm">عضو منذ {formatDate(user?.createdAt || '')}</span>
                </div>
              </div>

              {/* Edit Button */}
              <Button
                variant={isEditing ? 'outline' : 'default'}
                onClick={() => isEditing ? setIsEditing(false) : setIsEditing(true)}
                className={!isEditing ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
              >
                {isEditing ? (
                  <>
                    <X className="w-4 h-4 ml-2" />
                    إلغاء
                  </>
                ) : (
                  <>
                    <Edit className="w-4 h-4 ml-2" />
                    تعديل
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="profile">
          <TabsList className="mb-4">
            <TabsTrigger value="profile">المعلومات الشخصية</TabsTrigger>
            <TabsTrigger value="security">الأمان</TabsTrigger>
            <TabsTrigger value="notifications">الإشعارات</TabsTrigger>
            <TabsTrigger value="preferences">التفضيلات</TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle>المعلومات الشخصية</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="fullName">الاسم الكامل</Label>
                    <div className="relative mt-1">
                      <User className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <Input
                        id="fullName"
                        value={profileData.fullName}
                        onChange={(e) => setProfileData({ ...profileData, fullName: e.target.value })}
                        disabled={!isEditing}
                        className="pr-10"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="email">البريد الإلكتروني</Label>
                    <div className="relative mt-1">
                      <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <Input
                        id="email"
                        type="email"
                        value={profileData.email}
                        onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                        disabled={!isEditing}
                        className="pr-10"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="phone">رقم الجوال</Label>
                    <div className="relative mt-1">
                      <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <Input
                        id="phone"
                        value={profileData.phone}
                        onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                        disabled={!isEditing}
                        className="pr-10"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="address">العنوان</Label>
                    <div className="relative mt-1">
                      <MapPin className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <Input
                        id="address"
                        value={profileData.address}
                        onChange={(e) => setProfileData({ ...profileData, address: e.target.value })}
                        disabled={!isEditing}
                        placeholder="المدينة، الحي"
                        className="pr-10"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="bio">نبذة عني</Label>
                  <textarea
                    id="bio"
                    value={profileData.bio}
                    onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
                    disabled={!isEditing}
                    placeholder="اكتب نبذة مختصرة عنك..."
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 min-h-[100px] disabled:bg-slate-50"
                  />
                </div>

                {isEditing && (
                  <div className="flex justify-end">
                    <Button 
                      onClick={handleSaveProfile}
                      className="bg-emerald-600 hover:bg-emerald-700"
                    >
                      <Save className="w-4 h-4 ml-2" />
                      حفظ التغييرات
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security">
            <Card>
              <CardHeader>
                <CardTitle>تغيير كلمة المرور</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="currentPassword">كلمة المرور الحالية</Label>
                  <div className="relative mt-1">
                    <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <Input
                      id="currentPassword"
                      type="password"
                      value={securityData.currentPassword}
                      onChange={(e) => setSecurityData({ ...securityData, currentPassword: e.target.value })}
                      className="pr-10"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="newPassword">كلمة المرور الجديدة</Label>
                  <div className="relative mt-1">
                    <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <Input
                      id="newPassword"
                      type="password"
                      value={securityData.newPassword}
                      onChange={(e) => setSecurityData({ ...securityData, newPassword: e.target.value })}
                      className="pr-10"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="confirmPassword">تأكيد كلمة المرور</Label>
                  <div className="relative mt-1">
                    <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <Input
                      id="confirmPassword"
                      type="password"
                      value={securityData.confirmPassword}
                      onChange={(e) => setSecurityData({ ...securityData, confirmPassword: e.target.value })}
                      className="pr-10"
                    />
                  </div>
                </div>

                <div className="pt-4">
                  <Button 
                    onClick={handleChangePassword}
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    <Lock className="w-4 h-4 ml-2" />
                    تغيير كلمة المرور
                  </Button>
                </div>

                <Separator />

                <div>
                  <h4 className="font-semibold mb-4">التحقق بخطوتين</h4>
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                        <Shield className="w-5 h-5 text-emerald-600" />
                      </div>
                      <div>
                        <p className="font-medium">تفعيل التحقق بخطوتين</p>
                        <p className="text-sm text-slate-500">زيادة الأمان بحماية إضافية</p>
                      </div>
                    </div>
                    <Switch />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>إعدادات الإشعارات</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h4 className="font-medium mb-4">قنوات الإشعارات</h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Mail className="w-5 h-5 text-slate-400" />
                        <div>
                          <p className="font-medium">البريد الإلكتروني</p>
                          <p className="text-sm text-slate-500">استلام الإشعارات عبر البريد</p>
                        </div>
                      </div>
                      <Switch
                        checked={notifications.email}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, email: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Smartphone className="w-5 h-5 text-slate-400" />
                        <div>
                          <p className="font-medium">الرسائل النصية</p>
                          <p className="text-sm text-slate-500">استلام الإشعارات عبر SMS</p>
                        </div>
                      </div>
                      <Switch
                        checked={notifications.sms}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, sms: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Bell className="w-5 h-5 text-slate-400" />
                        <div>
                          <p className="font-medium">الإشعارات الفورية</p>
                          <p className="text-sm text-slate-500">إشعارات منبثقة في المتصفح</p>
                        </div>
                      </div>
                      <Switch
                        checked={notifications.push}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, push: checked })}
                      />
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium mb-4">أنواع الإشعارات</h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">الصفقات</p>
                        <p className="text-sm text-slate-500">إشعارات حول الصفقات الجديدة</p>
                      </div>
                      <Switch
                        checked={notifications.deals}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, deals: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">العمولات</p>
                        <p className="text-sm text-slate-500">إشعارات دفع العمولات</p>
                      </div>
                      <Switch
                        checked={notifications.commissions}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, commissions: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">طلبات العملاء</p>
                        <p className="text-sm text-slate-500">إشعارات طلبات العملاء الجديدة</p>
                      </div>
                      <Switch
                        checked={notifications.requests}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, requests: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">العروض والتسويق</p>
                        <p className="text-sm text-slate-500">آخر العروض والأخبار</p>
                      </div>
                      <Switch
                        checked={notifications.marketing}
                        onCheckedChange={(checked) => setNotifications({ ...notifications, marketing: checked })}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Preferences Tab */}
          <TabsContent value="preferences">
            <Card>
              <CardHeader>
                <CardTitle>التفضيلات العامة</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h4 className="font-medium mb-4">اللغة</h4>
                  <div className="flex items-center gap-3">
                    <Globe className="w-5 h-5 text-slate-400" />
                    <select
                      value={preferences.language}
                      onChange={(e) => setPreferences({ ...preferences, language: e.target.value })}
                      className="flex-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="ar">العربية</option>
                      <option value="en">English</option>
                    </select>
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium mb-4">المظهر</h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Moon className="w-5 h-5 text-slate-400" />
                        <div>
                          <p className="font-medium">الوضع الداكن</p>
                          <p className="text-sm text-slate-500">تفعيل المظهر الداكن</p>
                        </div>
                      </div>
                      <Switch
                        checked={preferences.darkMode}
                        onCheckedChange={(checked) => setPreferences({ ...preferences, darkMode: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Building className="w-5 h-5 text-slate-400" />
                        <div>
                          <p className="font-medium">العرض المضغوط</p>
                          <p className="text-sm text-slate-500">عرض أكثر محتوى في الشاشة</p>
                        </div>
                      </div>
                      <Switch
                        checked={preferences.compactView}
                        onCheckedChange={(checked) => setPreferences({ ...preferences, compactView: checked })}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}
