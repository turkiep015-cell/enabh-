import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { NavLink } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { deals, users, properties } from '@/data/mockData';
import {
  Search,
  Plus,
  MoreVertical,
  Calendar,
  User,
  Home,
  DollarSign,
  CheckCircle2,
  Clock,
  XCircle,
  Eye,
  Edit,
  Trash2,
  Download,
  FileText,
} from 'lucide-react';

export default function Deals() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'completed' | 'cancelled'>('all');

  const filteredDeals = deals.filter((deal) => {
    const property = properties.find((p) => p.id === deal.propertyId);
    const matchesSearch =
      deal.dealNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      property?.titleAr.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'all' ? true : deal.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Get stats
  const pendingDeals = deals.filter((d) => d.status === 'pending').length;
  const completedDeals = deals.filter((d) => d.status === 'completed').length;
  const totalCommission = deals
    .filter((d) => d.status === 'completed')
    .reduce((sum, d) => sum + d.totalCommission, 0);

  const handleDelete = (_dealId: string) => {
    toast({
      title: 'تم الحذف',
      description: 'تم حذف الصفقة بنجاح',
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return (
          <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
            <CheckCircle2 className="w-3 h-3 ml-1" />
            مكتملة
          </Badge>
        );
      case 'approved':
        return (
          <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">
            <CheckCircle2 className="w-3 h-3 ml-1" />
            معتمدة
          </Badge>
        );
      case 'pending':
        return (
          <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">
            <Clock className="w-3 h-3 ml-1" />
            بانتظار الموافقة
          </Badge>
        );
      case 'cancelled':
        return (
          <Badge className="bg-red-100 text-red-700 hover:bg-red-100">
            <XCircle className="w-3 h-3 ml-1" />
            ملغاة
          </Badge>
        );
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getPropertyTitle = (propertyId: string) => {
    const property = properties.find((p) => p.id === propertyId);
    return property?.titleAr || 'عقار غير معروف';
  };

  const getAgentName = (agentId?: string) => {
    if (!agentId) return 'غير معين';
    const user = users.find((u) => u.id === agentId);
    return user?.fullName || 'غير معروف';
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <>
      <Helmet>
        <title>إدارة الصفقات | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">إدارة الصفقات</h1>
            <p className="text-slate-500 mt-1">متابعة وإدارة جميع الصفقات العقارية</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              تصدير
            </Button>
            <NavLink to="/deals/add">
              <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4" />
                صفقة جديدة
              </Button>
            </NavLink>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي الصفقات</p>
                  <p className="text-2xl font-bold text-slate-900">{deals.length}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">بانتظار الموافقة</p>
                  <p className="text-2xl font-bold text-amber-600">{pendingDeals}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">الصفقات المكتملة</p>
                  <p className="text-2xl font-bold text-emerald-600">{completedDeals}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي العمولات</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {(totalCommission / 1000000).toFixed(1)}M
                  </p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="البحث برقم الصفقة، اسم العقار..."
                  className="pr-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Tabs
                value={statusFilter}
                onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}
                className="w-full sm:w-auto"
              >
                <TabsList>
                  <TabsTrigger value="all">الكل</TabsTrigger>
                  <TabsTrigger value="pending">بانتظار</TabsTrigger>
                  <TabsTrigger value="approved">معتمدة</TabsTrigger>
                  <TabsTrigger value="completed">مكتملة</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Deals List */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">رقم الصفقة</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">العقار</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الوسيط</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">سعر البيع</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">العمولة</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">التاريخ</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الحالة</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredDeals.map((deal) => (
                    <tr key={deal.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-slate-400" />
                          <span className="font-medium text-slate-900">{deal.dealNumber}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <Home className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-700">{getPropertyTitle(deal.propertyId)}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-700">{getAgentName(deal.listingAgentId)}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <span className="font-medium text-slate-900">{formatCurrency(deal.salePrice)}</span>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <div className="flex flex-col items-center">
                          <span className="font-medium text-emerald-600">{formatCurrency(deal.totalCommission)}</span>
                          <span className="text-xs text-slate-500">{deal.commissionRate}%</span>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <Calendar className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-700">
                            {new Date(deal.createdAt).toLocaleDateString('ar-SA')}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">{getStatusBadge(deal.status)}</td>
                      <td className="px-4 py-4 text-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem asChild>
                              <NavLink to={`/deals/${deal.id}`}>
                                <Eye className="w-4 h-4 ml-2" />
                                عرض التفاصيل
                              </NavLink>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <NavLink to={`/deals/${deal.id}/edit`}>
                                <Edit className="w-4 h-4 ml-2" />
                                تعديل
                              </NavLink>
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleDelete(deal.id)}
                              className="text-red-600"
                            >
                              <Trash2 className="w-4 h-4 ml-2" />
                              حذف
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredDeals.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-2">لا توجد نتائج</h3>
                <p className="text-slate-500">لم يتم العثور على صفقة تطابق معايير البحث</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pagination */}
        {filteredDeals.length > 0 && (
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-500">
              عرض {filteredDeals.length} من {deals.length} صفقة
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>
                السابق
              </Button>
              <Button variant="outline" size="sm" disabled>
                التالي
              </Button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
