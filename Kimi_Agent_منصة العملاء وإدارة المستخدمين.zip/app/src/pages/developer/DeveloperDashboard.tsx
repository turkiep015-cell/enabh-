import { Helmet } from 'react-helmet-async';
import { NavLink } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/useAuth';
import { 
  properties, 
  deals, 
  projects,
  companies 
} from '@/data/mockData';
import {
  Home,
  TrendingUp,
  DollarSign,
  Building2,
  MapPin,
  Plus,
  Eye,
  ArrowUpRight,
  BarChart3,
  Phone,
  Mail,
} from 'lucide-react';

export default function DeveloperDashboard() {
  const { user } = useAuth();

  // Filter data for this developer only
  const developerProjects = projects.filter(p => p.developerId === user?.id);
  const developerProperties = properties.filter(p => 
    p.companyId === user?.companyId || p.listedBy === user?.id
  );
  const developerDeals = deals.filter(d => {
    const dealProperty = properties.find(p => p.id === d.propertyId);
    return dealProperty?.companyId === user?.companyId;
  });
  
  // Get developer's company
  const developerCompany = companies.find(c => c.id === user?.companyId);
  
  // Calculate stats
  const totalProjects = developerProjects.length;
  const activeProjects = developerProjects.filter(p => p.status === 'selling').length;
  const totalUnits = developerProperties.length;
  const availableUnits = developerProperties.filter(p => p.status === 'active').length;
  const reservedUnits = developerProperties.filter(p => p.status === 'reserved').length;
  const soldUnits = developerProperties.filter(p => p.status === 'sold').length;
  const totalSales = developerDeals
    .filter(d => d.status === 'completed')
    .reduce((sum, d) => sum + d.salePrice, 0);

  // Recent projects
  const recentProjects = developerProjects
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 3);

  const getProjectStatusBadge = (status: string) => {
    switch (status) {
      case 'selling':
        return <Badge className="bg-emerald-100 text-emerald-700">قيد البيع</Badge>;
      case 'completed':
        return <Badge className="bg-blue-100 text-blue-700">مكتمل</Badge>;
      case 'closed':
        return <Badge className="bg-slate-100 text-slate-600">مغلق</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <>
      <Helmet>
        <title>لوحة تحكم المطور | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Welcome Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              مرحباً، {user?.fullName}
            </h1>
            <p className="text-slate-500 mt-1">
              {developerCompany?.name || 'مطور عقاري'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <NavLink to="/developer/projects/add">
              <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4" />
                مشروع جديد
              </Button>
            </NavLink>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">مشاريعي</p>
                  <p className="text-2xl font-bold text-slate-900">{totalProjects}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-blue-600" />
                </div>
              </div>
              <p className="text-xs text-slate-400 mt-2">
                {activeProjects} قيد البيع
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي الوحدات</p>
                  <p className="text-2xl font-bold text-emerald-600">{totalUnits}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <Home className="w-5 h-5 text-emerald-600" />
                </div>
              </div>
              <p className="text-xs text-slate-400 mt-2">
                {availableUnits} متاح | {reservedUnits} محجوز | {soldUnits} مباع
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي المبيعات</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {(totalSales / 1000000).toFixed(1)}M
                  </p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-purple-600" />
                </div>
              </div>
              <p className="text-xs text-slate-400 mt-2">
                ريال سعودي
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">نسبة البيع</p>
                  <p className="text-2xl font-bold text-amber-600">
                    {totalUnits > 0 ? Math.round((soldUnits / totalUnits) * 100) : 0}%
                  </p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-amber-600" />
                </div>
              </div>
              <p className="text-xs text-slate-400 mt-2">
                {soldUnits} وحدة مباعة
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Projects */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-semibold">مشاريعي</CardTitle>
              <NavLink to="/developer/projects">
                <Button variant="ghost" size="sm" className="gap-1">
                  عرض الكل
                  <ArrowUpRight className="w-4 h-4" />
                </Button>
              </NavLink>
            </CardHeader>
            <CardContent>
              {recentProjects.length > 0 ? (
                <div className="space-y-4">
                  {recentProjects.map((project) => (
                    <div 
                      key={project.id} 
                      className="p-4 rounded-lg border border-slate-100 hover:border-emerald-200 hover:bg-emerald-50/30 transition-all"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex gap-4">
                          <div className="w-20 h-20 rounded-lg bg-slate-100 flex items-center justify-center flex-shrink-0 overflow-hidden">
                            {project.images?.[0] ? (
                              <img 
                                src={project.images[0]} 
                                alt={project.name}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <Building2 className="w-8 h-8 text-slate-400" />
                            )}
                          </div>
                          <div>
                            <h3 className="font-semibold text-slate-900">{project.name}</h3>
                            <div className="flex items-center gap-1 text-sm text-slate-500 mt-1">
                              <MapPin className="w-4 h-4" />
                              {project.city?.nameAr}
                            </div>
                            <div className="flex items-center gap-4 mt-2">
                              {getProjectStatusBadge(project.status)}
                              <span className="text-sm text-slate-500">
                                {properties.filter(p => p.projectId === project.id).length} وحدة
                              </span>
                            </div>
                          </div>
                        </div>
                        <NavLink to={`/developer/projects/${project.id}`}>
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </NavLink>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Building2 className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500">لا توجد مشاريع مسجلة</p>
                  <NavLink to="/developer/projects/add">
                    <Button className="mt-3 gap-2 bg-emerald-600 hover:bg-emerald-700">
                      <Plus className="w-4 h-4" />
                      إضافة مشروع
                    </Button>
                  </NavLink>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Stats & Actions */}
          <div className="space-y-6">
            {/* Units Status */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold">حالة الوحدات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                      <span className="text-sm">متاح</span>
                    </div>
                    <span className="font-semibold">{availableUnits}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                      <span className="text-sm">محجوز</span>
                    </div>
                    <span className="font-semibold">{reservedUnits}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                      <span className="text-sm">مباع</span>
                    </div>
                    <span className="font-semibold">{soldUnits}</span>
                  </div>
                </div>
                
                <div className="mt-4 pt-4 border-t border-slate-100">
                  <div className="h-2 bg-slate-100 rounded-full overflow-hidden flex">
                    <div 
                      className="bg-emerald-500" 
                      style={{ width: `${totalUnits ? (availableUnits / totalUnits) * 100 : 0}%` }}
                    ></div>
                    <div 
                      className="bg-amber-500" 
                      style={{ width: `${totalUnits ? (reservedUnits / totalUnits) * 100 : 0}%` }}
                    ></div>
                    <div 
                      className="bg-blue-500" 
                      style={{ width: `${totalUnits ? (soldUnits / totalUnits) * 100 : 0}%` }}
                    ></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold">إجراءات سريعة</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <NavLink to="/developer/projects/add">
                  <Button variant="outline" className="w-full justify-start gap-2">
                    <Plus className="w-4 h-4" />
                    مشروع جديد
                  </Button>
                </NavLink>
                <NavLink to="/developer/properties/add">
                  <Button variant="outline" className="w-full justify-start gap-2">
                    <Home className="w-4 h-4" />
                    إضافة وحدة
                  </Button>
                </NavLink>
                <NavLink to="/developer/reports">
                  <Button variant="outline" className="w-full justify-start gap-2">
                    <BarChart3 className="w-4 h-4" />
                    تقارير المبيعات
                  </Button>
                </NavLink>
              </CardContent>
            </Card>

            {/* Company Info */}
            {developerCompany && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-semibold">بيانات الشركة</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-slate-400" />
                    <span>{developerCompany.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-slate-400" />
                    <span className="ltr">{developerCompany.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <span>{developerCompany.email}</span>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
