import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { NavLink } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { companies, users, properties } from '@/data/mockData';
import {
  Search,
  Plus,
  MoreVertical,
  Phone,
  Mail,
  Building2,
  Users,
  Home,
  CheckCircle2,
  XCircle,
  Eye,
  Edit,
  Trash2,
  Download,
  MapPin,
} from 'lucide-react';

export default function Companies() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'developer' | 'brokerage'>('all');
  const [statusFilter] = useState<'all' | 'active' | 'inactive'>('all');

  const filteredCompanies = companies.filter((company) => {
    const matchesSearch =
      company.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      company.crNumber?.includes(searchQuery) ||
      company.licenseNumber?.includes(searchQuery);

    const matchesType = typeFilter === 'all' ? true : company.type === typeFilter;
    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'active'
        ? company.status === 'active'
        : company.status !== 'active';

    return matchesSearch && matchesType && matchesStatus;
  });

  // Get company stats
  const getCompanyUsersCount = (companyId: string) => {
    return users.filter((u) => u.companyId === companyId).length;
  };

  const getCompanyPropertiesCount = (companyId: string) => {
    return properties.filter((p) => p.companyId === companyId).length;
  };

  const activeCompanies = companies.filter((c) => c.status === 'active').length;
  const developerCompanies = companies.filter((c) => c.type === 'developer').length;
  const brokerageCompanies = companies.filter((c) => c.type === 'brokerage').length;

  const handleDelete = (_companyId: string) => {
    toast({
      title: 'تم الحذف',
      description: 'تم حذف الشركة بنجاح',
    });
  };

  const handleToggleStatus = (company: typeof companies[0]) => {
    toast({
      title: company.status === 'active' ? 'تم التعطيل' : 'تم التفعيل',
      description: `${company.name} ${company.status === 'active' ? 'تم تعطيلها' : 'تم تفعيلها'}`,
    });
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .slice(0, 2);
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'developer':
        return 'مطور عقاري';
      case 'brokerage':
        return 'وساطة عقارية';
      default:
        return type;
    }
  };

  return (
    <>
      <Helmet>
        <title>إدارة الشركات | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">إدارة الشركات</h1>
            <p className="text-slate-500 mt-1">إدارة الشركات والمؤسسات العقارية المسجلة</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              تصدير
            </Button>
            <NavLink to="/companies/add">
              <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4" />
                إضافة شركة
              </Button>
            </NavLink>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي الشركات</p>
                  <p className="text-2xl font-bold text-slate-900">{companies.length}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">الشركات النشطة</p>
                  <p className="text-2xl font-bold text-emerald-600">{activeCompanies}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">مطورين عقاريين</p>
                  <p className="text-2xl font-bold text-amber-600">{developerCompanies}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">وساطات عقارية</p>
                  <p className="text-2xl font-bold text-purple-600">{brokerageCompanies}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                  <Users className="w-5 h-5 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="البحث باسم الشركة، السجل التجاري، رقم الترخيص..."
                  className="pr-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Tabs
                value={typeFilter}
                onValueChange={(v) => setTypeFilter(v as typeof typeFilter)}
                className="w-full sm:w-auto"
              >
                <TabsList>
                  <TabsTrigger value="all">الكل</TabsTrigger>
                  <TabsTrigger value="developer">مطور</TabsTrigger>
                  <TabsTrigger value="brokerage">وساطة</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Companies List */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الشركة</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">النوع</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">التواصل</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الموظفين</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">العقارات</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الحالة</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredCompanies.map((company) => {
                    const usersCount = getCompanyUsersCount(company.id);
                    const propertiesCount = getCompanyPropertiesCount(company.id);

                    return (
                      <tr key={company.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-3">
                            <Avatar className="w-10 h-10">
                              <AvatarImage src={company.logoUrl} alt={company.name} />
                              <AvatarFallback className="bg-blue-100 text-blue-700">
                                {getInitials(company.name)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium text-slate-900">{company.name}</p>
                              <p className="text-sm text-slate-500">س.ت: {company.crNumber}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <Badge
                            variant="secondary"
                            className={
                              company.type === 'developer'
                                ? 'bg-amber-100 text-amber-700'
                                : 'bg-purple-100 text-purple-700'
                            }
                          >
                            {getTypeLabel(company.type)}
                          </Badge>
                        </td>
                        <td className="px-4 py-4">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <Phone className="w-4 h-4 text-slate-400" />
                              <span className="text-sm text-slate-700 ltr">{company.phone}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Mail className="w-4 h-4 text-slate-400" />
                              <span className="text-sm text-slate-700">{company.email}</span>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <div className="flex items-center justify-center gap-2">
                            <Users className="w-4 h-4 text-slate-400" />
                            <span className="font-medium text-slate-900">{usersCount}</span>
                          </div>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <div className="flex items-center justify-center gap-2">
                            <Home className="w-4 h-4 text-slate-400" />
                            <span className="font-medium text-slate-900">{propertiesCount}</span>
                          </div>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <Badge
                            variant={company.status === 'active' ? 'default' : 'secondary'}
                            className={
                              company.status === 'active'
                                ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-100'
                            }
                          >
                            {company.status === 'active' ? 'نشطة' : 'غير نشطة'}
                          </Badge>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreVertical className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem asChild>
                                <NavLink to={`/companies/${company.id}`}>
                                  <Eye className="w-4 h-4 ml-2" />
                                  عرض التفاصيل
                                </NavLink>
                              </DropdownMenuItem>
                              <DropdownMenuItem asChild>
                                <NavLink to={`/companies/${company.id}/edit`}>
                                  <Edit className="w-4 h-4 ml-2" />
                                  تعديل
                                </NavLink>
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleToggleStatus(company)}>
                                {company.status === 'active' ? (
                                  <>
                                    <XCircle className="w-4 h-4 ml-2" />
                                    تعطيل
                                  </>
                                ) : (
                                  <>
                                    <CheckCircle2 className="w-4 h-4 ml-2" />
                                    تفعيل
                                  </>
                                )}
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => handleDelete(company.id)}
                                className="text-red-600"
                              >
                                <Trash2 className="w-4 h-4 ml-2" />
                                حذف
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {filteredCompanies.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-2">لا توجد نتائج</h3>
                <p className="text-slate-500">لم يتم العثور على شركة تطابق معايير البحث</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pagination */}
        {filteredCompanies.length > 0 && (
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-500">
              عرض {filteredCompanies.length} من {companies.length} شركة
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>
                السابق
              </Button>
              <Button variant="outline" size="sm" disabled>
                التالي
              </Button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
