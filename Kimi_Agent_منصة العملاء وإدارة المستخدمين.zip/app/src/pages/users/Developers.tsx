import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { NavLink } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { users, companies, properties } from '@/data/mockData';
import {
  Search,
  Plus,
  MoreVertical,
  Phone,
  Building2,
  Home,
  Star,
  UserCheck,
  UserX,
  Eye,
  Edit,
  Trash2,
  Download,
  MapPin,
} from 'lucide-react';

interface DeveloperStats {
  projectsCount: number;
  unitsCount: number;
  totalSales: number;
  rating: number;
}

const developerStats: Record<string, DeveloperStats> = {
  '5': { projectsCount: 8, unitsCount: 245, totalSales: 125000000, rating: 4.7 },
};

export default function Developers() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');

  // Filter developers
  const developers = users.filter((user) => user.role === 'developer');

  const filteredDevelopers = developers.filter((developer) => {
    const matchesSearch =
      developer.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      developer.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (developer.phone?.includes(searchQuery) ?? false);

    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'active'
        ? developer.isActive
        : !developer.isActive;

    return matchesSearch && matchesStatus;
  });

  // Get developer properties count
  const getDeveloperPropertiesCount = (developerId: string) => {
    return properties.filter((p) => p.listedBy === developerId).length;
  };

  const activeDevelopers = developers.filter((d) => d.isActive).length;
  const totalProjects = Object.values(developerStats).reduce((sum, s) => sum + s.projectsCount, 0);
  const totalUnits = Object.values(developerStats).reduce((sum, s) => sum + s.unitsCount, 0);

  const handleDelete = (_developerId: string) => {
    toast({
      title: 'تم الحذف',
      description: 'تم حذف المطور بنجاح',
    });
  };

  const handleToggleStatus = (developer: typeof developers[0]) => {
    toast({
      title: developer.isActive ? 'تم التعطيل' : 'تم التفعيل',
      description: `${developer.fullName} ${developer.isActive ? 'تم تعطيل حسابه' : 'تم تفعيل حسابه'}`,
    });
  };

  const getCompanyName = (companyId?: string) => {
    if (!companyId) return 'غير مرتبط بشركة';
    const company = companies.find((c) => c.id === companyId);
    return company?.name || 'غير معروف';
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .slice(0, 2);
  };

  return (
    <>
      <Helmet>
        <title>المطورين العقاريين | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">المطورين العقاريين</h1>
            <p className="text-slate-500 mt-1">إدارة المطورين العقاريين المسجلين في المنصة</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              تصدير
            </Button>
            <NavLink to="/users/developers/add">
              <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4" />
                إضافة مطور
              </Button>
            </NavLink>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي المطورين</p>
                  <p className="text-2xl font-bold text-slate-900">{developers.length}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">المطورين النشطين</p>
                  <p className="text-2xl font-bold text-emerald-600">{activeDevelopers}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <UserCheck className="w-5 h-5 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي المشاريع</p>
                  <p className="text-2xl font-bold text-amber-600">{totalProjects}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي الوحدات</p>
                  <p className="text-2xl font-bold text-purple-600">{totalUnits}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                  <Home className="w-5 h-5 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="البحث باسم المطور، البريد الإلكتروني، رقم الجوال..."
                  className="pr-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Tabs
                value={statusFilter}
                onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}
                className="w-full sm:w-auto"
              >
                <TabsList>
                  <TabsTrigger value="all">الكل</TabsTrigger>
                  <TabsTrigger value="active">نشط</TabsTrigger>
                  <TabsTrigger value="inactive">غير نشط</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Developers List */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">المطور</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الشركة</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">التواصل</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">المشاريع</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">العقارات</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">التقييم</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الحالة</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredDevelopers.map((developer) => {
                    const stats = developerStats[developer.id] || {
                      projectsCount: 0,
                      unitsCount: 0,
                      totalSales: 0,
                      rating: 0,
                    };
                    const propertiesCount = getDeveloperPropertiesCount(developer.id);

                    return (
                      <tr key={developer.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-3">
                            <Avatar className="w-10 h-10">
                              <AvatarImage src={developer.avatarUrl} alt={developer.fullName} />
                              <AvatarFallback className="bg-amber-100 text-amber-700">
                                {getInitials(developer.fullName)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium text-slate-900">{developer.fullName}</p>
                              <p className="text-sm text-slate-500">{developer.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-2">
                            <Building2 className="w-4 h-4 text-slate-400" />
                            <span className="text-sm text-slate-700">
                              {getCompanyName(developer.companyId)}
                            </span>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-2">
                            <Phone className="w-4 h-4 text-slate-400" />
                            <span className="text-sm text-slate-700 ltr">{developer.phone || '-'}</span>
                          </div>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <span className="font-medium text-slate-900">{stats.projectsCount}</span>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                            {propertiesCount} عقار
                          </Badge>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                            <span className="font-medium text-slate-900">{stats.rating}</span>
                          </div>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <Badge
                            variant={developer.isActive ? 'default' : 'secondary'}
                            className={
                              developer.isActive
                                ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-100'
                            }
                          >
                            {developer.isActive ? 'نشط' : 'غير نشط'}
                          </Badge>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreVertical className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem asChild>
                                <NavLink to={`/users/developers/${developer.id}`}>
                                  <Eye className="w-4 h-4 ml-2" />
                                  عرض التفاصيل
                                </NavLink>
                              </DropdownMenuItem>
                              <DropdownMenuItem asChild>
                                <NavLink to={`/users/developers/${developer.id}/edit`}>
                                  <Edit className="w-4 h-4 ml-2" />
                                  تعديل
                                </NavLink>
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleToggleStatus(developer)}>
                                {developer.isActive ? (
                                  <>
                                    <UserX className="w-4 h-4 ml-2" />
                                    تعطيل الحساب
                                  </>
                                ) : (
                                  <>
                                    <UserCheck className="w-4 h-4 ml-2" />
                                    تفعيل الحساب
                                  </>
                                )}
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => handleDelete(developer.id)}
                                className="text-red-600"
                              >
                                <Trash2 className="w-4 h-4 ml-2" />
                                حذف
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {filteredDevelopers.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-2">لا توجد نتائج</h3>
                <p className="text-slate-500">لم يتم العثور على مطور يطابق معايير البحث</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pagination */}
        {filteredDevelopers.length > 0 && (
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-500">
              عرض {filteredDevelopers.length} من {developers.length} مطور
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>
                السابق
              </Button>
              <Button variant="outline" size="sm" disabled>
                التالي
              </Button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
