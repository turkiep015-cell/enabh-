import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { NavLink } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { users, companies } from '@/data/mockData';
import {
  Search,
  Plus,
  MoreVertical,
  Phone,
  Building2,
  Star,
  TrendingUp,
  UserCheck,
  UserX,
  Eye,
  Edit,
  Trash2,
  Download,
} from 'lucide-react';

interface BrokerStats {
  dealsCount: number;
  listingsCount: number;
  totalCommission: number;
  rating: number;
}

const brokerStats: Record<string, BrokerStats> = {
  '2': { dealsCount: 18, listingsCount: 45, totalCommission: 463000, rating: 4.8 },
  '3': { dealsCount: 12, listingsCount: 32, totalCommission: 285000, rating: 4.5 },
};

export default function Brokers() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');

  // Filter brokers
  const brokers = users.filter((user) => user.role === 'broker');

  const filteredBrokers = brokers.filter((broker) => {
    const matchesSearch =
      broker.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      broker.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (broker.phone?.includes(searchQuery) ?? false);

    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'active'
        ? broker.isActive
        : !broker.isActive;

    return matchesSearch && matchesStatus;
  });

  const activeBrokers = brokers.filter((b) => b.isActive).length;
  const totalDeals = Object.values(brokerStats).reduce((sum, s) => sum + s.dealsCount, 0);
  const totalListings = Object.values(brokerStats).reduce((sum, s) => sum + s.listingsCount, 0);

  const handleDelete = (_brokerId: string) => {
    toast({
      title: 'تم الحذف',
      description: 'تم حذف الوسيط بنجاح',
    });
  };

  const handleToggleStatus = (broker: typeof brokers[0]) => {
    toast({
      title: broker.isActive ? 'تم التعطيل' : 'تم التفعيل',
      description: `${broker.fullName} ${broker.isActive ? 'تم تعطيل حسابه' : 'تم تفعيل حسابه'}`,
    });
  };

  const getCompanyName = (companyId?: string) => {
    if (!companyId) return 'غير مرتبط بشركة';
    const company = companies.find((c) => c.id === companyId);
    return company?.name || 'غير معروف';
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .slice(0, 2);
  };

  return (
    <>
      <Helmet>
        <title>الوسطاء العقاريين | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">الوسطاء العقاريين</h1>
            <p className="text-slate-500 mt-1">إدارة الوسطاء العقاريين المسجلين في المنصة</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              تصدير
            </Button>
            <NavLink to="/users/brokers/add">
              <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4" />
                إضافة وسيط
              </Button>
            </NavLink>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي الوسطاء</p>
                  <p className="text-2xl font-bold text-slate-900">{brokers.length}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">الوسطاء النشطين</p>
                  <p className="text-2xl font-bold text-emerald-600">{activeBrokers}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <UserCheck className="w-5 h-5 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي الصفقات</p>
                  <p className="text-2xl font-bold text-slate-900">{totalDeals}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي الإدراجات</p>
                  <p className="text-2xl font-bold text-slate-900">{totalListings}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                  <Star className="w-5 h-5 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="البحث باسم الوسيط، البريد الإلكتروني، رقم الجوال..."
                  className="pr-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Tabs
                value={statusFilter}
                onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}
                className="w-full sm:w-auto"
              >
                <TabsList>
                  <TabsTrigger value="all">الكل</TabsTrigger>
                  <TabsTrigger value="active">نشط</TabsTrigger>
                  <TabsTrigger value="inactive">غير نشط</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Brokers List */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الوسيط</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">الشركة</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">التواصل</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الصفقات</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الإدراجات</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">التقييم</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الحالة</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredBrokers.map((broker) => {
                    const stats = brokerStats[broker.id] || {
                      dealsCount: 0,
                      listingsCount: 0,
                      totalCommission: 0,
                      rating: 0,
                    };

                    return (
                      <tr key={broker.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-3">
                            <Avatar className="w-10 h-10">
                              <AvatarImage src={broker.avatarUrl} alt={broker.fullName} />
                              <AvatarFallback className="bg-emerald-100 text-emerald-700">
                                {getInitials(broker.fullName)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium text-slate-900">{broker.fullName}</p>
                              <p className="text-sm text-slate-500">{broker.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-2">
                            <Building2 className="w-4 h-4 text-slate-400" />
                            <span className="text-sm text-slate-700">
                              {getCompanyName(broker.companyId)}
                            </span>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-2">
                            <Phone className="w-4 h-4 text-slate-400" />
                            <span className="text-sm text-slate-700 ltr">{broker.phone || '-'}</span>
                          </div>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <span className="font-medium text-slate-900">{stats.dealsCount}</span>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <span className="font-medium text-slate-900">{stats.listingsCount}</span>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                            <span className="font-medium text-slate-900">{stats.rating}</span>
                          </div>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <Badge
                            variant={broker.isActive ? 'default' : 'secondary'}
                            className={
                              broker.isActive
                                ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-100'
                            }
                          >
                            {broker.isActive ? 'نشط' : 'غير نشط'}
                          </Badge>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreVertical className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem asChild>
                                <NavLink to={`/users/brokers/${broker.id}`}>
                                  <Eye className="w-4 h-4 ml-2" />
                                  عرض التفاصيل
                                </NavLink>
                              </DropdownMenuItem>
                              <DropdownMenuItem asChild>
                                <NavLink to={`/users/brokers/${broker.id}/edit`}>
                                  <Edit className="w-4 h-4 ml-2" />
                                  تعديل
                                </NavLink>
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleToggleStatus(broker)}>
                                {broker.isActive ? (
                                  <>
                                    <UserX className="w-4 h-4 ml-2" />
                                    تعطيل الحساب
                                  </>
                                ) : (
                                  <>
                                    <UserCheck className="w-4 h-4 ml-2" />
                                    تفعيل الحساب
                                  </>
                                )}
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => handleDelete(broker.id)}
                                className="text-red-600"
                              >
                                <Trash2 className="w-4 h-4 ml-2" />
                                حذف
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {filteredBrokers.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-2">لا توجد نتائج</h3>
                <p className="text-slate-500">لم يتم العثور على وسيط يطابق معايير البحث</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pagination */}
        {filteredBrokers.length > 0 && (
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-500">
              عرض {filteredBrokers.length} من {brokers.length} وسيط
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>
                السابق
              </Button>
              <Button variant="outline" size="sm" disabled>
                التالي
              </Button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
