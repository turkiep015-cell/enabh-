import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { NavLink } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { users, clientRequests } from '@/data/mockData';
import {
  Search,
  Plus,
  MoreVertical,
  Phone,
  Home,
  Calendar,
  UserCheck,
  UserX,
  Eye,
  Edit,
  Trash2,
  Download,
  FileText,
} from 'lucide-react';

export default function Clients() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');

  // Filter clients
  const clients = users.filter((user) => user.role === 'client');

  const filteredClients = clients.filter((client) => {
    const matchesSearch =
      client.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (client.phone?.includes(searchQuery) ?? false);

    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'active'
        ? client.isActive
        : !client.isActive;

    return matchesSearch && matchesStatus;
  });

  // Get client requests count
  const getClientRequestsCount = (clientId: string) => {
    return clientRequests.filter((req) => req.clientId === clientId).length;
  };

  const activeClients = clients.filter((c) => c.isActive).length;
  const totalRequests = clientRequests.length;

  const handleDelete = (_clientId: string) => {
    toast({
      title: 'تم الحذف',
      description: 'تم حذف العميل بنجاح',
    });
  };

  const handleToggleStatus = (client: typeof clients[0]) => {
    toast({
      title: client.isActive ? 'تم التعطيل' : 'تم التفعيل',
      description: `${client.fullName} ${client.isActive ? 'تم تعطيل حسابه' : 'تم تفعيل حسابه'}`,
    });
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .slice(0, 2);
  };

  return (
    <>
      <Helmet>
        <title>العملاء | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">العملاء</h1>
            <p className="text-slate-500 mt-1">إدارة العملاء المسجلين في المنصة</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              تصدير
            </Button>
            <NavLink to="/users/clients/add">
              <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4" />
                إضافة عميل
              </Button>
            </NavLink>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي العملاء</p>
                  <p className="text-2xl font-bold text-slate-900">{clients.length}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <UserCheck className="w-5 h-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">العملاء النشطين</p>
                  <p className="text-2xl font-bold text-emerald-600">{activeClients}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <UserCheck className="w-5 h-5 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي الطلبات</p>
                  <p className="text-2xl font-bold text-amber-600">{totalRequests}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">متوسط الطلبات/عميل</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {clients.length > 0 ? (totalRequests / clients.length).toFixed(1) : 0}
                  </p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                  <Home className="w-5 h-5 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="البحث باسم العميل، البريد الإلكتروني، رقم الجوال..."
                  className="pr-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Tabs
                value={statusFilter}
                onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}
                className="w-full sm:w-auto"
              >
                <TabsList>
                  <TabsTrigger value="all">الكل</TabsTrigger>
                  <TabsTrigger value="active">نشط</TabsTrigger>
                  <TabsTrigger value="inactive">غير نشط</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Clients List */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">العميل</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">التواصل</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الطلبات</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">تاريخ التسجيل</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الحالة</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredClients.map((client) => (
                    <tr key={client.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-3">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={client.avatarUrl} alt={client.fullName} />
                            <AvatarFallback className="bg-blue-100 text-blue-700">
                              {getInitials(client.fullName)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-slate-900">{client.fullName}</p>
                            <p className="text-sm text-slate-500">{client.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <Phone className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-700 ltr">{client.phone || '-'}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <Badge variant="secondary" className="bg-amber-100 text-amber-700">
                          {getClientRequestsCount(client.id)} طلب
                        </Badge>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <Calendar className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-700">
                            {new Date(client.createdAt).toLocaleDateString('ar-SA')}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <Badge
                          variant={client.isActive ? 'default' : 'secondary'}
                          className={
                            client.isActive
                              ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-100'
                          }
                        >
                          {client.isActive ? 'نشط' : 'غير نشط'}
                        </Badge>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem asChild>
                              <NavLink to={`/users/clients/${client.id}`}>
                                <Eye className="w-4 h-4 ml-2" />
                                عرض التفاصيل
                              </NavLink>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <NavLink to={`/users/clients/${client.id}/edit`}>
                                <Edit className="w-4 h-4 ml-2" />
                                تعديل
                              </NavLink>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleToggleStatus(client)}>
                              {client.isActive ? (
                                <>
                                  <UserX className="w-4 h-4 ml-2" />
                                  تعطيل الحساب
                                </>
                              ) : (
                                <>
                                  <UserCheck className="w-4 h-4 ml-2" />
                                  تفعيل الحساب
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleDelete(client.id)}
                              className="text-red-600"
                            >
                              <Trash2 className="w-4 h-4 ml-2" />
                              حذف
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredClients.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-2">لا توجد نتائج</h3>
                <p className="text-slate-500">لم يتم العثور على عميل يطابق معايير البحث</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pagination */}
        {filteredClients.length > 0 && (
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-500">
              عرض {filteredClients.length} من {clients.length} عميل
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>
                السابق
              </Button>
              <Button variant="outline" size="sm" disabled>
                التالي
              </Button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
