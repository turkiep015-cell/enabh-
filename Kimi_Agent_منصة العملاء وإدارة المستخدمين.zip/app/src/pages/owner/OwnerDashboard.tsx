import { Helmet } from 'react-helmet-async';
import { NavLink } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/useAuth';
import { 
  properties, 
  clientRequests,
} from '@/data/mockData';
import {
  Home,
  TrendingUp,
  Eye,
  Users,
  Plus,
  ArrowUpRight,
  Phone,
  Mail,
  Clock,
} from 'lucide-react';

export default function OwnerDashboard() {
  const { user } = useAuth();

  // Filter data for this owner only
  const ownerProperties = properties.filter(p => p.listedBy === user?.id);
  const propertyRequests = clientRequests.filter(r => 
    ownerProperties.some(p => p.id === r.propertyId)
  );
  
  // Calculate stats
  const activeListings = ownerProperties.filter(p => p.status === 'active').length;
  const totalViews = ownerProperties.reduce((sum, p) => sum + p.viewCount, 0);
  const totalInquiries = ownerProperties.reduce((sum, p) => sum + p.inquiryCount, 0);
  const pendingRequests = propertyRequests.filter(r => r.status === 'open').length;

  // Recent properties
  const recentProperties = ownerProperties
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-emerald-100 text-emerald-700">معروض</Badge>;
      case 'reserved':
        return <Badge className="bg-amber-100 text-amber-700">محجوز</Badge>;
      case 'sold':
        return <Badge className="bg-blue-100 text-blue-700">مباع</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <>
      <Helmet>
        <title>لوحة تحكم المالك | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Welcome Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              مرحباً، {user?.fullName}
            </h1>
            <p className="text-slate-500 mt-1">
              مالك عقار
            </p>
          </div>
          <div className="flex items-center gap-2">
            <NavLink to="/owner/properties/add">
              <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4" />
                إضافة عقار
              </Button>
            </NavLink>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">عقاراتي</p>
                  <p className="text-2xl font-bold text-slate-900">{ownerProperties.length}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Home className="w-5 h-5 text-blue-600" />
                </div>
              </div>
              <p className="text-xs text-slate-400 mt-2">
                {activeListings} معروض للبيع
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي المشاهدات</p>
                  <p className="text-2xl font-bold text-emerald-600">{totalViews}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <Eye className="w-5 h-5 text-emerald-600" />
                </div>
              </div>
              <p className="text-xs text-slate-400 mt-2">
                منذ إضافة العقارات
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">الاستفسارات</p>
                  <p className="text-2xl font-bold text-purple-600">{totalInquiries}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                  <Users className="w-5 h-5 text-purple-600" />
                </div>
              </div>
              <p className="text-xs text-slate-400 mt-2">
                طلبات معلومات
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">طلبات جديدة</p>
                  <p className="text-2xl font-bold text-amber-600">{pendingRequests}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-amber-600" />
                </div>
              </div>
              <p className="text-xs text-slate-400 mt-2">
                بانتظار الرد
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Properties List */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-semibold">عقاراتي</CardTitle>
              <NavLink to="/owner/properties">
                <Button variant="ghost" size="sm" className="gap-1">
                  عرض الكل
                  <ArrowUpRight className="w-4 h-4" />
                </Button>
              </NavLink>
            </CardHeader>
            <CardContent>
              {recentProperties.length > 0 ? (
                <div className="space-y-3">
                  {recentProperties.map((property) => (
                    <div 
                      key={property.id} 
                      className="flex items-center gap-4 p-3 rounded-lg hover:bg-slate-50 transition-colors border border-slate-100"
                    >
                      <div className="w-16 h-16 rounded-lg bg-slate-100 flex items-center justify-center flex-shrink-0 overflow-hidden">
                        {property.images?.[0] ? (
                          <img 
                            src={property.images[0].imageUrl} 
                            alt={property.titleAr}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <Home className="w-6 h-6 text-slate-400" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-slate-900 truncate">{property.titleAr}</p>
                        <div className="flex items-center gap-4 mt-1 text-sm text-slate-500">
                          <span>{formatCurrency(property.price)}</span>
                          <span className="flex items-center gap-1">
                            <Eye className="w-3 h-3" />
                            {property.viewCount}
                          </span>
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {property.inquiryCount}
                          </span>
                        </div>
                      </div>
                      <div>
                        {getStatusBadge(property.status)}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Home className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500">لا توجد عقارات مسجلة</p>
                  <NavLink to="/owner/properties/add">
                    <Button className="mt-3 gap-2 bg-emerald-600 hover:bg-emerald-700">
                      <Plus className="w-4 h-4" />
                      إضافة عقار
                    </Button>
                  </NavLink>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Profile & Quick Actions */}
          <div className="space-y-6">
            {/* Profile Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold">ملفي الشخصي</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-full bg-emerald-100 flex items-center justify-center">
                    {user?.avatarUrl ? (
                      <img 
                        src={user.avatarUrl} 
                        alt={user.fullName}
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <span className="text-xl font-bold text-emerald-700">
                        {user?.fullName?.charAt(0)}
                      </span>
                    )}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900">{user?.fullName}</p>
                    <p className="text-sm text-slate-500">مالك عقار</p>
                  </div>
                </div>
                
                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <span className="text-slate-600">{user?.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="w-4 h-4 text-slate-400" />
                    <span className="text-slate-600 ltr">{user?.phone}</span>
                  </div>
                </div>

                <NavLink to="/owner/profile">
                  <Button variant="outline" className="w-full">
                    تعديل الملف
                  </Button>
                </NavLink>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold">إجراءات سريعة</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <NavLink to="/owner/properties/add">
                  <Button variant="outline" className="w-full justify-start gap-2">
                    <Plus className="w-4 h-4" />
                    إضافة عقار جديد
                  </Button>
                </NavLink>
                <NavLink to="/owner/requests">
                  <Button variant="outline" className="w-full justify-start gap-2">
                    <Users className="w-4 h-4" />
                    طلبات الاستفسار
                    {pendingRequests > 0 && (
                      <Badge variant="secondary" className="mr-auto">
                        {pendingRequests}
                      </Badge>
                    )}
                  </Button>
                </NavLink>
                <NavLink to="/owner/reports">
                  <Button variant="outline" className="w-full justify-start gap-2">
                    <TrendingUp className="w-4 h-4" />
                    تقارير العقارات
                  </Button>
                </NavLink>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}
