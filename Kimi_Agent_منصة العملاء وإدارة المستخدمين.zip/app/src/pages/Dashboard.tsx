import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';

import { StatsCards, ExtendedStatsCards } from '@/components/dashboard/StatsCards';
import { RevenueChart, RevenueBreakdownChart } from '@/components/charts/RevenueChart';
import { RecentDeals } from '@/components/dashboard/RecentDeals';
import { BrokerPerformanceList, BrokerPerformanceCompact } from '@/components/dashboard/BrokerPerformance';
import { PropertyCard } from '@/components/common/PropertyCard';
import { 
  LayoutDashboard, 
  TrendingUp, 
  Calendar, 
  Download,
  Plus,
  Building2,
  Users,
  Handshake,
  ArrowUpRight,
  Clock,
  Bell,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Info,
} from 'lucide-react';
import { dashboardStats, properties, notifications } from '@/data/mockData';

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const { toast } = useToast();
  const unreadNotifications = notifications.filter(n => !n.isRead).length;

  // دوال تجربة الرسائل
  const showSuccessToast = () => {
    toast({
      title: 'تم بنجاح!',
      description: 'تم تنفيذ العملية بنجاح',
    });
  };

  const showErrorToast = () => {
    toast({
      title: 'خطأ!',
      description: 'حدث خطأ أثناء تنفيذ العملية',
      variant: 'destructive',
    });
  };

  const showCustomToast = (title: string, description: string) => {
    toast({
      title,
      description,
    });
  };

  const quickActions = [
    { 
      title: 'إضافة عقار', 
      icon: Building2, 
      color: 'bg-blue-500',
      href: '/properties/add' 
    },
    { 
      title: 'صفقة جديدة', 
      icon: Handshake, 
      color: 'bg-emerald-500',
      href: '/deals/add' 
    },
    { 
      title: 'مستخدم جديد', 
      icon: Users, 
      color: 'bg-purple-500',
      href: '/users/add' 
    },
    { 
      title: 'تقرير', 
      icon: TrendingUp, 
      color: 'bg-amber-500',
      href: '/reports' 
    },
  ];

  const pendingTasks = [
    { 
      title: 'صفقات بانتظار الموافقة', 
      count: 3, 
      icon: Clock,
      color: 'text-amber-600 bg-amber-100',
      href: '/deals/pending'
    },
    { 
      title: 'عقارات بانتظار التفعيل', 
      count: 5, 
      icon: Building2,
      color: 'text-blue-600 bg-blue-100',
      href: '/properties/pending'
    },
    { 
      title: 'طلبات عملاء جديدة', 
      count: 8, 
      icon: Users,
      color: 'text-purple-600 bg-purple-100',
      href: '/requests'
    },
    { 
      title: 'عمولات مستحقة', 
      count: 12, 
      icon: TrendingUp,
      color: 'text-emerald-600 bg-emerald-100',
      href: '/commissions'
    },
  ];

  return (
    <>
      <Helmet>
        <title>لوحة التحكم | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">لوحة التحكم</h1>
            <p className="text-slate-500 mt-1">
              نظرة عامة على أداء المنصة والإحصائيات
            </p>
          </div>
          
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2">
              <Calendar className="w-4 h-4" />
              <span>آخر 30 يوم</span>
            </Button>
            <Button variant="outline" size="icon">
              <Download className="w-4 h-4" />
            </Button>
            <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700">
              <Plus className="w-4 h-4" />
              <span>إضافة جديد</span>
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <StatsCards stats={dashboardStats} />

        {/* Quick Actions & Pending Tasks */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Quick Actions */}
          <Card className="lg:col-span-2">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg font-bold text-slate-900">
                إجراءات سريعة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {quickActions.map((action, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="flex flex-col items-center gap-3 h-auto py-6 hover:border-emerald-200 hover:bg-emerald-50/50 transition-all group"
                  >
                    <div className={cn(
                      'w-12 h-12 rounded-xl flex items-center justify-center text-white transition-transform group-hover:scale-110',
                      action.color
                    )}>
                      <action.icon className="w-6 h-6" />
                    </div>
                    <span className="text-sm font-medium text-slate-700">{action.title}</span>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Pending Tasks */}
          <Card>
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-bold text-slate-900">
                  المهام المعلقة
                </CardTitle>
                <Badge variant="secondary" className="bg-red-100 text-red-700">
                  {unreadNotifications}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {pendingTasks.map((task, index) => (
                  <div 
                    key={index}
                    className="flex items-center justify-between p-3 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center', task.color)}>
                        <task.icon className="w-5 h-5" />
                      </div>
                      <span className="text-sm font-medium text-slate-700">{task.title}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="bg-red-100 text-red-700">
                        {task.count}
                      </Badge>
                      <ArrowUpRight className="w-4 h-4 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Toast Test Section */}
        <Card className="border-2 border-dashed border-emerald-200 bg-emerald-50/30">
          <CardHeader className="pb-4">
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-emerald-600" />
              <CardTitle className="text-lg font-bold text-slate-900">
                تجربة نظام الرسائل
              </CardTitle>
            </div>
            <p className="text-sm text-slate-500">
              اضغط على الأزرار أدناه لتجربة أنواع مختلفة من الرسائل
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Button
                onClick={showSuccessToast}
                className="flex flex-col items-center gap-2 h-auto py-4 bg-emerald-600 hover:bg-emerald-700"
              >
                <CheckCircle className="w-6 h-6" />
                <span className="text-sm">رسالة نجاح</span>
              </Button>
              <Button
                onClick={showErrorToast}
                variant="destructive"
                className="flex flex-col items-center gap-2 h-auto py-4"
              >
                <XCircle className="w-6 h-6" />
                <span className="text-sm">رسالة خطأ</span>
              </Button>
              <Button
                onClick={() => showCustomToast('تنبيه!', 'هذه رسالة تنبيه عامة')}
                variant="outline"
                className="flex flex-col items-center gap-2 h-auto py-4 border-amber-500 text-amber-600 hover:bg-amber-50"
              >
                <AlertTriangle className="w-6 h-6" />
                <span className="text-sm">رسالة تنبيه</span>
              </Button>
              <Button
                onClick={() => showCustomToast('معلومة', 'هذه رسالة معلوماتية')}
                variant="outline"
                className="flex flex-col items-center gap-2 h-auto py-4 border-blue-500 text-blue-600 hover:bg-blue-50"
              >
                <Info className="w-6 h-6" />
                <span className="text-sm">رسالة معلومات</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <RevenueChart className="lg:col-span-2" />
          <RevenueBreakdownChart />
        </div>

        {/* Recent Activity Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <RecentDeals className="lg:col-span-2" />
          <BrokerPerformanceCompact />
        </div>

        {/* Featured Properties */}
        <Card>
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg font-bold text-slate-900">
                  العقارات المميزة
                </CardTitle>
                <p className="text-sm text-slate-500 mt-1">
                  أحدث العقارات المضافة للمنصة
                </p>
              </div>
              <Button variant="ghost" className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 gap-1">
                عرض الكل
                <ArrowUpRight className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {properties.slice(0, 3).map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Detailed Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-slate-100 p-1">
            <TabsTrigger value="overview" className="gap-2">
              <LayoutDashboard className="w-4 h-4" />
              نظرة عامة
            </TabsTrigger>
            <TabsTrigger value="properties" className="gap-2">
              <Building2 className="w-4 h-4" />
              العقارات
            </TabsTrigger>
            <TabsTrigger value="brokers" className="gap-2">
              <Users className="w-4 h-4" />
              الوسطاء
            </TabsTrigger>
            <TabsTrigger value="analytics" className="gap-2">
              <TrendingUp className="w-4 h-4" />
              التحليلات
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <ExtendedStatsCards stats={dashboardStats} />
          </TabsContent>

          <TabsContent value="properties" className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {properties.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="brokers" className="space-y-6">
            <BrokerPerformanceList />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <RevenueChart />
              <RevenueBreakdownChart />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}
