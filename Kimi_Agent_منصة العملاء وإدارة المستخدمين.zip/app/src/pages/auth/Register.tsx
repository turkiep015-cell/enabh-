import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { NavLink, useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import {
  Eye,
  EyeOff,
  Mail,
  Lock,
  Phone,
  User,
  Building2,
  ArrowLeft,
  CheckCircle2,
  Briefcase,
  Home,
  UserCircle,
} from 'lucide-react';

export default function Register() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [userType, setUserType] = useState<'client' | 'broker' | 'developer'>('client');
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    companyName: '',
    crNumber: '',
    licenseNumber: '',
    agreeTerms: false,
  });

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      toast({
        title: 'خطأ',
        description: 'كلمتا المرور غير متطابقتين',
        variant: 'destructive',
      });
      return;
    }
    
    setIsLoading(true);
    
    // محاكاة التسجيل
    setTimeout(() => {
      toast({
        title: 'تم إنشاء الحساب بنجاح',
        description: 'يمكنك الآن تسجيل الدخول',
      });
      navigate('/login');
      setIsLoading(false);
    }, 2000);
  };

  const steps = [
    { number: 1, title: 'المعلومات الشخصية' },
    { number: 2, title: 'كلمة المرور' },
    { number: 3, title: 'المعلومات الإضافية' },
  ];

  const userTypes = [
    { 
      value: 'client', 
      label: 'عميل', 
      description: 'ابحث عن عقارك المثالي',
      icon: UserCircle,
      color: 'bg-blue-100 text-blue-700 border-blue-200'
    },
    { 
      value: 'broker', 
      label: 'وسيط عقاري', 
      description: 'أدرج العقارات وأغلق الصفقات',
      icon: Briefcase,
      color: 'bg-emerald-100 text-emerald-700 border-emerald-200'
    },
    { 
      value: 'developer', 
      label: 'مطور عقاري', 
      description: 'اعرض مشاريعك العقارية',
      icon: Home,
      color: 'bg-amber-100 text-amber-700 border-amber-200'
    },
  ];

  return (
    <>
      <Helmet>
        <title>إنشاء حساب جديد | إنابة المستقبل</title>
      </Helmet>

      <div className="min-h-screen flex">
        {/* Left Side - Image */}
        <div className="hidden lg:flex lg:w-1/2 relative">
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-900/90 to-emerald-800/80 z-10" />
          <img
            src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=1200&h=800&fit=crop"
            alt="عقارات"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="relative z-20 flex flex-col justify-center px-16 text-white">
            <div className="mb-8">
              <div className="w-16 h-16 rounded-xl bg-emerald-500 flex items-center justify-center mb-6">
                <Building2 className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-4xl font-bold mb-4">انضم إلينا</h1>
              <p className="text-emerald-100 text-lg">كن جزءاً من مستقبل العقارات في المملكة</p>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                <span>منصة موثوقة وآمنة</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                <span>نظام عمولات شفاف</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                <span>دعم فني على مدار الساعة</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Form */}
        <div className="flex-1 flex flex-col justify-center px-6 sm:px-12 lg:px-20 py-12 bg-slate-50 overflow-y-auto">
          <div className="max-w-lg w-full mx-auto">
            {/* Mobile Logo */}
            <div className="lg:hidden text-center mb-8">
              <div className="w-16 h-16 rounded-xl bg-emerald-600 flex items-center justify-center mx-auto mb-4">
                <Building2 className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-slate-900">إنابة المستقبل</h1>
            </div>

            <Card className="border-0 shadow-xl">
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-2xl font-bold text-slate-900">
                  إنشاء حساب جديد
                </CardTitle>
                <CardDescription>
                  اختر نوع الحساب وأكمل بياناتك
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* User Type Selection */}
                <div className="grid grid-cols-3 gap-2">
                  {userTypes.map((type) => (
                    <button
                      key={type.value}
                      onClick={() => setUserType(type.value as 'client' | 'broker' | 'developer')}
                      className={cn(
                        'flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all',
                        userType === type.value 
                          ? type.color 
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      )}
                    >
                      <type.icon className="w-6 h-6" />
                      <span className="text-xs font-medium">{type.label}</span>
                    </button>
                  ))}
                </div>

                {/* Progress Steps */}
                <div className="flex items-center justify-between">
                  {steps.map((s, index) => (
                    <div key={s.number} className="flex items-center">
                      <div className={cn(
                        'w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold',
                        step >= s.number 
                          ? 'bg-emerald-600 text-white' 
                          : 'bg-slate-200 text-slate-500'
                      )}>
                        {step > s.number ? <CheckCircle2 className="w-5 h-5" /> : s.number}
                      </div>
                      {index < steps.length - 1 && (
                        <div className={cn(
                          'w-12 h-0.5 mx-2',
                          step > s.number ? 'bg-emerald-600' : 'bg-slate-200'
                        )} />
                      )}
                    </div>
                  ))}
                </div>

                <form onSubmit={handleRegister} className="space-y-4">
                  {/* Step 1: Personal Info */}
                  {step === 1 && (
                    <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                      <div className="space-y-2">
                        <Label htmlFor="fullName">الاسم الكامل</Label>
                        <div className="relative">
                          <User className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                          <Input
                            id="fullName"
                            placeholder="محمد عبدالله"
                            className="pr-10"
                            value={formData.fullName}
                            onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email">البريد الإلكتروني</Label>
                        <div className="relative">
                          <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                          <Input
                            id="email"
                            type="email"
                            placeholder="example@email.com"
                            className="pr-10"
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="phone">رقم الجوال</Label>
                        <div className="relative">
                          <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                          <Input
                            id="phone"
                            type="tel"
                            placeholder="+966 50 123 4567"
                            className="pr-10"
                            value={formData.phone}
                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                            required
                          />
                        </div>
                      </div>

                      <Button
                        type="button"
                        className="w-full bg-emerald-600 hover:bg-emerald-700"
                        onClick={() => setStep(2)}
                        disabled={!formData.fullName || !formData.email || !formData.phone}
                      >
                        التالي
                      </Button>
                    </div>
                  )}

                  {/* Step 2: Password */}
                  {step === 2 && (
                    <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                      <div className="space-y-2">
                        <Label htmlFor="password">كلمة المرور</Label>
                        <div className="relative">
                          <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                          <Input
                            id="password"
                            type={showPassword ? 'text' : 'password'}
                            placeholder="••••••••"
                            className="pr-10 pl-10"
                            value={formData.password}
                            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                            required
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                          >
                            {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword">تأكيد كلمة المرور</Label>
                        <div className="relative">
                          <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                          <Input
                            id="confirmPassword"
                            type={showConfirmPassword ? 'text' : 'password'}
                            placeholder="••••••••"
                            className="pr-10 pl-10"
                            value={formData.confirmPassword}
                            onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                            required
                          />
                          <button
                            type="button"
                            onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                          >
                            {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          className="flex-1"
                          onClick={() => setStep(1)}
                        >
                          السابق
                        </Button>
                        <Button
                          type="button"
                          className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                          onClick={() => setStep(3)}
                          disabled={!formData.password || formData.password.length < 6}
                        >
                          التالي
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Step 3: Additional Info */}
                  {step === 3 && (
                    <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                      {(userType === 'broker' || userType === 'developer') && (
                        <>
                          <div className="space-y-2">
                            <Label htmlFor="companyName">اسم الشركة</Label>
                            <Input
                              id="companyName"
                              placeholder="شركة الرياض العقارية"
                              value={formData.companyName}
                              onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="crNumber">رقم السجل التجاري</Label>
                            <Input
                              id="crNumber"
                              placeholder="1010123456"
                              value={formData.crNumber}
                              onChange={(e) => setFormData({ ...formData, crNumber: e.target.value })}
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="licenseNumber">رقم الترخيص</Label>
                            <Input
                              id="licenseNumber"
                              placeholder="REL-2024-001"
                              value={formData.licenseNumber}
                              onChange={(e) => setFormData({ ...formData, licenseNumber: e.target.value })}
                            />
                          </div>
                        </>
                      )}

                      <div className="flex items-start gap-2">
                        <Checkbox
                          id="terms"
                          checked={formData.agreeTerms}
                          onCheckedChange={(checked) => 
                            setFormData({ ...formData, agreeTerms: checked as boolean })
                          }
                        />
                        <Label htmlFor="terms" className="text-sm text-slate-600 leading-relaxed cursor-pointer">
                          أوافق على{' '}
                          <NavLink to="/terms" className="text-emerald-600 hover:underline">شروط الاستخدام</NavLink>
                          {' '}و{' '}
                          <NavLink to="/privacy" className="text-emerald-600 hover:underline">سياسة الخصوصية</NavLink>
                        </Label>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          className="flex-1"
                          onClick={() => setStep(2)}
                        >
                          السابق
                        </Button>
                        <Button
                          type="submit"
                          className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                          disabled={isLoading || !formData.agreeTerms}
                        >
                          {isLoading ? (
                            <span className="flex items-center gap-2">
                              <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                              جاري الإنشاء...
                            </span>
                          ) : (
                            'إنشاء الحساب'
                          )}
                        </Button>
                      </div>
                    </div>
                  )}
                </form>

                {/* Login Link */}
                <div className="text-center pt-4 border-t border-slate-100">
                  <p className="text-slate-600">
                    لديك حساب بالفعل؟{' '}
                    <NavLink to="/login" className="text-emerald-600 hover:text-emerald-700 font-medium">
                      سجل دخولك
                    </NavLink>
                  </p>
                </div>

                {/* Back to Home */}
                <NavLink 
                  to="/landing.html"
                  className="flex items-center justify-center gap-2 text-sm text-slate-500 hover:text-slate-700 transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  العودة للصفحة الرئيسية
                </NavLink>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}
