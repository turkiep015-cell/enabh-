import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { NavLink, useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { useAuth, getDashboardRoute } from '@/hooks/useAuth';
import {
  Eye,
  EyeOff,
  Mail,
  Lock,
  Phone,
  Building2,
  ArrowLeft,
  CheckCircle2,
} from 'lucide-react';
import { users } from '@/data/mockData';

export default function Login() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { quickLogin } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const [loginMethod, setLoginMethod] = useState<'email' | 'phone'>('email');
  const [isLoading, setIsLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    email: '',
    phone: '',
    password: '',
    rememberMe: false,
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // محاكاة تسجيل الدخول
    setTimeout(() => {
      const identifier = loginMethod === 'email' ? formData.email : formData.phone;
      const user = users.find(u => 
        loginMethod === 'email' ? u.email === identifier : u.phone === identifier
      );
      
      if (user) {
        // Use quickLogin to set auth state
        const role = user.role as 'super_admin' | 'broker' | 'client' | 'developer' | 'owner';
        quickLogin(role);
        
        toast({
          title: 'تم تسجيل الدخول بنجاح',
          description: `مرحباً ${user.fullName}`,
        });
        
        // Navigate to appropriate dashboard
        navigate(getDashboardRoute(role));
      } else {
        toast({
          title: 'خطأ في تسجيل الدخول',
          description: 'البريد الإلكتروني أو كلمة المرور غير صحيحة',
          variant: 'destructive',
        });
      }
      setIsLoading(false);
    }, 1500);
  };

  const quickLoginUsers = [
    { email: 'admin@inabah.sa', role: 'مدير النظام', roleKey: 'super_admin' as const, color: 'bg-purple-100 text-purple-700' },
    { email: 'broker1@inabah.sa', role: 'وسيط عقاري', roleKey: 'broker' as const, color: 'bg-emerald-100 text-emerald-700' },
    { email: 'client1@example.com', role: 'عميل', roleKey: 'client' as const, color: 'bg-blue-100 text-blue-700' },
    { email: 'developer@riyadhdev.sa', role: 'مطور عقاري', roleKey: 'developer' as const, color: 'bg-amber-100 text-amber-700' },
  ];

  return (
    <>
      <Helmet>
        <title>تسجيل الدخول | إنابة المستقبل</title>
      </Helmet>

      <div className="min-h-screen flex">
        {/* Left Side - Image */}
        <div className="hidden lg:flex lg:w-1/2 relative">
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-900/90 to-emerald-800/80 z-10" />
          <img
            src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1200&h=800&fit=crop"
            alt="عقارات فاخرة"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="relative z-20 flex flex-col justify-center px-16 text-white">
            <div className="mb-8">
              <div className="w-16 h-16 rounded-xl bg-emerald-500 flex items-center justify-center mb-6">
                <Building2 className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-4xl font-bold mb-4">إنابة المستقبل</h1>
              <p className="text-emerald-100 text-lg">للخدمات العقارية</p>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                <span>أكثر من 1,250 صفقة ناجحة</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                <span>أكثر من 150 وسيط نشط</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                <span>2.5 مليار ريال مبيعات</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Form */}
        <div className="flex-1 flex flex-col justify-center px-6 sm:px-12 lg:px-20 py-12 bg-slate-50">
          <div className="max-w-md w-full mx-auto">
            {/* Mobile Logo */}
            <div className="lg:hidden text-center mb-8">
              <div className="w-16 h-16 rounded-xl bg-emerald-600 flex items-center justify-center mx-auto mb-4">
                <Building2 className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-slate-900">إنابة المستقبل</h1>
              <p className="text-slate-500">للخدمات العقارية</p>
            </div>

            <Card className="border-0 shadow-xl">
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-2xl font-bold text-slate-900">
                  تسجيل الدخول
                </CardTitle>
                <CardDescription>
                  أدخل بياناتك للوصول إلى حسابك
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* Login Method Tabs */}
                <Tabs value={loginMethod} onValueChange={(v) => setLoginMethod(v as 'email' | 'phone')}>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="email" className="gap-2">
                      <Mail className="w-4 h-4" />
                      البريد الإلكتروني
                    </TabsTrigger>
                    <TabsTrigger value="phone" className="gap-2">
                      <Phone className="w-4 h-4" />
                      رقم الجوال
                    </TabsTrigger>
                  </TabsList>

                  <form onSubmit={handleLogin} className="mt-6 space-y-4">
                    <TabsContent value="email" className="mt-0">
                      <div className="space-y-2">
                        <Label htmlFor="email">البريد الإلكتروني</Label>
                        <div className="relative">
                          <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                          <Input
                            id="email"
                            type="email"
                            placeholder="example@email.com"
                            className="pr-10"
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            required
                          />
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="phone" className="mt-0">
                      <div className="space-y-2">
                        <Label htmlFor="phone">رقم الجوال</Label>
                        <div className="relative">
                          <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                          <Input
                            id="phone"
                            type="tel"
                            placeholder="+966 50 123 4567"
                            className="pr-10"
                            value={formData.phone}
                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                            required
                          />
                        </div>
                      </div>
                    </TabsContent>

                    <div className="space-y-2">
                      <Label htmlFor="password">كلمة المرور</Label>
                      <div className="relative">
                        <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                        <Input
                          id="password"
                          type={showPassword ? 'text' : 'password'}
                          placeholder="••••••••"
                          className="pr-10 pl-10"
                          value={formData.password}
                          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                        >
                          {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id="remember"
                          checked={formData.rememberMe}
                          onCheckedChange={(checked) => 
                            setFormData({ ...formData, rememberMe: checked as boolean })
                          }
                        />
                        <Label htmlFor="remember" className="text-sm text-slate-600 cursor-pointer">
                          تذكرني
                        </Label>
                      </div>
                      <NavLink to="/forgot-password" className="text-sm text-emerald-600 hover:text-emerald-700">
                        نسيت كلمة المرور؟
                      </NavLink>
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-emerald-600 hover:bg-emerald-700 h-12 text-lg"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <span className="flex items-center gap-2">
                          <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          جاري تسجيل الدخول...
                        </span>
                      ) : (
                        'تسجيل الدخول'
                      )}
                    </Button>
                  </form>
                </Tabs>

                {/* Quick Login */}
                <div className="pt-4 border-t border-slate-100">
                  <p className="text-sm text-slate-500 text-center mb-4">تسجيل الدخول السريع (للتجربة)</p>
                  <div className="grid grid-cols-2 gap-2">
                    {quickLoginUsers.map((user, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          quickLogin(user.roleKey);
                          toast({
                            title: `تسجيل دخول كـ ${user.role}`,
                            description: user.email,
                          });
                          navigate(getDashboardRoute(user.roleKey));
                        }}
                        className={cn(
                          'p-2 rounded-lg text-xs font-medium transition-all hover:scale-105',
                          user.color
                        )}
                      >
                        {user.role}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Register Link */}
                <div className="text-center pt-4">
                  <p className="text-slate-600">
                    ليس لديك حساب؟{' '}
                    <NavLink to="/register" className="text-emerald-600 hover:text-emerald-700 font-medium">
                      سجل الآن
                    </NavLink>
                  </p>
                </div>

                {/* Back to Home */}
                <NavLink 
                  to="/landing.html"
                  className="flex items-center justify-center gap-2 text-sm text-slate-500 hover:text-slate-700 transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  العودة للصفحة الرئيسية
                </NavLink>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}
