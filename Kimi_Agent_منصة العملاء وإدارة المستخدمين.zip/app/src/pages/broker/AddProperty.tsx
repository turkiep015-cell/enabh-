import { useState, useRef } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';

import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { cities, propertyTypes } from '@/data/mockData';
import {
  MapPin,
  DollarSign,
  Bed,
  Bath,
  Maximize,
  Calendar,
  X,
  Upload,
  Check,
  ArrowRight,
  ArrowLeft,
  Layers,
  Car,
  Sofa,
  Wind,
  Flame,
  Shield,
  Trees,
  Waves,
  Dumbbell,
  Gamepad2,
  Baby,
  Camera
} from 'lucide-react';
import { cn } from '@/lib/utils';

const amenitiesList = [
  { id: 'pool', label: 'مسبح', icon: Waves },
  { id: 'gym', label: 'نادي رياضي', icon: Dumbbell },
  { id: 'parking', label: 'موقف سيارات', icon: Car },
  { id: 'security', label: 'أمن 24 ساعة', icon: Shield },
  { id: 'garden', label: 'حديقة', icon: Trees },
  { id: 'elevator', label: 'مصعد', icon: Layers },
  { id: 'furnished', label: 'مفروش', icon: Sofa },
  { id: 'ac', label: 'تكييف', icon: Wind },
  { id: 'heating', label: 'تدفئة', icon: Flame },
  { id: 'cameras', label: 'كاميرات مراقبة', icon: Camera },
  { id: 'playground', label: 'ملعب أطفال', icon: Baby },
  { id: 'games', label: 'غرفة ألعاب', icon: Gamepad2 },
];

const nearbyPlacesList = [
  { id: 'mosque', label: 'مسجد' },
  { id: 'school', label: 'مدرسة' },
  { id: 'hospital', label: 'مستشفى' },
  { id: 'mall', label: 'مجمع تجاري' },
  { id: 'supermarket', label: 'سوبرماركت' },
  { id: 'park', label: 'حديقة عامة' },
  { id: 'restaurant', label: 'مطاعم' },
  { id: 'bank', label: 'بنك' },
  { id: 'pharmacy', label: 'صيدلية' },
  { id: 'gas', label: 'محطة وقود' },
];

export default function AddProperty() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [selectedNearby, setSelectedNearby] = useState<string[]>([]);
  
  const [formData, setFormData] = useState({
    // Basic Info
    title: '',
    description: '',
    propertyType: '',
    listingType: 'sale',
    
    // Location
    city: '',
    district: '',
    address: '',
    latitude: '',
    longitude: '',
    
    // Details
    price: '',
    area: '',
    bedrooms: '',
    bathrooms: '',
    floorNumber: '',
    totalFloors: '',
    yearBuilt: '',
    furnishingStatus: 'unfurnished',
    
    // Features
    hasDriverRoom: false,
    hasMaidRoom: false,
    hasBasement: false,
    hasRoof: false,
    
    // Additional
    titleDeed: '',
    propertyAge: '',
    maintenanceFee: '',
    
    // Contact
    contactName: user?.fullName || '',
    contactPhone: user?.phone || '',
    contactEmail: user?.email || '',
    allowWhatsApp: true,
  });

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newImages: string[] = [];
      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          newImages.push(reader.result as string);
          if (newImages.length === files.length) {
            setUploadedImages(prev => [...prev, ...newImages].slice(0, 10));
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeImage = (index: number) => {
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
  };

  const toggleAmenity = (id: string) => {
    setSelectedAmenities(prev => 
      prev.includes(id) ? prev.filter(a => a !== id) : [...prev, id]
    );
  };

  const toggleNearby = (id: string) => {
    setSelectedNearby(prev => 
      prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]
    );
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    toast({
      title: 'تم إضافة العقار بنجاح',
      description: 'سيتم مراجعة العقار والموافقة عليه قريباً',
    });
    
    navigate('/broker/properties');
  };

  const steps = [
    { id: 1, title: 'المعلومات الأساسية' },
    { id: 2, title: 'الموقع' },
    { id: 3, title: 'التفاصيل' },
    { id: 4, title: 'المرافق والخدمات' },
    { id: 5, title: 'الصور' },
    { id: 6, title: 'المراجعة' },
  ];

  const isStepValid = () => {
    switch (currentStep) {
      case 1:
        return formData.title && formData.description && formData.propertyType && formData.listingType;
      case 2:
        return formData.city && formData.district && formData.address;
      case 3:
        return formData.price && formData.area && formData.bedrooms && formData.bathrooms;
      case 4:
        return true;
      case 5:
        return uploadedImages.length > 0;
      default:
        return true;
    }
  };

  return (
    <>
      <Helmet>
        <title>إضافة عقار جديد | إنابة المستقبل</title>
      </Helmet>

      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-900 mb-2">إضافة عقار جديد</h1>
          <p className="text-slate-500">أدخل تفاصيل العقار لإضافته إلى قائمتك</p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className={cn(
                  'w-10 h-10 rounded-full flex items-center justify-center font-semibold text-sm transition-colors',
                  currentStep > step.id && 'bg-emerald-600 text-white',
                  currentStep === step.id && 'bg-emerald-600 text-white',
                  currentStep < step.id && 'bg-slate-200 text-slate-500'
                )}>
                  {currentStep > step.id ? <Check className="w-5 h-5" /> : step.id}
                </div>
                <span className={cn(
                  'hidden md:block mr-2 text-sm font-medium',
                  currentStep >= step.id ? 'text-emerald-600' : 'text-slate-400'
                )}>
                  {step.title}
                </span>
                {index < steps.length - 1 && (
                  <div className={cn(
                    'hidden md:block w-12 h-0.5 mx-2',
                    currentStep > step.id ? 'bg-emerald-600' : 'bg-slate-200'
                  )} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Form Content */}
        <Card>
          <CardContent className="p-6">
            {/* Step 1: Basic Info */}
            {currentStep === 1 && (
              <div className="space-y-6">
                <div>
                  <Label htmlFor="title">عنوان العقار *</Label>
                  <Input
                    id="title"
                    placeholder="مثال: فيلا فاخرة في حي النرجس"
                    value={formData.title}
                    onChange={(e) => handleInputChange('title', e.target.value)}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="description">وصف العقار *</Label>
                  <Textarea
                    id="description"
                    placeholder="اكتب وصفاً تفصيلياً للعقار..."
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    className="mt-1 min-h-[120px]"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>نوع العقار *</Label>
                    <select
                      value={formData.propertyType}
                      onChange={(e) => handleInputChange('propertyType', e.target.value)}
                      className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="">اختر نوع العقار</option>
                      {propertyTypes.map(type => (
                        <option key={type.id} value={type.id}>{type.nameAr}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <Label>نوع العرض *</Label>
                    <div className="flex gap-2 mt-1">
                      <button
                        onClick={() => handleInputChange('listingType', 'sale')}
                        className={cn(
                          'flex-1 py-2 px-4 rounded-lg border-2 transition-all',
                          formData.listingType === 'sale'
                            ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                            : 'border-slate-200 hover:border-emerald-300'
                        )}
                      >
                        للبيع
                      </button>
                      <button
                        onClick={() => handleInputChange('listingType', 'rent')}
                        className={cn(
                          'flex-1 py-2 px-4 rounded-lg border-2 transition-all',
                          formData.listingType === 'rent'
                            ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                            : 'border-slate-200 hover:border-emerald-300'
                        )}
                      >
                        للإيجار
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Location */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>المدينة *</Label>
                    <select
                      value={formData.city}
                      onChange={(e) => handleInputChange('city', e.target.value)}
                      className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="">اختر المدينة</option>
                      {cities.map(city => (
                        <option key={city.id} value={city.id}>{city.nameAr}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <Label htmlFor="district">الحي *</Label>
                    <Input
                      id="district"
                      placeholder="مثال: النرجس"
                      value={formData.district}
                      onChange={(e) => handleInputChange('district', e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="address">العنوان التفصيلي *</Label>
                  <Textarea
                    id="address"
                    placeholder="أدخل العنوان الكامل مع رقم المبنى والشارع..."
                    value={formData.address}
                    onChange={(e) => handleInputChange('address', e.target.value)}
                    className="mt-1"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="latitude">خط العرض (اختياري)</Label>
                    <Input
                      id="latitude"
                      placeholder="24.7136"
                      value={formData.latitude}
                      onChange={(e) => handleInputChange('latitude', e.target.value)}
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="longitude">خط الطول (اختياري)</Label>
                    <Input
                      id="longitude"
                      placeholder="46.6753"
                      value={formData.longitude}
                      onChange={(e) => handleInputChange('longitude', e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </div>

                {/* Map Placeholder */}
                <div className="bg-slate-100 rounded-xl h-64 flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="w-12 h-12 text-slate-400 mx-auto mb-2" />
                    <p className="text-slate-500">الخريطة التفاعلية ستظهر هنا</p>
                    <p className="text-sm text-slate-400">يمكنك تحديد الموقع بالنقر على الخريطة</p>
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Details */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="price">
                      {formData.listingType === 'sale' ? 'السعر (ريال) *' : 'الإيجار السنوي (ريال) *'}
                    </Label>
                    <div className="relative mt-1">
                      <DollarSign className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <Input
                        id="price"
                        type="number"
                        placeholder="2500000"
                        value={formData.price}
                        onChange={(e) => handleInputChange('price', e.target.value)}
                        className="pr-10"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="area">المساحة (م²) *</Label>
                    <div className="relative mt-1">
                      <Maximize className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <Input
                        id="area"
                        type="number"
                        placeholder="450"
                        value={formData.area}
                        onChange={(e) => handleInputChange('area', e.target.value)}
                        className="pr-10"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="bedrooms">غرف النوم *</Label>
                    <div className="relative mt-1">
                      <Bed className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <Input
                        id="bedrooms"
                        type="number"
                        placeholder="5"
                        value={formData.bedrooms}
                        onChange={(e) => handleInputChange('bedrooms', e.target.value)}
                        className="pr-10"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="bathrooms">الحمامات *</Label>
                    <div className="relative mt-1">
                      <Bath className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <Input
                        id="bathrooms"
                        type="number"
                        placeholder="6"
                        value={formData.bathrooms}
                        onChange={(e) => handleInputChange('bathrooms', e.target.value)}
                        className="pr-10"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="yearBuilt">سنة البناء</Label>
                    <div className="relative mt-1">
                      <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <Input
                        id="yearBuilt"
                        type="number"
                        placeholder="2023"
                        value={formData.yearBuilt}
                        onChange={(e) => handleInputChange('yearBuilt', e.target.value)}
                        className="pr-10"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="floorNumber">رقم الدور</Label>
                    <Input
                      id="floorNumber"
                      type="number"
                      placeholder="0 للأرضي"
                      value={formData.floorNumber}
                      onChange={(e) => handleInputChange('floorNumber', e.target.value)}
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="totalFloors">إجمالي الأدوار</Label>
                    <Input
                      id="totalFloors"
                      type="number"
                      placeholder="2"
                      value={formData.totalFloors}
                      onChange={(e) => handleInputChange('totalFloors', e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </div>

                <div>
                  <Label>حالة التأثيث</Label>
                  <div className="flex gap-2 mt-1">
                    {[
                      { value: 'furnished', label: 'مفروش' },
                      { value: 'semi_furnished', label: 'نصف مفروش' },
                      { value: 'unfurnished', label: 'غير مفروش' },
                    ].map(option => (
                      <button
                        key={option.value}
                        onClick={() => handleInputChange('furnishingStatus', option.value)}
                        className={cn(
                          'flex-1 py-2 px-4 rounded-lg border-2 transition-all',
                          formData.furnishingStatus === option.value
                            ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                            : 'border-slate-200 hover:border-emerald-300'
                        )}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="mb-3 block">مميزات إضافية</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {[
                      { id: 'hasDriverRoom', label: 'غرفة سائق' },
                      { id: 'hasMaidRoom', label: 'غرفة خادمة' },
                      { id: 'hasBasement', label: 'قبو' },
                      { id: 'hasRoof', label: 'سطح' },
                    ].map(feature => (
                      <label
                        key={feature.id}
                        className={cn(
                          'flex items-center gap-2 p-3 rounded-lg border-2 cursor-pointer transition-all',
                          formData[feature.id as keyof typeof formData]
                            ? 'border-emerald-600 bg-emerald-50'
                            : 'border-slate-200 hover:border-emerald-300'
                        )}
                      >
                        <Checkbox
                          checked={formData[feature.id as keyof typeof formData] as boolean}
                          onCheckedChange={(checked) => handleInputChange(feature.id, checked as boolean)}
                        />
                        <span className="text-sm">{feature.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: Amenities */}
            {currentStep === 4 && (
              <div className="space-y-6">
                <div>
                  <Label className="mb-3 block">المرافق والخدمات</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {amenitiesList.map(amenity => {
                      const Icon = amenity.icon;
                      return (
                        <button
                          key={amenity.id}
                          onClick={() => toggleAmenity(amenity.id)}
                          className={cn(
                            'flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all',
                            selectedAmenities.includes(amenity.id)
                              ? 'border-emerald-600 bg-emerald-50'
                              : 'border-slate-200 hover:border-emerald-300'
                          )}
                        >
                          <Icon className={cn(
                            'w-6 h-6',
                            selectedAmenities.includes(amenity.id) ? 'text-emerald-600' : 'text-slate-400'
                          )} />
                          <span className="text-sm">{amenity.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="mb-3 block">الأماكن القريبة</Label>
                  <div className="flex flex-wrap gap-2">
                    {nearbyPlacesList.map(place => (
                      <button
                        key={place.id}
                        onClick={() => toggleNearby(place.id)}
                        className={cn(
                          'px-4 py-2 rounded-full border-2 transition-all',
                          selectedNearby.includes(place.id)
                            ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                            : 'border-slate-200 hover:border-emerald-300'
                        )}
                      >
                        {place.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Step 5: Images */}
            {currentStep === 5 && (
              <div className="space-y-6">
                <div>
                  <Label className="mb-3 block">صور العقار * (الحد الأقصى 10 صور)</Label>
                  
                  {/* Upload Area */}
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center cursor-pointer hover:border-emerald-500 hover:bg-emerald-50 transition-all"
                  >
                    <Upload className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                    <p className="text-slate-600 mb-1">اضغط هنا لرفع الصور</p>
                    <p className="text-sm text-slate-400">أو اسحب الصور وأفلتها هنا</p>
                    <p className="text-xs text-slate-400 mt-2">PNG, JPG حتى 5 ميجابايت</p>
                  </div>
                  
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>

                {/* Uploaded Images */}
                {uploadedImages.length > 0 && (
                  <div>
                    <Label className="mb-3 block">الصور المرفوعة ({uploadedImages.length}/10)</Label>
                    <div className="grid grid-cols-3 md:grid-cols-5 gap-3">
                      {uploadedImages.map((image, index) => (
                        <div key={index} className="relative aspect-square rounded-lg overflow-hidden group">
                          <img
                            src={image}
                            alt={`صورة ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                          <button
                            onClick={() => removeImage(index)}
                            className="absolute top-1 right-1 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-4 h-4" />
                          </button>
                          {index === 0 && (
                            <div className="absolute bottom-0 left-0 right-0 bg-emerald-600 text-white text-xs py-1 text-center">
                              الصورة الرئيسية
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Image Tips */}
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <h4 className="font-medium text-amber-800 mb-2">نصائح للصور:</h4>
                  <ul className="text-sm text-amber-700 space-y-1 list-disc list-inside">
                    <li>استخدم صور عالية الجودة وواضحة</li>
                    <li>تأكد من إضاءة جيدة للعقار</li>
                    <li>صور من زوايا مختلفة تظهر جميع تفاصيل العقار</li>
                    <li>الصورة الأولى ستكون الصورة الرئيسية</li>
                  </ul>
                </div>
              </div>
            )}

            {/* Step 6: Review */}
            {currentStep === 6 && (
              <div className="space-y-6">
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
                  <h3 className="font-semibold text-emerald-800 mb-2">مراجعة العقار</h3>
                  <p className="text-emerald-700 text-sm">يرجى مراجعة المعلومات قبل الإرسال للموافقة</p>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-slate-900 mb-3">المعلومات الأساسية</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-500">العنوان:</span>
                        <span className="font-medium">{formData.title}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">نوع العقار:</span>
                        <span className="font-medium">
                          {propertyTypes.find(t => t.id === formData.propertyType)?.nameAr}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">نوع العرض:</span>
                        <span className="font-medium">
                          {formData.listingType === 'sale' ? 'للبيع' : 'للإيجار'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-900 mb-3">الموقع</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-500">المدينة:</span>
                        <span className="font-medium">
                          {cities.find(c => c.id === formData.city)?.nameAr}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">الحي:</span>
                        <span className="font-medium">{formData.district}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-900 mb-3">التفاصيل</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-500">السعر:</span>
                        <span className="font-medium">{Number(formData.price).toLocaleString()} ريال</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">المساحة:</span>
                        <span className="font-medium">{formData.area} م²</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">الغرف:</span>
                        <span className="font-medium">{formData.bedrooms}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">الحمامات:</span>
                        <span className="font-medium">{formData.bathrooms}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-900 mb-3">المرافق</h4>
                    <div className="flex flex-wrap gap-1">
                      {selectedAmenities.length > 0 ? (
                        selectedAmenities.map(id => {
                          const amenity = amenitiesList.find(a => a.id === id);
                          return amenity ? (
                            <Badge key={id} variant="secondary" className="text-xs">
                              {amenity.label}
                            </Badge>
                          ) : null;
                        })
                      ) : (
                        <span className="text-slate-400 text-sm">لا توجد مرافق محددة</span>
                      )}
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-3">الصور</h4>
                  <div className="flex gap-2">
                    {uploadedImages.map((image, index) => (
                      <img
                        key={index}
                        src={image}
                        alt={`صورة ${index + 1}`}
                        className="w-20 h-20 object-cover rounded-lg"
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8 pt-6 border-t">
              <Button
                variant="outline"
                onClick={() => setCurrentStep(prev => prev - 1)}
                disabled={currentStep === 1}
              >
                <ArrowRight className="w-4 h-4 ml-2" />
                السابق
              </Button>

              {currentStep < 6 ? (
                <Button
                  onClick={() => setCurrentStep(prev => prev + 1)}
                  disabled={!isStepValid()}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  التالي
                  <ArrowLeft className="w-4 h-4 mr-2" />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  {isSubmitting ? (
                    <>
                      <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin ml-2" />
                      جاري الإرسال...
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4 ml-2" />
                      إرسال للموافقة
                    </>
                  )}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
