import { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/hooks/useAuth';
import { deals } from '@/data/mockData';
import {
  DollarSign,
  Calendar,
  Home,
  Search,
  Download,
  FileText,
  CheckCircle,
  Clock,
  XCircle,
  ArrowUpRight,
  Percent
} from 'lucide-react';
import { formatCurrency, formatDate } from '@/lib/utils';

export default function MyCommissions() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedYear, setSelectedYear] = useState('2024');
  const [selectedTab, setSelectedTab] = useState('all');

  // Filter deals for current broker
  const myDeals = useMemo(() => {
    return deals.filter(d => 
      d.listingAgentId === user?.id || d.sellingAgentId === user?.id
    );
  }, [user?.id]);

  // Calculate commissions
  const commissions = useMemo(() => {
    return myDeals.map(deal => {
      const isListingAgent = deal.listingAgentId === user?.id;
      const isSellingAgent = deal.sellingAgentId === user?.id;
      
      let myCommission = 0;
      let commissionType = '';
      
      if (isListingAgent && isSellingAgent) {
        myCommission = deal.totalCommission;
        commissionType = 'كامل';
      } else if (isListingAgent) {
        myCommission = deal.totalCommission * 0.4;
        commissionType = 'إدراج';
      } else if (isSellingAgent) {
        myCommission = deal.totalCommission * 0.6;
        commissionType = 'بيع';
      }

      return {
        ...deal,
        myCommission,
        commissionType,
        isListingAgent,
        isSellingAgent,
      };
    });
  }, [myDeals, user?.id]);

  // Filter based on search and tab
  const filteredCommissions = useMemo(() => {
    let filtered = commissions;

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(c => 
        c.dealNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.property?.titleAr.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Tab filter
    switch (selectedTab) {
      case 'paid':
        filtered = filtered.filter(c => c.status === 'completed');
        break;
      case 'pending':
        filtered = filtered.filter(c => c.status === 'pending' || c.status === 'approved');
        break;
      case 'listing':
        filtered = filtered.filter(c => c.commissionType === 'إدراج');
        break;
      case 'selling':
        filtered = filtered.filter(c => c.commissionType === 'بيع');
        break;
    }

    return filtered;
  }, [commissions, searchQuery, selectedTab]);

  // Stats
  const stats = useMemo(() => {
    const total = commissions.reduce((sum, c) => sum + c.myCommission, 0);
    const paid = commissions
      .filter(c => c.status === 'completed')
      .reduce((sum, c) => sum + c.myCommission, 0);
    const pending = commissions
      .filter(c => c.status === 'pending' || c.status === 'approved')
      .reduce((sum, c) => sum + c.myCommission, 0);
    const totalDeals = commissions.length;

    return { total, paid, pending, totalDeals };
  }, [commissions]);

  // Monthly data for chart
  const monthlyData = useMemo(() => {
    const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    return months.map((month, index) => {
      const monthCommissions = commissions.filter(c => {
        const date = new Date(c.createdAt);
        return date.getMonth() === index && date.getFullYear() === parseInt(selectedYear);
      });
      return {
        month,
        amount: monthCommissions.reduce((sum, c) => sum + c.myCommission, 0),
        deals: monthCommissions.length,
      };
    });
  }, [commissions, selectedYear]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return (
          <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
            <CheckCircle className="w-3 h-3 ml-1" />
            مدفوعة
          </Badge>
        );
      case 'approved':
        return (
          <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">
            <CheckCircle className="w-3 h-3 ml-1" />
            معتمدة
          </Badge>
        );
      case 'pending':
        return (
          <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">
            <Clock className="w-3 h-3 ml-1" />
            معلقة
          </Badge>
        );
      case 'cancelled':
        return (
          <Badge className="bg-red-100 text-red-700 hover:bg-red-100">
            <XCircle className="w-3 h-3 ml-1" />
            ملغاة
          </Badge>
        );
      default:
        return null;
    }
  };

  return (
    <>
      <Helmet>
        <title>عمولاتي | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">عمولاتي</h1>
            <p className="text-slate-500">تتبع عمولاتك والمدفوعات</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Download className="w-4 h-4 ml-2" />
              تصدير
            </Button>
            <Button variant="outline">
              <FileText className="w-4 h-4 ml-2" />
              تقرير
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-emerald-100 text-sm mb-1">إجمالي العمولات</p>
                  <p className="text-3xl font-bold">{formatCurrency(stats.total)}</p>
                </div>
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <DollarSign className="w-6 h-6" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-500 text-sm mb-1">المدفوعة</p>
                  <p className="text-2xl font-bold text-emerald-600">{formatCurrency(stats.paid)}</p>
                </div>
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-500 text-sm mb-1">المعلقة</p>
                  <p className="text-2xl font-bold text-amber-600">{formatCurrency(stats.pending)}</p>
                </div>
                <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
                  <Clock className="w-6 h-6 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-500 text-sm mb-1">عدد الصفقات</p>
                  <p className="text-2xl font-bold text-blue-600">{stats.totalDeals}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Home className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Monthly Chart */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">العمولات الشهرية</CardTitle>
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2024">2024</SelectItem>
                  <SelectItem value="2023">2023</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-end gap-2 h-48">
              {monthlyData.map((data, index) => (
                <div key={index} className="flex-1 flex flex-col items-center gap-1">
                  <div 
                    className="w-full bg-emerald-500 rounded-t-sm transition-all hover:bg-emerald-600 relative group"
                    style={{ 
                      height: `${Math.max((data.amount / Math.max(...monthlyData.map(d => d.amount))) * 100, 5)}%`,
                      minHeight: data.amount > 0 ? '20px' : '4px'
                    }}
                  >
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                      {formatCurrency(data.amount)}
                    </div>
                  </div>
                  <span className="text-xs text-slate-500">{data.month.slice(0, 3)}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Commissions List */}
        <Card>
          <CardHeader className="pb-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <CardTitle className="text-lg">سجل العمولات</CardTitle>
              
              <div className="flex flex-col md:flex-row gap-2">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    placeholder="البحث..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pr-10 w-full md:w-64"
                  />
                </div>
              </div>
            </div>

            <Tabs value={selectedTab} onValueChange={setSelectedTab} className="mt-4">
              <TabsList>
                <TabsTrigger value="all">الكل</TabsTrigger>
                <TabsTrigger value="paid">المدفوعة</TabsTrigger>
                <TabsTrigger value="pending">المعلقة</TabsTrigger>
                <TabsTrigger value="listing">عمولات إدراج</TabsTrigger>
                <TabsTrigger value="selling">عمولات بيع</TabsTrigger>
              </TabsList>
            </Tabs>
          </CardHeader>

          <CardContent>
            <div className="space-y-3">
              {filteredCommissions.length === 0 ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <DollarSign className="w-8 h-8 text-slate-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">لا توجد عمولات</h3>
                  <p className="text-slate-500">لم يتم العثور على عمولات في هذا القسم</p>
                </div>
              ) : (
                filteredCommissions.map((commission) => (
                  <div 
                    key={commission.id}
                    className="flex flex-col md:flex-row md:items-center gap-4 p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors"
                  >
                    {/* Deal Info */}
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-slate-900">{commission.dealNumber}</span>
                        {getStatusBadge(commission.status)}
                        <Badge variant="outline" className="text-xs">
                          {commission.commissionType}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-600 mb-1">
                        {commission.property?.titleAr}
                      </p>
                      <div className="flex items-center gap-4 text-xs text-slate-500">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {formatDate(commission.createdAt)}
                        </span>
                        <span className="flex items-center gap-1">
                          <Percent className="w-3 h-3" />
                          {commission.commissionRate}%
                        </span>
                      </div>
                    </div>

                    {/* Commission Amount */}
                    <div className="text-left md:text-right">
                      <p className="text-2xl font-bold text-emerald-600">
                        {formatCurrency(commission.myCommission)}
                      </p>
                      <p className="text-sm text-slate-500">
                        من إجمالي {formatCurrency(commission.totalCommission)}
                      </p>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm">
                        <FileText className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Commission Structure Info */}
        <Card className="bg-slate-50">
          <CardHeader>
            <CardTitle className="text-lg">هيكل العمولات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="p-4 bg-white rounded-lg">
                <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center mb-3">
                  <Percent className="w-5 h-5 text-emerald-600" />
                </div>
                <h4 className="font-semibold mb-1">نسبة العمولة</h4>
                <p className="text-sm text-slate-500">2.5% من قيمة الصفقة</p>
              </div>
              
              <div className="p-4 bg-white rounded-lg">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mb-3">
                  <ArrowUpRight className="w-5 h-5 text-blue-600" />
                </div>
                <h4 className="font-semibold mb-1">عمولة البيع</h4>
                <p className="text-sm text-slate-500">60% للوسيط البائع</p>
              </div>
              
              <div className="p-4 bg-white rounded-lg">
                <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center mb-3">
                  <Home className="w-5 h-5 text-amber-600" />
                </div>
                <h4 className="font-semibold mb-1">عمولة الإدراج</h4>
                <p className="text-sm text-slate-500">40% للوسيط المدرج</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
