import { Helmet } from 'react-helmet-async';
import { NavLink } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/useAuth';
import { 
  properties, 
  deals, 
  clientRequests,
  companies 
} from '@/data/mockData';
import {
  Home,
  DollarSign,
  Users,
  FileText,
  Plus,
  Eye,
  Phone,
  Mail,
  Building2,
  ArrowUpRight,
  CheckCircle2,
} from 'lucide-react';

export default function BrokerDashboard() {
  const { user } = useAuth();

  // Filter data for this broker only
  const brokerProperties = properties.filter(p => p.listedBy === user?.id);
  const brokerDeals = deals.filter(d => 
    d.commissions?.some(c => c.userId === user?.id)
  );
  const brokerRequests = clientRequests.filter(r => r.assignedTo === user?.id);
  
  // Get broker's company
  const brokerCompany = companies.find(c => c.id === user?.companyId);
  
  // Calculate stats
  const activeListings = brokerProperties.filter(p => p.status === 'active').length;
  const totalDeals = brokerDeals.length;
  const completedDeals = brokerDeals.filter(d => d.status === 'completed').length;
  const totalCommission = brokerDeals
    .filter(d => d.status === 'completed')
    .reduce((sum, d) => {
      const brokerCommission = d.commissions?.find(c => c.userId === user?.id);
      return sum + (brokerCommission?.amount || 0);
    }, 0);
  const pendingRequests = brokerRequests.filter(r => r.status === 'open' || r.status === 'in_progress').length;

  // Recent activity
  const recentProperties = brokerProperties
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const recentDeals = brokerDeals
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-emerald-100 text-emerald-700">نشط</Badge>;
      case 'reserved':
        return <Badge className="bg-amber-100 text-amber-700">محجوز</Badge>;
      case 'sold':
        return <Badge className="bg-blue-100 text-blue-700">مباع</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <>
      <Helmet>
        <title>لوحة تحكم الوسيط | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Welcome Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              مرحباً، {user?.fullName}
            </h1>
            <p className="text-slate-500 mt-1">
              {brokerCompany?.name || 'وسيط عقاري مستقل'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <NavLink to="/broker/properties/add">
              <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4" />
                إضافة عقار
              </Button>
            </NavLink>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إدراجاتي النشطة</p>
                  <p className="text-2xl font-bold text-slate-900">{activeListings}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Home className="w-5 h-5 text-blue-600" />
                </div>
              </div>
              <p className="text-xs text-slate-400 mt-2">
                من {brokerProperties.length} إدراج إجمالي
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">صفقاتي</p>
                  <p className="text-2xl font-bold text-emerald-600">{totalDeals}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                </div>
              </div>
              <p className="text-xs text-slate-400 mt-2">
                {completedDeals} مكتملة
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">عمولاتي</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {(totalCommission / 1000).toFixed(0)}K
                  </p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-purple-600" />
                </div>
              </div>
              <p className="text-xs text-slate-400 mt-2">
                ريال سعودي
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">طلباتي</p>
                  <p className="text-2xl font-bold text-amber-600">{pendingRequests}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                  <Users className="w-5 h-5 text-amber-600" />
                </div>
              </div>
              <p className="text-xs text-slate-400 mt-2">
                بانتظار المعالجة
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Recent Properties */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-semibold">عقاراتي الأخيرة</CardTitle>
              <NavLink to="/broker/properties">
                <Button variant="ghost" size="sm" className="gap-1">
                  عرض الكل
                  <ArrowUpRight className="w-4 h-4" />
                </Button>
              </NavLink>
            </CardHeader>
            <CardContent>
              {recentProperties.length > 0 ? (
                <div className="space-y-3">
                  {recentProperties.map((property) => (
                    <div 
                      key={property.id} 
                      className="flex items-center gap-4 p-3 rounded-lg hover:bg-slate-50 transition-colors border border-slate-100"
                    >
                      <div className="w-16 h-16 rounded-lg bg-slate-100 flex items-center justify-center flex-shrink-0">
                        {property.images?.[0] ? (
                          <img 
                            src={property.images[0].imageUrl} 
                            alt={property.titleAr}
                            className="w-full h-full object-cover rounded-lg"
                          />
                        ) : (
                          <Home className="w-6 h-6 text-slate-400" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-slate-900 truncate">{property.titleAr}</p>
                        <p className="text-sm text-slate-500">
                          {formatCurrency(property.price)}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusBadge(property.status)}
                        <NavLink to={`/broker/properties/${property.id}`}>
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </NavLink>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Home className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500">لا توجد عقارات مسجلة</p>
                  <NavLink to="/broker/properties/add">
                    <Button variant="outline" className="mt-3 gap-2">
                      <Plus className="w-4 h-4" />
                      إضافة عقار
                    </Button>
                  </NavLink>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Actions & Profile */}
          <div className="space-y-6">
            {/* Profile Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold">ملفي الشخصي</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-full bg-emerald-100 flex items-center justify-center">
                    {user?.avatarUrl ? (
                      <img 
                        src={user.avatarUrl} 
                        alt={user.fullName}
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <span className="text-xl font-bold text-emerald-700">
                        {user?.fullName?.charAt(0)}
                      </span>
                    )}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900">{user?.fullName}</p>
                    <p className="text-sm text-slate-500">وسيط عقاري</p>
                  </div>
                </div>
                
                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <span className="text-slate-600">{user?.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="w-4 h-4 text-slate-400" />
                    <span className="text-slate-600 ltr">{user?.phone}</span>
                  </div>
                  {brokerCompany && (
                    <div className="flex items-center gap-2 text-sm">
                      <Building2 className="w-4 h-4 text-slate-400" />
                      <span className="text-slate-600">{brokerCompany.name}</span>
                    </div>
                  )}
                </div>

                <NavLink to="/broker/profile">
                  <Button variant="outline" className="w-full gap-2">
                    <Eye className="w-4 h-4" />
                    تعديل الملف
                  </Button>
                </NavLink>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold">إجراءات سريعة</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <NavLink to="/broker/properties/add">
                  <Button variant="outline" className="w-full justify-start gap-2">
                    <Plus className="w-4 h-4" />
                    إضافة عقار جديد
                  </Button>
                </NavLink>
                <NavLink to="/broker/deals/add">
                  <Button variant="outline" className="w-full justify-start gap-2">
                    <FileText className="w-4 h-4" />
                    تسجيل صفقة
                  </Button>
                </NavLink>
                <NavLink to="/broker/requests">
                  <Button variant="outline" className="w-full justify-start gap-2">
                    <Users className="w-4 h-4" />
                    طلبات العملاء
                    {pendingRequests > 0 && (
                      <Badge variant="secondary" className="mr-auto">
                        {pendingRequests}
                      </Badge>
                    )}
                  </Button>
                </NavLink>
                <NavLink to="/broker/commissions">
                  <Button variant="outline" className="w-full justify-start gap-2">
                    <DollarSign className="w-4 h-4" />
                    عمولاتي
                  </Button>
                </NavLink>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Recent Deals */}
        {recentDeals.length > 0 && (
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-semibold">صفقاتي الأخيرة</CardTitle>
              <NavLink to="/broker/deals">
                <Button variant="ghost" size="sm" className="gap-1">
                  عرض الكل
                  <ArrowUpRight className="w-4 h-4" />
                </Button>
              </NavLink>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">رقم الصفقة</th>
                      <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">العقار</th>
                      <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">سعر البيع</th>
                      <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">عمولتي</th>
                      <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الحالة</th>
                      <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">التاريخ</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {recentDeals.slice(0, 5).map((deal) => {
                      const myCommission = deal.commissions?.find(c => c.userId === user?.id);
                      return (
                        <tr key={deal.id} className="hover:bg-slate-50">
                          <td className="px-4 py-3 text-sm font-medium">{deal.dealNumber}</td>
                          <td className="px-4 py-3 text-sm">
                            {properties.find(p => p.id === deal.propertyId)?.titleAr || 'غير معروف'}
                          </td>
                          <td className="px-4 py-3 text-sm text-center">{formatCurrency(deal.salePrice)}</td>
                          <td className="px-4 py-3 text-sm text-center text-emerald-600 font-medium">
                            {myCommission ? formatCurrency(myCommission.amount) : '-'}
                          </td>
                          <td className="px-4 py-3 text-center">
                            {deal.status === 'completed' ? (
                              <Badge className="bg-emerald-100 text-emerald-700">مكتملة</Badge>
                            ) : deal.status === 'pending' ? (
                              <Badge className="bg-amber-100 text-amber-700">بانتظار</Badge>
                            ) : (
                              <Badge variant="secondary">{deal.status}</Badge>
                            )}
                          </td>
                          <td className="px-4 py-3 text-sm text-center text-slate-500">
                            {new Date(deal.createdAt).toLocaleDateString('ar-SA')}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </>
  );
}
