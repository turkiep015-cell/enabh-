import { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { clientRequests, users, cities } from '@/data/mockData';
import type { ClientRequest } from '@/types';
import {
  Search,
  User,
  Phone,
  MapPin,
  Home,
  DollarSign,
  Bed,
  MessageSquare,
  CheckCircle,
  Clock,
  XCircle,
  Eye,
  Send,
  Tag
} from 'lucide-react';
import { formatCurrency, formatDate } from '@/lib/utils';

export default function BrokerClientRequests() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTab, setSelectedTab] = useState('open');
  const [selectedRequest, setSelectedRequest] = useState<ClientRequest | null>(null);
  const [responseDialogOpen, setResponseDialogOpen] = useState(false);
  const [responseText, setResponseText] = useState('');
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);

  // Filter requests assigned to current broker or open
  const myRequests = useMemo(() => {
    return clientRequests.filter(r => 
      r.assignedTo === user?.id || 
      r.status === 'open' ||
      r.status === 'in_progress'
    );
  }, [user?.id]);

  // Filter based on search and tab
  const filteredRequests = useMemo(() => {
    let filtered = myRequests;

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(r => 
        r.requestNumber.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Tab filter
    switch (selectedTab) {
      case 'open':
        filtered = filtered.filter(r => r.status === 'open');
        break;
      case 'assigned':
        filtered = filtered.filter(r => r.assignedTo === user?.id && r.status === 'in_progress');
        break;
      case 'completed':
        filtered = filtered.filter(r => r.status === 'in_progress');
        break;
      case 'closed':
        filtered = filtered.filter(r => r.status === 'cancelled');
        break;
    }

    return filtered;
  }, [myRequests, searchQuery, selectedTab, user?.id]);

  // Stats
  const stats = useMemo(() => ({
    open: myRequests.filter(r => r.status === 'open').length,
    assigned: myRequests.filter(r => r.assignedTo === user?.id && r.status === 'in_progress').length,
    completed: myRequests.filter(r => r.status === 'closed').length,
    total: myRequests.filter(r => r.assignedTo === user?.id).length,
  }), [myRequests, user?.id]);

  const handleAssign = (request: ClientRequest) => {
    toast({
      title: 'تم تعيين الطلب',
      description: `تم تعيين الطلب ${request.requestNumber} لك`,
    });
  };

  const handleResponse = (request: ClientRequest) => {
    setSelectedRequest(request);
    setResponseDialogOpen(true);
  };

  const sendResponse = () => {
    toast({
      title: 'تم إرسال الرد',
      description: 'تم إرسال ردك للعميل بنجاح',
    });
    setResponseDialogOpen(false);
    setResponseText('');
  };

  const handleViewDetails = (request: ClientRequest) => {
    setSelectedRequest(request);
    setDetailsDialogOpen(true);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return (
          <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">
            <Clock className="w-3 h-3 ml-1" />
            مفتوح
          </Badge>
        );
      case 'in_progress':
        return (
          <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">
            <Clock className="w-3 h-3 ml-1" />
            قيد التنفيذ
          </Badge>
        );
      case 'completed':
        return (
          <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
            <CheckCircle className="w-3 h-3 ml-1" />
            مكتمل
          </Badge>
        );
      case 'closed':
        return (
          <Badge className="bg-slate-100 text-slate-700 hover:bg-slate-100">
            <XCircle className="w-3 h-3 ml-1" />
            مغلق
          </Badge>
        );
      default:
        return null;
    }
  };

  const getRequestTypeLabel = (type: string) => {
    switch (type) {
      case 'buy': return 'شراء';
      case 'rent': return 'إيجار';
      case 'invest': return 'استثمار';
      default: return type;
    }
  };

  const getClientName = (clientId?: string) => {
    if (!clientId) return 'غير معروف';
    const client = users.find(u => u.id === clientId);
    return client?.fullName || 'غير معروف';
  };

  const getCityName = (cityId?: string) => {
    if (!cityId) return 'غير محدد';
    const city = cities.find(c => c.id === cityId);
    return city?.nameAr || 'غير محدد';
  };

  const RequestCard = ({ request }: { request: ClientRequest }) => (
    <Card className="hover:shadow-md transition-all">
      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-semibold text-slate-900">{request.requestNumber}</span>
              {getStatusBadge(request.status)}
            </div>
            <p className="text-sm text-slate-500">
              {formatDate(request.createdAt)}
            </p>
          </div>
          <Badge variant="outline">
            {getRequestTypeLabel(request.requestType)}
          </Badge>
        </div>

        {/* Client Info */}
        <div className="flex items-center gap-3 mb-4 p-3 bg-slate-50 rounded-lg">
          <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
            <User className="w-5 h-5 text-emerald-600" />
          </div>
          <div>
            <p className="font-medium text-slate-900">{getClientName(request.clientId || '')}</p>
            <p className="text-sm text-slate-500">عميل</p>
          </div>
        </div>

        {/* Request Details */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="flex items-center gap-2 text-sm">
            <MapPin className="w-4 h-4 text-slate-400" />
            <span>{getCityName(request.cityId)}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <DollarSign className="w-4 h-4 text-slate-400" />
            <span>
              {request.budgetMin && request.budgetMax 
                ? `${formatCurrency(request.budgetMin)} - ${formatCurrency(request.budgetMax)}`
                : 'غير محدد'}
            </span>
          </div>
          {request.bedroomsMin && (
            <div className="flex items-center gap-2 text-sm">
              <Bed className="w-4 h-4 text-slate-400" />
              <span>{request.bedroomsMin} - {request.bedroomsMax} غرف</span>
            </div>
          )}
          {request.propertyTypeIds && (
            <div className="flex items-center gap-2 text-sm">
              <Home className="w-4 h-4 text-slate-400" />
              <span>{request.propertyTypeIds.length} أنواع عقارات</span>
            </div>
          )}
        </div>

        {/* Notes */}
        {request.notes && (
          <p className="text-sm text-slate-600 mb-4 line-clamp-2">
            <MessageSquare className="w-4 h-4 inline ml-1" />
            {request.notes}
          </p>
        )}

        {/* Actions */}
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1"
            onClick={() => handleViewDetails(request)}
          >
            <Eye className="w-4 h-4 ml-1" />
            التفاصيل
          </Button>
          
          {request.status === 'open' && (
            <Button 
              size="sm" 
              className="flex-1 bg-emerald-600 hover:bg-emerald-700"
              onClick={() => handleAssign(request)}
            >
              <CheckCircle className="w-4 h-4 ml-1" />
              قبول
            </Button>
          )}
          
          {request.assignedTo === user?.id && request.status === 'in_progress' && (
            <Button 
              size="sm" 
              className="flex-1 bg-blue-600 hover:bg-blue-700"
              onClick={() => handleResponse(request)}
            >
              <Send className="w-4 h-4 ml-1" />
              رد
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <>
      <Helmet>
        <title>طلبات العملاء | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-slate-900">طلبات العملاء</h1>
          <p className="text-slate-500">إدارة طلبات العملاء والرد عليها</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Clock className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">مفتوحة</p>
                  <p className="text-xl font-bold">{stats.open}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">معينة لي</p>
                  <p className="text-xl font-bold">{stats.assigned}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">مكتملة</p>
                  <p className="text-xl font-bold">{stats.completed}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <User className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">إجمالي طلباتي</p>
                  <p className="text-xl font-bold">{stats.total}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <Card>
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <Input
                placeholder="البحث في الطلبات..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Tabs & Content */}
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="open">مفتوحة ({stats.open})</TabsTrigger>
            <TabsTrigger value="assigned">معينة لي ({stats.assigned})</TabsTrigger>
            <TabsTrigger value="completed">مكتملة ({stats.completed})</TabsTrigger>
            <TabsTrigger value="closed">مغلقة</TabsTrigger>
          </TabsList>

          <TabsContent value={selectedTab}>
            {filteredRequests.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageSquare className="w-10 h-10 text-slate-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 mb-2">لا توجد طلبات</h3>
                <p className="text-slate-500">لم يتم العثور على طلبات في هذا القسم</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredRequests.map(request => (
                  <RequestCard key={request.id} request={request} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Response Dialog */}
        <Dialog open={responseDialogOpen} onOpenChange={setResponseDialogOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>الرد على الطلب</DialogTitle>
              <DialogDescription>
                أرسل رداً للعميل مع العقارات المناسبة
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div>
                <label className="text-sm font-medium mb-2 block">رسالتك</label>
                <Textarea
                  placeholder="اكتب ردك هنا..."
                  value={responseText}
                  onChange={(e) => setResponseText(e.target.value)}
                  className="min-h-[120px]"
                />
              </div>
              
              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-sm font-medium mb-2">يمكنك إرفاق:</p>
                <ul className="text-sm text-slate-600 space-y-1">
                  <li>• روابط العقارات المناسبة</li>
                  <li>• ملفات إضافية</li>
                  <li>• مواعيد للمعاينة</li>
                </ul>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setResponseDialogOpen(false)}>
                إلغاء
              </Button>
              <Button 
                onClick={sendResponse}
                className="bg-emerald-600 hover:bg-emerald-700"
                disabled={!responseText.trim()}
              >
                <Send className="w-4 h-4 ml-2" />
                إرسال
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Details Dialog */}
        <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>تفاصيل الطلب</DialogTitle>
            </DialogHeader>
            
            {selectedRequest && (
              <div className="space-y-6 py-4">
                {/* Request Header */}
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-2xl font-bold">{selectedRequest.requestNumber}</p>
                    <p className="text-slate-500">{formatDate(selectedRequest.createdAt)}</p>
                  </div>
                  {getStatusBadge(selectedRequest.status)}
                </div>

                {/* Client Info */}
                <div className="p-4 bg-slate-50 rounded-lg">
                  <h4 className="font-semibold mb-3">معلومات العميل</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="flex items-center gap-3">
                      <User className="w-5 h-5 text-slate-400" />
                      <span>{getClientName(selectedRequest.clientId || '')}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Phone className="w-5 h-5 text-slate-400" />
                      <span>+966 50 123 4567</span>
                    </div>
                  </div>
                </div>

                {/* Request Details */}
                <div>
                  <h4 className="font-semibold mb-3">تفاصيل الطلب</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="flex items-center gap-3">
                      <Tag className="w-5 h-5 text-slate-400" />
                      <span>النوع: {getRequestTypeLabel(selectedRequest.requestType)}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <MapPin className="w-5 h-5 text-slate-400" />
                      <span>المدينة: {getCityName(selectedRequest.cityId)}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <DollarSign className="w-5 h-5 text-slate-400" />
                      <span>
                        الميزانية: {selectedRequest.budgetMin && selectedRequest.budgetMax 
                          ? `${formatCurrency(selectedRequest.budgetMin)} - ${formatCurrency(selectedRequest.budgetMax)}`
                          : 'غير محدد'}
                      </span>
                    </div>
                    {selectedRequest.bedroomsMin && (
                      <div className="flex items-center gap-3">
                        <Bed className="w-5 h-5 text-slate-400" />
                        <span>الغرف: {selectedRequest.bedroomsMin} - {selectedRequest.bedroomsMax}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Notes */}
                {selectedRequest.notes && (
                  <div>
                    <h4 className="font-semibold mb-2">ملاحظات</h4>
                    <p className="text-slate-600 p-4 bg-slate-50 rounded-lg">
                      {selectedRequest.notes}
                    </p>
                  </div>
                )}
              </div>
            )}

            <DialogFooter>
              <Button variant="outline" onClick={() => setDetailsDialogOpen(false)}>
                إغلاق
              </Button>
              {selectedRequest?.status === 'open' && (
                <Button 
                  className="bg-emerald-600 hover:bg-emerald-700"
                  onClick={() => {
                    setDetailsDialogOpen(false);
                    handleAssign(selectedRequest);
                  }}
                >
                  <CheckCircle className="w-4 h-4 ml-2" />
                  قبول الطلب
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}
