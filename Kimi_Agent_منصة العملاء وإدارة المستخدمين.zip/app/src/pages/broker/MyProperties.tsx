import { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { properties } from '@/data/mockData';
import type { Property } from '@/types';
import {
  Plus,
  Search,
  MoreVertical,
  Edit,
  Eye,
  Star,
  Trash2,
  MapPin,
  Bed,
  Bath,
  Maximize,
  CheckCircle,
  Clock,
  XCircle,
  TrendingUp,
  Home
} from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

export default function MyProperties() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTab, setSelectedTab] = useState('all');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [propertyToDelete, setPropertyToDelete] = useState<Property | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Filter properties for current broker
  const myProperties = useMemo(() => {
    return properties.filter(p => p.listedBy === user?.id);
  }, [user?.id]);

  // Filter based on search and tab
  const filteredProperties = useMemo(() => {
    let filtered = myProperties;

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(p => 
        p.titleAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.city.nameAr.includes(searchQuery) ||
        (p.address && p.address.includes(searchQuery))
      );
    }

    // Tab filter
    switch (selectedTab) {
      case 'active':
        filtered = filtered.filter(p => p.status === 'active');
        break;
      case 'pending':
        filtered = filtered.filter(p => !p.isApproved);
        break;
      case 'featured':
        filtered = filtered.filter(p => p.isFeatured);
        break;
      case 'sold':
        filtered = filtered.filter(p => p.status === 'sold');
        break;
      case 'reserved':
        filtered = filtered.filter(p => p.status === 'reserved');
        break;
    }

    return filtered;
  }, [myProperties, searchQuery, selectedTab]);

  const stats = useMemo(() => ({
    total: myProperties.length,
    active: myProperties.filter(p => p.status === 'active').length,
    pending: myProperties.filter(p => !p.isApproved).length,
    featured: myProperties.filter(p => p.isFeatured).length,
    sold: myProperties.filter(p => p.status === 'sold').length,
    totalViews: myProperties.reduce((sum, p) => sum + p.viewCount, 0),
    totalInquiries: myProperties.reduce((sum, p) => sum + p.inquiryCount, 0),
  }), [myProperties]);

  const handleDelete = (property: Property) => {
    setPropertyToDelete(property);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    toast({
      title: 'تم حذف العقار',
      description: 'تم حذف العقار بنجاح',
    });
    setDeleteDialogOpen(false);
    setPropertyToDelete(null);
  };

  const handleToggleFeatured = (property: Property) => {
    toast({
      title: property.isFeatured ? 'تم إزالة التمييز' : 'تم تمييز العقار',
      description: property.isFeatured 
        ? 'تم إزالة العقار من القائمة المميزة'
        : 'تمت إضافة العقار إلى القائمة المميزة',
    });
  };

  const getStatusBadge = (property: Property) => {
    if (!property.isApproved) {
      return (
        <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
          <Clock className="w-3 h-3 ml-1" />
          بانتظار الموافقة
        </Badge>
      );
    }
    
    switch (property.status) {
      case 'active':
        return (
          <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">
            <CheckCircle className="w-3 h-3 ml-1" />
            نشط
          </Badge>
        );
      case 'sold':
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            <CheckCircle className="w-3 h-3 ml-1" />
            مباع
          </Badge>
        );
      case 'reserved':
        return (
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
            <Clock className="w-3 h-3 ml-1" />
            محجوز
          </Badge>
        );
      case 'inactive':
        return (
          <Badge variant="outline" className="bg-slate-50 text-slate-700 border-slate-200">
            <XCircle className="w-3 h-3 ml-1" />
            غير نشط
          </Badge>
        );
      default:
        return null;
    }
  };

  const PropertyCard = ({ property }: { property: Property }) => (
    <Card className="group overflow-hidden hover:shadow-lg transition-all">
      {/* Image */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={property.images?.[0]?.imageUrl || 'https://via.placeholder.com/400x300'}
          alt={property.titleAr}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        
        {/* Status Badge */}
        <div className="absolute top-3 left-3">
          {getStatusBadge(property)}
        </div>

        {/* Featured Badge */}
        {property.isFeatured && (
          <div className="absolute top-3 right-3">
            <Badge className="bg-amber-500 text-white">
              <Star className="w-3 h-3 ml-1 fill-current" />
              مميز
            </Badge>
          </div>
        )}

        {/* Actions */}
        <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="secondary" size="icon" className="h-8 w-8">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => navigate(`/broker/properties/${property.id}`)}>
                <Eye className="w-4 h-4 ml-2" />
                عرض التفاصيل
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`/broker/properties/edit/${property.id}`)}>
                <Edit className="w-4 h-4 ml-2" />
                تعديل
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleToggleFeatured(property)}>
                <Star className="w-4 h-4 ml-2" />
                {property.isFeatured ? 'إزالة التمييز' : 'تمييز'}
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => handleDelete(property)}
                className="text-red-600"
              >
                <Trash2 className="w-4 h-4 ml-2" />
                حذف
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Content */}
      <CardContent className="p-4">
        <h3 className="font-semibold text-slate-900 mb-1 line-clamp-1">{property.titleAr}</h3>
        
        <div className="flex items-center gap-1 text-slate-500 text-sm mb-3">
          <MapPin className="w-4 h-4" />
          <span className="line-clamp-1">{property.city.nameAr}، {property.address}</span>
        </div>

        <div className="flex items-center gap-4 text-sm text-slate-600 mb-3">
          {property.bedrooms && (
            <div className="flex items-center gap-1">
              <Bed className="w-4 h-4" />
              <span>{property.bedrooms}</span>
            </div>
          )}
          {property.bathrooms && (
            <div className="flex items-center gap-1">
              <Bath className="w-4 h-4" />
              <span>{property.bathrooms}</span>
            </div>
          )}
          <div className="flex items-center gap-1">
            <Maximize className="w-4 h-4" />
            <span>{property.area} م²</span>
          </div>
        </div>

        <div className="flex items-center justify-between pt-3 border-t">
          <div className="font-bold text-emerald-600 text-lg">
            {formatCurrency(property.price)}
          </div>
          <div className="flex items-center gap-3 text-xs text-slate-500">
            <span className="flex items-center gap-1">
              <Eye className="w-3 h-3" />
              {property.viewCount}
            </span>
            <span className="flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              {property.inquiryCount}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const PropertyRow = ({ property }: { property: Property }) => (
    <div className="flex items-center gap-4 p-4 bg-white rounded-lg border hover:shadow-md transition-all">
      <img
        src={property.images?.[0]?.imageUrl || 'https://via.placeholder.com/100'}
        alt={property.titleAr}
        className="w-24 h-24 object-cover rounded-lg"
      />
      
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-semibold text-slate-900 mb-1">{property.titleAr}</h3>
            <div className="flex items-center gap-1 text-slate-500 text-sm mb-2">
              <MapPin className="w-4 h-4" />
              <span>{property.city.nameAr}، {property.address}</span>
            </div>
            <div className="flex items-center gap-2">
              {getStatusBadge(property)}
              {property.isFeatured && (
                <Badge className="bg-amber-500 text-white">
                  <Star className="w-3 h-3 ml-1 fill-current" />
                  مميز
                </Badge>
              )}
            </div>
          </div>
          
          <div className="text-left">
            <div className="font-bold text-emerald-600 text-lg">
              {formatCurrency(property.price)}
            </div>
            <div className="text-sm text-slate-500">{property.area} م²</div>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" onClick={() => navigate(`/broker/properties/${property.id}`)}>
          <Eye className="w-4 h-4" />
        </Button>
        <Button variant="ghost" size="icon" onClick={() => navigate(`/broker/properties/edit/${property.id}`)}>
          <Edit className="w-4 h-4" />
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => handleToggleFeatured(property)}>
              <Star className="w-4 h-4 ml-2" />
              {property.isFeatured ? 'إزالة التمييز' : 'تمييز'}
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => handleDelete(property)}
              className="text-red-600"
            >
              <Trash2 className="w-4 h-4 ml-2" />
              حذف
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );

  return (
    <>
      <Helmet>
        <title>عقاراتي | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">عقاراتي</h1>
            <p className="text-slate-500">إدارة جميع عقاراتك</p>
          </div>
          <Button 
            onClick={() => navigate('/broker/properties/add')}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            <Plus className="w-4 h-4 ml-2" />
            إضافة عقار
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                  <Home className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">الكل</p>
                  <p className="text-xl font-bold">{stats.total}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">نشط</p>
                  <p className="text-xl font-bold">{stats.active}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
                  <Clock className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">بانتظار الموافقة</p>
                  <p className="text-xl font-bold">{stats.pending}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-amber-500/20 rounded-lg flex items-center justify-center">
                  <Star className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">مميز</p>
                  <p className="text-xl font-bold">{stats.featured}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Eye className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">المشاهدات</p>
                  <p className="text-xl font-bold">{stats.totalViews.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">الاستفسارات</p>
                  <p className="text-xl font-bold">{stats.totalInquiries}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="البحث في العقارات..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10"
                />
              </div>
              
              <div className="flex gap-2">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'outline'}
                  size="icon"
                  onClick={() => setViewMode('grid')}
                  className={viewMode === 'grid' ? 'bg-emerald-600' : ''}
                >
                  <div className="grid grid-cols-2 gap-0.5 w-4 h-4">
                    <div className="bg-current rounded-sm" />
                    <div className="bg-current rounded-sm" />
                    <div className="bg-current rounded-sm" />
                    <div className="bg-current rounded-sm" />
                  </div>
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'outline'}
                  size="icon"
                  onClick={() => setViewMode('list')}
                  className={viewMode === 'list' ? 'bg-emerald-600' : ''}
                >
                  <div className="flex flex-col gap-0.5 w-4">
                    <div className="h-0.5 bg-current rounded-full" />
                    <div className="h-0.5 bg-current rounded-full" />
                    <div className="h-0.5 bg-current rounded-full" />
                  </div>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs & Content */}
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="all">الكل ({stats.total})</TabsTrigger>
            <TabsTrigger value="active">نشط ({stats.active})</TabsTrigger>
            <TabsTrigger value="pending">بانتظار الموافقة ({stats.pending})</TabsTrigger>
            <TabsTrigger value="featured">مميز ({stats.featured})</TabsTrigger>
            <TabsTrigger value="sold">مباع ({stats.sold})</TabsTrigger>
          </TabsList>

          <TabsContent value={selectedTab}>
            {filteredProperties.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Home className="w-10 h-10 text-slate-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 mb-2">لا توجد عقارات</h3>
                <p className="text-slate-500 mb-4">لم يتم العثور على عقارات في هذا القسم</p>
                <Button 
                  onClick={() => navigate('/broker/properties/add')}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  <Plus className="w-4 h-4 ml-2" />
                  إضافة عقار جديد
                </Button>
              </div>
            ) : (
              <>
                {viewMode === 'grid' ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filteredProperties.map(property => (
                      <PropertyCard key={property.id} property={property} />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-3">
                    {filteredProperties.map(property => (
                      <PropertyRow key={property.id} property={property} />
                    ))}
                  </div>
                )}
              </>
            )}
          </TabsContent>
        </Tabs>

        {/* Delete Dialog */}
        <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>حذف العقار</DialogTitle>
              <DialogDescription>
                هل أنت متأكد من حذف هذا العقار؟ لا يمكن التراجع عن هذا الإجراء.
              </DialogDescription>
            </DialogHeader>
            {propertyToDelete && (
              <div className="py-4">
                <p className="font-medium">{propertyToDelete.titleAr}</p>
                <p className="text-sm text-slate-500">{propertyToDelete.city.nameAr}</p>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
                إلغاء
              </Button>
              <Button variant="destructive" onClick={confirmDelete}>
                <Trash2 className="w-4 h-4 ml-2" />
                حذف
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}
