import { useState, useRef } from 'react';
import { Helmet } from 'react-helmet-async';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import {
  Palette, Image, Building2, Save, Upload, Check, Globe, Mail, Phone,
  RefreshCw, Shield, Lock, Users, DollarSign, Bell, Code, Search, AlertTriangle,
  RotateCcw, Settings2, Languages, Eye, EyeOff, Copy, Moon
} from 'lucide-react';

// أنظمة الألوان
const colorThemes = [
  { id: 'emerald', name: 'أخضر زمردي', primary: '#059669', secondary: '#10b981' },
  { id: 'blue', name: 'أزرق ملكي', primary: '#2563eb', secondary: '#3b82f6' },
  { id: 'indigo', name: 'نيلي', primary: '#4f46e5', secondary: '#6366f1' },
  { id: 'violet', name: 'بنفسجي', primary: '#7c3aed', secondary: '#8b5cf6' },
  { id: 'rose', name: 'وردي', primary: '#e11d48', secondary: '#f43f5e' },
  { id: 'orange', name: 'برتقالي', primary: '#ea580c', secondary: '#f97316' },
  { id: 'amber', name: 'ذهبي', primary: '#d97706', secondary: '#f59e0b' },
  { id: 'teal', name: 'فيروزي', primary: '#0d9488', secondary: '#14b8a6' },
];

// العملات
const currencies = [
  { id: 'SAR', name: 'ريال سعودي', symbol: 'ر.س' },
  { id: 'AED', name: 'درهم إماراتي', symbol: 'د.إ' },
  { id: 'KWD', name: 'دينار كويتي', symbol: 'د.ك' },
  { id: 'QAR', name: 'ريال قطري', symbol: 'ر.ق' },
  { id: 'USD', name: 'دولار أمريكي', symbol: '$' },
];

export default function AdminSettings() {
  const { toast } = useToast();
  const logoInputRef = useRef<HTMLInputElement>(null);
  const faviconInputRef = useRef<HTMLInputElement>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);
  const [activeTab, setActiveTab] = useState('general');

  // الإعدادات العامة
  const [generalSettings, setGeneralSettings] = useState({
    platformName: 'إنابة المستقبل',
    platformNameEn: 'Inabah Future',
    platformDescription: 'منصة العقارات الرائدة في المملكة العربية السعودية',
    contactEmail: 'info@inabah.sa',
    supportEmail: 'support@inabah.sa',
    contactPhone: '+966 50 123 4567',
    whatsappNumber: '+966 50 123 4567',
    address: 'الرياض، المملكة العربية السعودية',
    defaultLanguage: 'ar',
    defaultCurrency: 'SAR',
    timezone: 'Asia/Riyadh',
    logo: null as string | null,
    favicon: null as string | null,
  });

  // إعدادات المظهر
  const [appearanceSettings, setAppearanceSettings] = useState({
    theme: 'emerald',
    darkMode: false,
    rtl: true,
  });

  // إعدادات الأمان
  const [securitySettings, setSecuritySettings] = useState({
    twoFactorAuth: false,
    loginAttempts: 5,
    lockoutDuration: 30,
    passwordMinLength: 8,
    passwordRequireUppercase: true,
    passwordRequireNumbers: true,
    passwordRequireSymbols: true,
    emailVerificationRequired: true,
    phoneVerificationRequired: false,
  });

  // إعدادات الميزات
  const [featureSettings, setFeatureSettings] = useState({
    enableRegistration: true,
    enablePropertySubmission: true,
    enablePropertyApproval: true,
    enableDeals: true,
    enableCommissions: true,
    enableMap: true,
    enableChat: false,
    enableEmailNotifications: true,
    enableSMSNotifications: false,
    enableWhatsAppNotifications: false,
    maintenanceMode: false,
    maintenanceMessage: 'المنصة قيد الصيانة، نعتذر عن الإزعاج',
  });

  // إعدادات العمولات
  const [commissionSettings, setCommissionSettings] = useState({
    commissionEnabled: true,
    defaultCommissionRate: 2.5,
    listingAgentShare: 40,
    sellingAgentShare: 60,
    vatEnabled: true,
    vatRate: 15,
    commissionPaymentDays: 14,
    minPayoutAmount: 1000,
  });

  // إعدادات العقارات
  const [propertySettings, setPropertySettings] = useState({
    maxImagesPerProperty: 20,
    maxImageSize: 10,
    requireApproval: true,
    featuredPropertiesLimit: 10,
    featuredPropertyPrice: 500,
    propertyExpiryDays: 90,
  });

  // إعدادات البريد
  const [emailSettings, setEmailSettings] = useState({
    smtpHost: 'smtp.gmail.com',
    smtpPort: 587,
    smtpUsername: '',
    smtpPassword: '',
    fromName: 'إنابة المستقبل',
    fromEmail: 'noreply@inabah.sa',
  });

  // إعدادات SEO
  const [seoSettings, setSeoSettings] = useState({
    metaTitle: 'إنابة المستقبل - منصة العقارات الرائدة',
    metaDescription: 'منصة إنابة المستقبل للعقارات في السعودية',
    metaKeywords: 'عقارات, سعودية, بيع, شراء, إيجار',
    googleAnalyticsId: '',
  });

  // إعدادات API
  const [apiSettings, setApiSettings] = useState({
    apiEnabled: true,
    apiKey: 'sk_live_' + Math.random().toString(36).substring(2, 15),
    mapProvider: 'google',
    mapApiKey: '',
  });

  const handleSave = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    toast({ title: '✅ تم الحفظ بنجاح', description: 'تم حفظ جميع إعدادات المنصة' });
    setHasChanges(false);
    setIsLoading(false);
  };

  const handleReset = () => {
    setShowResetDialog(true);
  };

  const confirmReset = () => {
    toast({ title: 'تمت إعادة الضبط', description: 'تم إعادة الإعدادات الافتراضية' });
    setShowResetDialog(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'logo' | 'favicon') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setGeneralSettings({ ...generalSettings, [type]: reader.result as string });
        setHasChanges(true);
        toast({ title: 'تم رفع الصورة', description: `تم رفع ${type === 'logo' ? 'الشعار' : 'الأيقونة'}` });
      };
      reader.readAsDataURL(file);
    }
  };

  const generateApiKey = () => {
    const key = 'sk_live_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    setApiSettings({ ...apiSettings, apiKey: key });
    setHasChanges(true);
    toast({ title: 'تم إنشاء مفتاح جديد', description: 'تم إنشاء مفتاح API جديد' });
  };

  const copyApiKey = () => {
    navigator.clipboard.writeText(apiSettings.apiKey);
    toast({ title: 'تم النسخ', description: 'تم نسخ مفتاح API' });
  };

  const selectedTheme = colorThemes.find(t => t.id === appearanceSettings.theme) || colorThemes[0];

  return (
    <>
      <Helmet><title>إعدادات المنصة | {generalSettings.platformName}</title></Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">إعدادات المنصة</h1>
            <p className="text-slate-500">إدارة وتخصيص جميع إعدادات المنصة</p>
          </div>
          <div className="flex gap-2">
            {hasChanges && (
              <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                <AlertTriangle className="w-3 h-3 ml-1" />
                تغييرات غير محفوظة
              </Badge>
            )}
            <Button variant="outline" onClick={handleReset}><RotateCcw className="w-4 h-4 ml-2" />إعادة ضبط</Button>
            <Button onClick={handleSave} disabled={isLoading} className="bg-emerald-600 hover:bg-emerald-700">
              {isLoading ? <><RefreshCw className="w-4 h-4 ml-2 animate-spin" />جاري الحفظ...</> : <><Save className="w-4 h-4 ml-2" />حفظ التغييرات</>}
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="flex flex-wrap h-auto gap-1 p-1">
            <TabsTrigger value="general" className="gap-2"><Building2 className="w-4 h-4" /><span className="hidden sm:inline">عام</span></TabsTrigger>
            <TabsTrigger value="appearance" className="gap-2"><Palette className="w-4 h-4" /><span className="hidden sm:inline">المظهر</span></TabsTrigger>
            <TabsTrigger value="security" className="gap-2"><Shield className="w-4 h-4" /><span className="hidden sm:inline">الأمان</span></TabsTrigger>
            <TabsTrigger value="features" className="gap-2"><Settings2 className="w-4 h-4" /><span className="hidden sm:inline">الميزات</span></TabsTrigger>
            <TabsTrigger value="commissions" className="gap-2"><DollarSign className="w-4 h-4" /><span className="hidden sm:inline">العمولات</span></TabsTrigger>
            <TabsTrigger value="properties" className="gap-2"><Building2 className="w-4 h-4" /><span className="hidden sm:inline">العقارات</span></TabsTrigger>
            <TabsTrigger value="email" className="gap-2"><Mail className="w-4 h-4" /><span className="hidden sm:inline">البريد</span></TabsTrigger>
            <TabsTrigger value="seo" className="gap-2"><Search className="w-4 h-4" /><span className="hidden sm:inline">SEO</span></TabsTrigger>
            <TabsTrigger value="api" className="gap-2"><Code className="w-4 h-4" /><span className="hidden sm:inline">API</span></TabsTrigger>
          </TabsList>

          {/* GENERAL */}
          <TabsContent value="general" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Building2 className="w-5 h-5 text-emerald-600" />معلومات المنصة</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>اسم المنصة (عربي)</Label>
                    <Input value={generalSettings.platformName} onChange={(e) => { setGeneralSettings({ ...generalSettings, platformName: e.target.value }); setHasChanges(true); }} className="mt-1" />
                  </div>
                  <div>
                    <Label>اسم المنصة (إنجليزي)</Label>
                    <Input value={generalSettings.platformNameEn} onChange={(e) => { setGeneralSettings({ ...generalSettings, platformNameEn: e.target.value }); setHasChanges(true); }} className="mt-1" dir="ltr" />
                  </div>
                </div>
                <div>
                  <Label>وصف المنصة</Label>
                  <textarea value={generalSettings.platformDescription} onChange={(e) => { setGeneralSettings({ ...generalSettings, platformDescription: e.target.value }); setHasChanges(true); }} className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-lg min-h-[80px]" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Globe className="w-5 h-5 text-emerald-600" />الإعدادات الإقليمية</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <Label>اللغة الافتراضية</Label>
                    <Select value={generalSettings.defaultLanguage} onValueChange={(v) => { setGeneralSettings({ ...generalSettings, defaultLanguage: v }); setHasChanges(true); }}>
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ar">العربية</SelectItem>
                        <SelectItem value="en">English</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>العملة الافتراضية</Label>
                    <Select value={generalSettings.defaultCurrency} onValueChange={(v) => { setGeneralSettings({ ...generalSettings, defaultCurrency: v }); setHasChanges(true); }}>
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {currencies.map(c => <SelectItem key={c.id} value={c.id}>{c.name} ({c.symbol})</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>المنطقة الزمنية</Label>
                    <Select value={generalSettings.timezone} onValueChange={(v) => { setGeneralSettings({ ...generalSettings, timezone: v }); setHasChanges(true); }}>
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Asia/Riyadh">الرياض (GMT+3)</SelectItem>
                        <SelectItem value="Asia/Dubai">دبي (GMT+4)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Phone className="w-5 h-5 text-emerald-600" />بيانات التواصل</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div><Label>البريد الإلكتروني</Label><Input value={generalSettings.contactEmail} onChange={(e) => { setGeneralSettings({ ...generalSettings, contactEmail: e.target.value }); setHasChanges(true); }} className="mt-1" dir="ltr" /></div>
                  <div><Label>بريد الدعم</Label><Input value={generalSettings.supportEmail} onChange={(e) => { setGeneralSettings({ ...generalSettings, supportEmail: e.target.value }); setHasChanges(true); }} className="mt-1" dir="ltr" /></div>
                  <div><Label>رقم الهاتف</Label><Input value={generalSettings.contactPhone} onChange={(e) => { setGeneralSettings({ ...generalSettings, contactPhone: e.target.value }); setHasChanges(true); }} className="mt-1" dir="ltr" /></div>
                  <div><Label>رقم الواتساب</Label><Input value={generalSettings.whatsappNumber} onChange={(e) => { setGeneralSettings({ ...generalSettings, whatsappNumber: e.target.value }); setHasChanges(true); }} className="mt-1" dir="ltr" /></div>
                </div>
                <div><Label>العنوان</Label><Input value={generalSettings.address} onChange={(e) => { setGeneralSettings({ ...generalSettings, address: e.target.value }); setHasChanges(true); }} className="mt-1" /></div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* APPEARANCE */}
          <TabsContent value="appearance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Palette className="w-5 h-5 text-emerald-600" />نظام الألوان</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {colorThemes.map((theme) => (
                    <button key={theme.id} onClick={() => { setAppearanceSettings({ ...appearanceSettings, theme: theme.id }); setHasChanges(true); }} className={`p-3 rounded-xl border-2 transition-all text-right ${appearanceSettings.theme === theme.id ? 'border-slate-900 ring-2 ring-offset-2' : 'border-slate-200 hover:border-slate-300'}`} style={{ borderColor: appearanceSettings.theme === theme.id ? theme.primary : undefined }}>
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 rounded-lg" style={{ backgroundColor: theme.primary }} />
                        <div className="w-5 h-5 rounded" style={{ backgroundColor: theme.secondary }} />
                      </div>
                      <p className="text-sm font-medium">{theme.name}</p>
                      {appearanceSettings.theme === theme.id && <div className="flex items-center gap-1 mt-1 text-emerald-600 text-xs"><Check className="w-3 h-3" /><span>مختار</span></div>}
                    </button>
                  ))}
                </div>
                <div className="mt-6 p-4 bg-slate-50 rounded-xl">
                  <h4 className="font-medium mb-3">معاينة</h4>
                  <div className="flex flex-wrap gap-2">
                    <button className="px-4 py-2 rounded-lg text-white text-sm font-medium" style={{ backgroundColor: selectedTheme.primary }}>زر رئيسي</button>
                    <button className="px-4 py-2 rounded-lg text-white text-sm font-medium" style={{ backgroundColor: selectedTheme.secondary }}>زر ثانوي</button>
                    <span className="px-3 py-2 rounded-full text-white text-xs font-medium" style={{ backgroundColor: selectedTheme.primary }}>شارة</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader><CardTitle className="flex items-center gap-2"><Moon className="w-5 h-5 text-emerald-600" />الوضع الليلي</CardTitle></CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div><p className="font-medium">تفعيل الوضع الليلي</p><p className="text-sm text-slate-500">تفعيل المظهر الداكن</p></div>
                    <Switch checked={appearanceSettings.darkMode} onCheckedChange={(checked) => { setAppearanceSettings({ ...appearanceSettings, darkMode: checked }); setHasChanges(true); }} />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader><CardTitle className="flex items-center gap-2"><Languages className="w-5 h-5 text-emerald-600" />اتجاه النص</CardTitle></CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div><p className="font-medium">RTL (من اليمين لليسار)</p><p className="text-sm text-slate-500">تفعيل الاتجاه العربي</p></div>
                    <Switch checked={appearanceSettings.rtl} onCheckedChange={(checked) => { setAppearanceSettings({ ...appearanceSettings, rtl: checked }); setHasChanges(true); }} />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Image className="w-5 h-5 text-emerald-600" />الهوية البصرية</CardTitle></CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label className="mb-3 block">شعار المنصة</Label>
                  <div className="flex items-center gap-4">
                    <div className="w-24 h-24 bg-slate-100 rounded-xl flex items-center justify-center overflow-hidden border-2 border-dashed border-slate-300">
                      {generalSettings.logo ? <img src={generalSettings.logo} alt="الشعار" className="w-full h-full object-contain p-2" /> : <Image className="w-8 h-8 text-slate-400" />}
                    </div>
                    <div className="space-y-2">
                      <Button variant="outline" size="sm" onClick={() => logoInputRef.current?.click()}><Upload className="w-4 h-4 ml-2" />رفع شعار</Button>
                      <input ref={logoInputRef} type="file" accept="image/*" onChange={(e) => handleImageUpload(e, 'logo')} className="hidden" />
                      <p className="text-xs text-slate-500">المقاس المثالي: 512×512 بكسل</p>
                    </div>
                  </div>
                </div>
                <Separator />
                <div>
                  <Label className="mb-3 block">أيقونة المتصفح</Label>
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-slate-100 rounded-lg flex items-center justify-center overflow-hidden border-2 border-dashed border-slate-300">
                      {generalSettings.favicon ? <img src={generalSettings.favicon} alt="Favicon" className="w-full h-full object-contain p-1" /> : <Globe className="w-6 h-6 text-slate-400" />}
                    </div>
                    <div className="space-y-2">
                      <Button variant="outline" size="sm" onClick={() => faviconInputRef.current?.click()}><Upload className="w-4 h-4 ml-2" />رفع أيقونة</Button>
                      <input ref={faviconInputRef} type="file" accept="image/*" onChange={(e) => handleImageUpload(e, 'favicon')} className="hidden" />
                      <p className="text-xs text-slate-500">المقاس المثالي: 32×32 بكسل</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* SECURITY */}
          <TabsContent value="security" className="space-y-6">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Lock className="w-5 h-5 text-emerald-600" />إعدادات كلمة المرور</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>الحد الأدنى لطول كلمة المرور</Label>
                    <div className="flex items-center gap-3 mt-1">
                      <Slider value={[securitySettings.passwordMinLength]} onValueChange={([v]) => { setSecuritySettings({ ...securitySettings, passwordMinLength: v }); setHasChanges(true); }} min={6} max={20} step={1} className="flex-1" />
                      <span className="w-8 text-center font-medium">{securitySettings.passwordMinLength}</span>
                    </div>
                  </div>
                  <div>
                    <Label>محاولات تسجيل الدخول</Label>
                    <Input type="number" value={securitySettings.loginAttempts} onChange={(e) => { setSecuritySettings({ ...securitySettings, loginAttempts: parseInt(e.target.value) }); setHasChanges(true); }} className="mt-1" />
                  </div>
                </div>
                <div className="space-y-3">
                  {[
                    { key: 'passwordRequireUppercase', label: 'حروف كبيرة', desc: 'إلزام بوجود حرف كبير' },
                    { key: 'passwordRequireNumbers', label: 'أرقام', desc: 'إلزام بوجود رقم' },
                    { key: 'passwordRequireSymbols', label: 'رموز خاصة', desc: 'إلزام بوجود رمز خاص' },
                  ].map((item) => (
                    <div key={item.key} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div><p className="font-medium">{item.label}</p><p className="text-sm text-slate-500">{item.desc}</p></div>
                      <Switch checked={securitySettings[item.key as keyof typeof securitySettings] as boolean} onCheckedChange={(checked) => { setSecuritySettings({ ...securitySettings, [item.key]: checked }); setHasChanges(true); }} />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Shield className="w-5 h-5 text-emerald-600" />التحقق والأمان</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {[
                  { key: 'twoFactorAuth', label: 'التحقق بخطوتين', desc: 'تفعيل 2FA للمستخدمين' },
                  { key: 'emailVerificationRequired', label: 'التحقق من البريد', desc: 'إلزام تأكيد البريد' },
                  { key: 'phoneVerificationRequired', label: 'التحقق من الجوال', desc: 'إلزام تأكيد الجوال' },
                ].map((item) => (
                  <div key={item.key} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div><p className="font-medium">{item.label}</p><p className="text-sm text-slate-500">{item.desc}</p></div>
                    <Switch checked={securitySettings[item.key as keyof typeof securitySettings] as boolean} onCheckedChange={(checked) => { setSecuritySettings({ ...securitySettings, [item.key]: checked }); setHasChanges(true); }} />
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* FEATURES */}
          <TabsContent value="features" className="space-y-6">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Users className="w-5 h-5 text-emerald-600" />المستخدمين</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div><p className="font-medium">التسجيل</p><p className="text-sm text-slate-500">السماح بالتسجيل</p></div>
                  <Switch checked={featureSettings.enableRegistration} onCheckedChange={(checked) => { setFeatureSettings({ ...featureSettings, enableRegistration: checked }); setHasChanges(true); }} />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Building2 className="w-5 h-5 text-emerald-600" />العقارات</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {[
                  { key: 'enablePropertySubmission', label: 'إضافة عقارات', desc: 'السماح بإضافة عقارات' },
                  { key: 'enablePropertyApproval', label: 'موافقة العقارات', desc: 'الموافقة قبل النشر' },
                  { key: 'enableMap', label: 'الخريطة', desc: 'عرض العقارات على الخريطة' },
                ].map((item) => (
                  <div key={item.key} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div><p className="font-medium">{item.label}</p><p className="text-sm text-slate-500">{item.desc}</p></div>
                    <Switch checked={featureSettings[item.key as keyof typeof featureSettings] as boolean} onCheckedChange={(checked) => { setFeatureSettings({ ...featureSettings, [item.key]: checked }); setHasChanges(true); }} />
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Bell className="w-5 h-5 text-emerald-600" />الإشعارات</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {[
                  { key: 'enableEmailNotifications', label: 'البريد', desc: 'إشعارات البريد' },
                  { key: 'enableSMSNotifications', label: 'SMS', desc: 'إشعارات الرسائل' },
                  { key: 'enableWhatsAppNotifications', label: 'واتساب', desc: 'إشعارات واتساب' },
                ].map((item) => (
                  <div key={item.key} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div><p className="font-medium">{item.label}</p><p className="text-sm text-slate-500">{item.desc}</p></div>
                    <Switch checked={featureSettings[item.key as keyof typeof featureSettings] as boolean} onCheckedChange={(checked) => { setFeatureSettings({ ...featureSettings, [item.key]: checked }); setHasChanges(true); }} />
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border-red-200">
              <CardHeader><CardTitle className="flex items-center gap-2 text-red-600"><AlertTriangle className="w-5 h-5" />وضع الصيانة</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
                  <div><p className="font-medium text-red-700">تفعيل وضع الصيانة</p><p className="text-sm text-red-500">إيقاف المنصة مؤقتاً</p></div>
                  <Switch checked={featureSettings.maintenanceMode} onCheckedChange={(checked) => { setFeatureSettings({ ...featureSettings, maintenanceMode: checked }); setHasChanges(true); }} />
                </div>
                {featureSettings.maintenanceMode && (
                  <div>
                    <Label className="text-red-600">رسالة الصيانة</Label>
                    <textarea value={featureSettings.maintenanceMessage} onChange={(e) => { setFeatureSettings({ ...featureSettings, maintenanceMessage: e.target.value }); setHasChanges(true); }} className="w-full mt-1 px-3 py-2 border border-red-200 rounded-lg min-h-[80px]" />
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* COMMISSIONS */}
          <TabsContent value="commissions" className="space-y-6">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><DollarSign className="w-5 h-5 text-emerald-600" />نسب العمولات</CardTitle></CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div><p className="font-medium">تفعيل نظام العمولات</p><p className="text-sm text-slate-500">تفعيل حساب العمولات</p></div>
                  <Switch checked={commissionSettings.commissionEnabled} onCheckedChange={(checked) => { setCommissionSettings({ ...commissionSettings, commissionEnabled: checked }); setHasChanges(true); }} />
                </div>
                <div>
                  <Label>نسبة العمولة الافتراضية (%)</Label>
                  <div className="flex items-center gap-3 mt-1">
                    <Slider value={[commissionSettings.defaultCommissionRate]} onValueChange={([v]) => { setCommissionSettings({ ...commissionSettings, defaultCommissionRate: v }); setHasChanges(true); }} min={0.5} max={10} step={0.5} className="flex-1" />
                    <span className="w-12 text-center font-medium">{commissionSettings.defaultCommissionRate}%</span>
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>نصيب وسيط الإدراج (%)</Label>
                    <div className="flex items-center gap-3 mt-1">
                      <Slider value={[commissionSettings.listingAgentShare]} onValueChange={([v]) => { setCommissionSettings({ ...commissionSettings, listingAgentShare: v }); setHasChanges(true); }} min={0} max={100} step={5} className="flex-1" />
                      <span className="w-12 text-center font-medium">{commissionSettings.listingAgentShare}%</span>
                    </div>
                  </div>
                  <div>
                    <Label>نصيب وسيط البيع (%)</Label>
                    <div className="flex items-center gap-3 mt-1">
                      <Slider value={[commissionSettings.sellingAgentShare]} onValueChange={([v]) => { setCommissionSettings({ ...commissionSettings, sellingAgentShare: v }); setHasChanges(true); }} min={0} max={100} step={5} className="flex-1" />
                      <span className="w-12 text-center font-medium">{commissionSettings.sellingAgentShare}%</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div><p className="font-medium">الضريبة المضافة (VAT)</p></div>
                  <div className="flex items-center gap-3">
                    {commissionSettings.vatEnabled && <Input type="number" value={commissionSettings.vatRate} onChange={(e) => { setCommissionSettings({ ...commissionSettings, vatRate: parseFloat(e.target.value) }); setHasChanges(true); }} className="w-20" />}
                    <Switch checked={commissionSettings.vatEnabled} onCheckedChange={(checked) => { setCommissionSettings({ ...commissionSettings, vatEnabled: checked }); setHasChanges(true); }} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* PROPERTIES */}
          <TabsContent value="properties" className="space-y-6">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Image className="w-5 h-5 text-emerald-600" />إعدادات الصور</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div><Label>الحد الأقصى للصور</Label><Input type="number" value={propertySettings.maxImagesPerProperty} onChange={(e) => { setPropertySettings({ ...propertySettings, maxImagesPerProperty: parseInt(e.target.value) }); setHasChanges(true); }} className="mt-1" /></div>
                  <div><Label>الحد الأقصى لحجم الصورة (ميجابايت)</Label><Input type="number" value={propertySettings.maxImageSize} onChange={(e) => { setPropertySettings({ ...propertySettings, maxImageSize: parseInt(e.target.value) }); setHasChanges(true); }} className="mt-1" /></div>
                </div>
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div><p className="font-medium">الموافقة على العقارات</p><p className="text-sm text-slate-500">الموافقة قبل النشر</p></div>
                  <Switch checked={propertySettings.requireApproval} onCheckedChange={(checked) => { setPropertySettings({ ...propertySettings, requireApproval: checked }); setHasChanges(true); }} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* EMAIL */}
          <TabsContent value="email" className="space-y-6">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Mail className="w-5 h-5 text-emerald-600" />إعدادات SMTP</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div><Label>SMTP Host</Label><Input value={emailSettings.smtpHost} onChange={(e) => { setEmailSettings({ ...emailSettings, smtpHost: e.target.value }); setHasChanges(true); }} className="mt-1" dir="ltr" /></div>
                  <div><Label>SMTP Port</Label><Input type="number" value={emailSettings.smtpPort} onChange={(e) => { setEmailSettings({ ...emailSettings, smtpPort: parseInt(e.target.value) }); setHasChanges(true); }} className="mt-1" /></div>
                  <div><Label>SMTP Username</Label><Input value={emailSettings.smtpUsername} onChange={(e) => { setEmailSettings({ ...emailSettings, smtpUsername: e.target.value }); setHasChanges(true); }} className="mt-1" dir="ltr" /></div>
                  <div><Label>SMTP Password</Label><Input type="password" value={emailSettings.smtpPassword} onChange={(e) => { setEmailSettings({ ...emailSettings, smtpPassword: e.target.value }); setHasChanges(true); }} className="mt-1" dir="ltr" /></div>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div><Label>From Name</Label><Input value={emailSettings.fromName} onChange={(e) => { setEmailSettings({ ...emailSettings, fromName: e.target.value }); setHasChanges(true); }} className="mt-1" /></div>
                  <div><Label>From Email</Label><Input value={emailSettings.fromEmail} onChange={(e) => { setEmailSettings({ ...emailSettings, fromEmail: e.target.value }); setHasChanges(true); }} className="mt-1" dir="ltr" /></div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* SEO */}
          <TabsContent value="seo" className="space-y-6">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Search className="w-5 h-5 text-emerald-600" />إعدادات SEO</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div><Label>Meta Title</Label><Input value={seoSettings.metaTitle} onChange={(e) => { setSeoSettings({ ...seoSettings, metaTitle: e.target.value }); setHasChanges(true); }} className="mt-1" /></div>
                <div><Label>Meta Description</Label><textarea value={seoSettings.metaDescription} onChange={(e) => { setSeoSettings({ ...seoSettings, metaDescription: e.target.value }); setHasChanges(true); }} className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-lg min-h-[80px]" /></div>
                <div><Label>Meta Keywords</Label><Input value={seoSettings.metaKeywords} onChange={(e) => { setSeoSettings({ ...seoSettings, metaKeywords: e.target.value }); setHasChanges(true); }} className="mt-1" /></div>
                <div><Label>Google Analytics ID</Label><Input value={seoSettings.googleAnalyticsId} onChange={(e) => { setSeoSettings({ ...seoSettings, googleAnalyticsId: e.target.value }); setHasChanges(true); }} className="mt-1" dir="ltr" placeholder="UA-XXXXXXXXX-X" /></div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* API */}
          <TabsContent value="api" className="space-y-6">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Code className="w-5 h-5 text-emerald-600" />إعدادات API</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div><p className="font-medium">تفعيل API</p><p className="text-sm text-slate-500">السماح بالوصول للـ API</p></div>
                  <Switch checked={apiSettings.apiEnabled} onCheckedChange={(checked) => { setApiSettings({ ...apiSettings, apiEnabled: checked }); setHasChanges(true); }} />
                </div>
                <div>
                  <Label>API Key</Label>
                  <div className="flex gap-2 mt-1">
                    <div className="relative flex-1">
                      <Input type={showApiKey ? 'text' : 'password'} value={apiSettings.apiKey} readOnly className="pr-10 font-mono" dir="ltr" />
                      <button onClick={() => setShowApiKey(!showApiKey)} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                        {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <Button variant="outline" onClick={copyApiKey}><Copy className="w-4 h-4" /></Button>
                    <Button variant="outline" onClick={generateApiKey}><RefreshCw className="w-4 h-4" /></Button>
                  </div>
                </div>
                <div>
                  <Label>Map Provider</Label>
                  <Select value={apiSettings.mapProvider} onValueChange={(v) => { setApiSettings({ ...apiSettings, mapProvider: v }); setHasChanges(true); }}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="google">Google Maps</SelectItem>
                      <SelectItem value="mapbox">Mapbox</SelectItem>
                      <SelectItem value="osm">OpenStreetMap</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Map API Key</Label>
                  <Input value={apiSettings.mapApiKey} onChange={(e) => { setApiSettings({ ...apiSettings, mapApiKey: e.target.value }); setHasChanges(true); }} className="mt-1" dir="ltr" />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Reset Dialog */}
        <Dialog open={showResetDialog} onOpenChange={setShowResetDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>إعادة ضبط الإعدادات</DialogTitle>
              <DialogDescription>هل أنت متأكد من إعادة جميع الإعدادات للقيم الافتراضية؟</DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowResetDialog(false)}>إلغاء</Button>
              <Button variant="destructive" onClick={confirmReset}><RotateCcw className="w-4 h-4 ml-2" />إعادة الضبط</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}
