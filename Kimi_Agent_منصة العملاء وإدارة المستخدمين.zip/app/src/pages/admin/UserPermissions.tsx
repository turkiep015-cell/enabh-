import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
// import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Search,
  Shield,
  User,
  Check,
  X,
  Unlock,
  Save,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Building2,
  Briefcase,
  Home,
  Users,
  UserCog,
  Ban,
  Power
} from 'lucide-react';

// أنواع المستخدمين
const userRoles = [
  { id: 'super_admin', name: 'مدير عام', color: 'bg-purple-100 text-purple-700', icon: Shield },
  { id: 'admin', name: 'مدير', color: 'bg-blue-100 text-blue-700', icon: UserCog },
  { id: 'broker', name: 'وسيط عقاري', color: 'bg-emerald-100 text-emerald-700', icon: Briefcase },
  { id: 'developer', name: 'مطور عقاري', color: 'bg-amber-100 text-amber-700', icon: Building2 },
  { id: 'owner', name: 'مالك عقار', color: 'bg-rose-100 text-rose-700', icon: Home },
  { id: 'client', name: 'عميل', color: 'bg-slate-100 text-slate-700', icon: Users },
];

// تعريف الصلاحيات حسب الوحدة
const permissionModules = [
  {
    id: 'dashboard',
    name: 'لوحة التحكم',
    icon: LayoutDashboardIcon,
    permissions: [
      { id: 'dashboard_view', name: 'عرض الإحصائيات', description: 'عرض الإحصائيات العامة والرسوم البيانية' },
      { id: 'dashboard_export', name: 'تصدير التقارير', description: 'تصدير التقارير والإحصائيات' },
    ]
  },
  {
    id: 'users',
    name: 'إدارة المستخدمين',
    icon: Users,
    permissions: [
      { id: 'users_view', name: 'عرض المستخدمين', description: 'عرض قائمة المستخدمين' },
      { id: 'users_create', name: 'إضافة مستخدم', description: 'إنشاء حسابات جديدة' },
      { id: 'users_edit', name: 'تعديل مستخدم', description: 'تعديل بيانات المستخدمين' },
      { id: 'users_delete', name: 'حذف مستخدم', description: 'حذف حسابات المستخدمين' },
      { id: 'users_permissions', name: 'إدارة الصلاحيات', description: 'تعديل صلاحيات المستخدمين' },
    ]
  },
  {
    id: 'properties',
    name: 'إدارة العقارات',
    icon: Home,
    permissions: [
      { id: 'properties_view', name: 'عرض العقارات', description: 'عرض جميع العقارات' },
      { id: 'properties_create', name: 'إضافة عقار', description: 'إضافة عقارات جديدة' },
      { id: 'properties_edit', name: 'تعديل عقار', description: 'تعديل بيانات العقارات' },
      { id: 'properties_delete', name: 'حذف عقار', description: 'حذف العقارات' },
      { id: 'properties_approve', name: 'الموافقة على العقارات', description: 'الموافقة/رفض العقارات' },
      { id: 'properties_featured', name: 'إدارة المميز', description: 'إضافة/إزالة من العقارات المميزة' },
    ]
  },
  {
    id: 'companies',
    name: 'إدارة الشركات',
    icon: Building2,
    permissions: [
      { id: 'companies_view', name: 'عرض الشركات', description: 'عرض قائمة الشركات' },
      { id: 'companies_create', name: 'إضافة شركة', description: 'إضافة شركات جديدة' },
      { id: 'companies_edit', name: 'تعديل شركة', description: 'تعديل بيانات الشركات' },
      { id: 'companies_delete', name: 'حذف شركة', description: 'حذف الشركات' },
    ]
  },
  {
    id: 'deals',
    name: 'إدارة الصفقات',
    icon: HandshakeIcon,
    permissions: [
      { id: 'deals_view', name: 'عرض الصفقات', description: 'عرض جميع الصفقات' },
      { id: 'deals_create', name: 'إنشاء صفقة', description: 'إنشاء صفقات جديدة' },
      { id: 'deals_edit', name: 'تعديل صفقة', description: 'تعديل بيانات الصفقات' },
      { id: 'deals_approve', name: 'الموافقة على الصفقات', description: 'الموافقة/رفض الصفقات' },
      { id: 'deals_cancel', name: 'إلغاء صفقة', description: 'إلغاء الصفقات' },
    ]
  },
  {
    id: 'commissions',
    name: 'إدارة العمولات',
    icon: DollarSignIcon,
    permissions: [
      { id: 'commissions_view', name: 'عرض العمولات', description: 'عرض العمولات والإيرادات' },
      { id: 'commissions_rules', name: 'قواعد العمولات', description: 'تعديل قواعد العمولات' },
      { id: 'commissions_settlements', name: 'التسويات', description: 'إدارة تسويات العمولات' },
      { id: 'commissions_approve', name: 'الموافقة على الدفعات', description: 'الموافقة على دفعات العمولات' },
    ]
  },
  {
    id: 'requests',
    name: 'طلبات العملاء',
    icon: MessageSquareIcon,
    permissions: [
      { id: 'requests_view', name: 'عرض الطلبات', description: 'عرض طلبات العملاء' },
      { id: 'requests_respond', name: 'الرد على الطلبات', description: 'الرد والتواصل مع العملاء' },
      { id: 'requests_assign', name: 'تعيين الطلبات', description: 'تعيين الطلبات للوسطاء' },
      { id: 'requests_close', name: 'إغلاق الطلبات', description: 'إغلاق الطلبات المكتملة' },
    ]
  },
  {
    id: 'ads',
    name: 'الإعلانات',
    icon: MegaphoneIcon,
    permissions: [
      { id: 'ads_view', name: 'عرض الإعلانات', description: 'عرض الإعلانات' },
      { id: 'ads_create', name: 'إنشاء إعلان', description: 'إنشاء إعلانات جديدة' },
      { id: 'ads_edit', name: 'تعديل إعلان', description: 'تعديل الإعلانات' },
      { id: 'ads_delete', name: 'حذف إعلان', description: 'حذف الإعلانات' },
    ]
  },
  {
    id: 'reports',
    name: 'التقارير',
    icon: BarChart3Icon,
    permissions: [
      { id: 'reports_view', name: 'عرض التقارير', description: 'عرض التقارير والإحصائيات' },
      { id: 'reports_export', name: 'تصدير التقارير', description: 'تصدير التقارير بصيغ مختلفة' },
      { id: 'reports_advanced', name: 'تقارير متقدمة', description: 'الوصول للتقارير المتقدمة' },
    ]
  },
  {
    id: 'settings',
    name: 'الإعدادات',
    icon: SettingsIcon,
    permissions: [
      { id: 'settings_view', name: 'عرض الإعدادات', description: 'عرض إعدادات النظام' },
      { id: 'settings_edit', name: 'تعديل الإعدادات', description: 'تعديل إعدادات النظام' },
      { id: 'settings_backup', name: 'النسخ الاحتياطي', description: 'إدارة النسخ الاحتياطي' },
    ]
  },
];

// بيانات تجريبية للمستخدمين
const mockUsers = [
  {
    id: '1',
    name: 'أحمد العلي',
    email: 'ahmed@example.com',
    phone: '+966 50 123 4567',
    role: 'broker',
    status: 'active',
    avatar: 'أ',
    lastActive: 'منذ 5 دقائق',
    permissions: ['dashboard_view', 'properties_view', 'properties_create', 'properties_edit', 'deals_view', 'deals_create', 'commissions_view', 'requests_view', 'requests_respond'],
  },
  {
    id: '2',
    name: 'محمد السالم',
    email: 'mohammed@example.com',
    phone: '+966 55 987 6543',
    role: 'admin',
    status: 'active',
    avatar: 'م',
    lastActive: 'منذ ساعة',
    permissions: ['dashboard_view', 'dashboard_export', 'users_view', 'users_create', 'users_edit', 'properties_view', 'properties_create', 'properties_edit', 'properties_approve', 'companies_view', 'deals_view', 'deals_approve', 'commissions_view', 'requests_view', 'reports_view'],
  },
  {
    id: '3',
    name: 'سارة الأحمد',
    email: 'sara@example.com',
    phone: '+966 54 456 7890',
    role: 'developer',
    status: 'inactive',
    avatar: 'س',
    lastActive: 'منذ 3 أيام',
    permissions: ['dashboard_view', 'properties_view', 'properties_create', 'properties_edit', 'deals_view'],
  },
  {
    id: '4',
    name: 'خالد العمران',
    email: 'khaled@example.com',
    phone: '+966 56 789 0123',
    role: 'broker',
    status: 'active',
    avatar: 'خ',
    lastActive: 'منذ 30 دقيقة',
    permissions: ['dashboard_view', 'properties_view', 'deals_view', 'deals_create', 'commissions_view'],
  },
  {
    id: '5',
    name: 'نورة الفهد',
    email: 'noura@example.com',
    phone: '+966 59 234 5678',
    role: 'client',
    status: 'active',
    avatar: 'ن',
    lastActive: 'منذ يوم',
    permissions: [],
  },
  {
    id: '6',
    name: 'عبدالله الراشد',
    email: 'abdullah@example.com',
    phone: '+966 57 345 6789',
    role: 'owner',
    status: 'suspended',
    avatar: 'ع',
    lastActive: 'منذ أسبوع',
    permissions: ['properties_view'],
  },
];

// أيقونات مساعدة
function LayoutDashboardIcon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>
    </svg>
  );
}
function HandshakeIcon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m11 17 2 2a1 1 0 1 0 3-3"/><path d="m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4"/><path d="m21 3 1 11h-2"/><path d="M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3"/><path d="M3 4h8"/>
    </svg>
  );
}
function DollarSignIcon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="12" x2="12" y1="2" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
    </svg>
  );
}
function MessageSquareIcon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
    </svg>
  );
}
function MegaphoneIcon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>
    </svg>
  );
}
function BarChart3Icon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 3v16a2 2 0 0 0 2 2h16"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>
    </svg>
  );
}
function SettingsIcon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>
    </svg>
  );
}

export default function UserPermissions() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRole, setSelectedRole] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedUser, setSelectedUser] = useState<typeof mockUsers[0] | null>(null);
  const [isPermissionDialogOpen, setIsPermissionDialogOpen] = useState(false);
  const [userPermissions, setUserPermissions] = useState<string[]>([]);
  const [users, setUsers] = useState(mockUsers);
  const [activeTab, setActiveTab] = useState('all');

  // تصفية المستخدمين
  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = selectedRole === 'all' || user.role === selectedRole;
    const matchesStatus = selectedStatus === 'all' || user.status === selectedStatus;
    const matchesTab = activeTab === 'all' || 
                      (activeTab === 'active' && user.status === 'active') ||
                      (activeTab === 'inactive' && user.status !== 'active');
    return matchesSearch && matchesRole && matchesStatus && matchesTab;
  });

  // فتح نافذة الصلاحيات
  const openPermissionDialog = (user: typeof mockUsers[0]) => {
    setSelectedUser(user);
    setUserPermissions([...user.permissions]);
    setIsPermissionDialogOpen(true);
  };

  // تبديل صلاحية
  const togglePermission = (permissionId: string) => {
    setUserPermissions(prev => 
      prev.includes(permissionId)
        ? prev.filter(p => p !== permissionId)
        : [...prev, permissionId]
    );
  };

  // حفظ الصلاحيات
  const savePermissions = () => {
    if (selectedUser) {
      setUsers(prev => prev.map(u => 
        u.id === selectedUser.id 
          ? { ...u, permissions: userPermissions }
          : u
      ));
      toast({
        title: 'تم الحفظ',
        description: `تم تحديث صلاحيات ${selectedUser.name} بنجاح`,
      });
      setIsPermissionDialogOpen(false);
    }
  };

  // تفعيل/تعطيل المستخدم
  const toggleUserStatus = (userId: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        const newStatus = u.status === 'active' ? 'inactive' : 'active';
        toast({
          title: newStatus === 'active' ? 'تم التفعيل' : 'تم التعطيل',
          description: `تم ${newStatus === 'active' ? 'تفعيل' : 'تعطيل'} حساب المستخدم بنجاح`,
        });
        return { ...u, status: newStatus };
      }
      return u;
    }));
  };

  // حظر/فك حظر المستخدم
  const suspendUser = (userId: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        const newStatus = u.status === 'suspended' ? 'inactive' : 'suspended';
        toast({
          title: newStatus === 'suspended' ? 'تم الحظر' : 'تم فك الحظر',
          description: `تم ${newStatus === 'suspended' ? 'حظر' : 'فك حظر'} حساب المستخدم بنجاح`,
        });
        return { ...u, status: newStatus };
      }
      return u;
    }));
  };

  // الحصول على لون حالة المستخدم
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'inactive': return 'bg-slate-100 text-slate-700 border-slate-200';
      case 'suspended': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'نشط';
      case 'inactive': return 'غير نشط';
      case 'suspended': return 'محظور';
      default: return status;
    }
  };

  // عدد الصلاحيات المفعلة لكل وحدة
  const getModuleActiveCount = (moduleId: string) => {
    const module = permissionModules.find(m => m.id === moduleId);
    if (!module) return 0;
    return module.permissions.filter(p => userPermissions.includes(p.id)).length;
  };

  return (
    <>
      <Helmet>
        <title>إدارة صلاحيات المستخدمين | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">إدارة صلاحيات المستخدمين</h1>
            <p className="text-slate-500 mt-1">إدارة وتخصيص صلاحيات المستخدمين بالتفصيل</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => navigate('/admin/users/add')}>
              <User className="w-4 h-4 ml-2" />
              إضافة مستخدم
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center">
                <Users className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{users.length}</p>
                <p className="text-sm text-slate-500">إجمالي المستخدمين</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{users.filter(u => u.status === 'active').length}</p>
                <p className="text-sm text-slate-500">المستخدمين النشطين</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{users.filter(u => u.status === 'inactive').length}</p>
                <p className="text-sm text-slate-500">غير النشطين</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-red-100 flex items-center justify-center">
                <Ban className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{users.filter(u => u.status === 'suspended').length}</p>
                <p className="text-sm text-slate-500">المحظورين</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Toast Test Section */}
        <Card className="border-2 border-dashed border-emerald-200 bg-emerald-50/30">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <CardTitle className="text-base font-bold text-slate-900">
                تجربة نظام الرسائل
              </CardTitle>
            </div>
            <p className="text-sm text-slate-500">
              اضغط على الأزرار لتجربة أنواع مختلفة من الرسائل
            </p>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                onClick={() => toast({ title: 'تم بنجاح!', description: 'تم تنفيذ العملية بنجاح' })}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                <CheckCircle2 className="w-4 h-4 ml-2" />
                نجاح
              </Button>
              <Button
                size="sm"
                variant="destructive"
                onClick={() => toast({ title: 'خطأ!', description: 'حدث خطأ أثناء التنفيذ', variant: 'destructive' })}
              >
                <X className="w-4 h-4 ml-2" />
                خطأ
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => toast({ title: 'تنبيه', description: 'هذا تنبيه مهم' })}
                className="border-amber-500 text-amber-600 hover:bg-amber-50"
              >
                <AlertCircle className="w-4 h-4 ml-2" />
                تنبيه
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => toast({ title: 'معلومة', description: 'هذه معلومة إضافية' })}
                className="border-blue-500 text-blue-600 hover:bg-blue-50"
              >
                <Shield className="w-4 h-4 ml-2" />
                معلومة
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Filters & Tabs */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="البحث بالاسم أو البريد الإلكتروني..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10"
                />
              </div>
              <div className="flex gap-2">
                <select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                  className="px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">جميع الأدوار</option>
                  {userRoles.map(role => (
                    <option key={role.id} value={role.id}>{role.name}</option>
                  ))}
                </select>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">جميع الحالات</option>
                  <option value="active">نشط</option>
                  <option value="inactive">غير نشط</option>
                  <option value="suspended">محظور</option>
                </select>
              </div>
            </div>
          </CardHeader>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mx-6 mb-4">
              <TabsTrigger value="all">الكل ({users.length})</TabsTrigger>
              <TabsTrigger value="active">نشط ({users.filter(u => u.status === 'active').length})</TabsTrigger>
              <TabsTrigger value="inactive">غير نشط ({users.filter(u => u.status !== 'active').length})</TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="m-0">
              <div className="border-t">
                <div className="grid grid-cols-12 gap-4 p-4 bg-slate-50 text-sm font-medium text-slate-600">
                  <div className="col-span-4">المستخدم</div>
                  <div className="col-span-2">الدور</div>
                  <div className="col-span-2">الحالة</div>
                  <div className="col-span-2">الصلاحيات</div>
                  <div className="col-span-2 text-left">الإجراءات</div>
                </div>

                {filteredUsers.map((user) => {
                  const role = userRoles.find(r => r.id === user.role);
                  const RoleIcon = role?.icon || User;

                  return (
                    <div key={user.id} className="grid grid-cols-12 gap-4 p-4 border-b hover:bg-slate-50 transition-colors items-center">
                      <div className="col-span-4 flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold">
                          {user.avatar}
                        </div>
                        <div>
                          <p className="font-medium text-slate-900">{user.name}</p>
                          <p className="text-sm text-slate-500" dir="ltr">{user.email}</p>
                        </div>
                      </div>

                      <div className="col-span-2">
                        <Badge className={`${role?.color} gap-1`}>
                          <RoleIcon className="w-3 h-3" />
                          {role?.name}
                        </Badge>
                      </div>

                      <div className="col-span-2">
                        <Badge variant="outline" className={getStatusColor(user.status)}>
                          {getStatusText(user.status)}
                        </Badge>
                      </div>

                      <div className="col-span-2">
                        <div className="flex items-center gap-2">
                          <Shield className="w-4 h-4 text-emerald-600" />
                          <span className="text-sm">{user.permissions.length} صلاحية</span>
                        </div>
                      </div>

                      <div className="col-span-2 flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openPermissionDialog(user)}
                          className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                        >
                          <Shield className="w-4 h-4" />
                          الصلاحيات
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => toggleUserStatus(user.id)}
                          className={user.status === 'active' ? 'text-amber-600 hover:text-amber-700 hover:bg-amber-50' : 'text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50'}
                        >
                          {user.status === 'active' ? <Power className="w-4 h-4" /> : <Check className="w-4 h-4" />}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => suspendUser(user.id)}
                          className={user.status === 'suspended' ? 'text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50' : 'text-red-600 hover:text-red-700 hover:bg-red-50'}
                        >
                          {user.status === 'suspended' ? <Unlock className="w-4 h-4" /> : <Ban className="w-4 h-4" />}
                        </Button>
                      </div>
                    </div>
                  );
                })}

                {filteredUsers.length === 0 && (
                  <div className="p-12 text-center">
                    <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                      <Search className="w-8 h-8 text-slate-400" />
                    </div>
                    <p className="text-slate-500">لا يوجد مستخدمين مطابقين للبحث</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </Card>
      </div>

      {/* Permission Dialog */}
      <Dialog open={isPermissionDialogOpen} onOpenChange={setIsPermissionDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold">
                {selectedUser?.avatar}
              </div>
              <div>
                <p>إدارة صلاحيات {selectedUser?.name}</p>
                <p className="text-sm font-normal text-slate-500">{selectedUser?.email}</p>
              </div>
            </DialogTitle>
            <DialogDescription>
              قم بتحديد الصلاحيات التي تريد منحها لهذا المستخدم
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 overflow-hidden flex flex-col">
            {/* Quick Actions */}
            <div className="flex gap-2 mb-4 pb-4 border-b">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setUserPermissions(permissionModules.flatMap(m => m.permissions.map(p => p.id)))}
              >
                <Check className="w-4 h-4 ml-2" />
                تحديد الكل
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setUserPermissions([])}
              >
                <X className="w-4 h-4 ml-2" />
                إلغاء الكل
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => selectedUser && setUserPermissions([...selectedUser.permissions])}
              >
                <RotateCcw className="w-4 h-4 ml-2" />
                إعادة الضبط
              </Button>
            </div>

            {/* Permissions Grid */}
            <div className="flex-1 overflow-y-auto pr-2">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {permissionModules.map((module) => {
                  const ModuleIcon = module.icon;
                  const activeCount = getModuleActiveCount(module.id);
                  const totalCount = module.permissions.length;

                  return (
                    <Card key={module.id} className="border-slate-200">
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                              <ModuleIcon className="w-4 h-4 text-emerald-600" />
                            </div>
                            <CardTitle className="text-base">{module.name}</CardTitle>
                          </div>
                          <Badge variant={activeCount === totalCount ? 'default' : 'secondary'} className={activeCount === totalCount ? 'bg-emerald-600' : ''}>
                            {activeCount}/{totalCount}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0 space-y-2">
                        {module.permissions.map((permission) => {
                          const isEnabled = userPermissions.includes(permission.id);
                          return (
                            <div
                              key={permission.id}
                              onClick={() => togglePermission(permission.id)}
                              className={`
                                flex items-start gap-3 p-3 rounded-lg cursor-pointer transition-all
                                ${isEnabled ? 'bg-emerald-50 border border-emerald-200' : 'bg-slate-50 border border-slate-200 hover:border-emerald-300'}
                              `}
                            >
                              <div className={`
                                w-5 h-5 rounded flex items-center justify-center flex-shrink-0 mt-0.5
                                ${isEnabled ? 'bg-emerald-600 text-white' : 'bg-white border border-slate-300'}
                              `}>
                                {isEnabled && <Check className="w-3 h-3" />}
                              </div>
                              <div className="flex-1">
                                <p className={`font-medium text-sm ${isEnabled ? 'text-emerald-900' : 'text-slate-700'}`}>
                                  {permission.name}
                                </p>
                                <p className="text-xs text-slate-500 mt-0.5">
                                  {permission.description}
                                </p>
                              </div>
                            </div>
                          );
                        })}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          </div>

          <DialogFooter className="border-t pt-4 mt-4">
            <div className="flex items-center justify-between w-full">
              <div className="text-sm text-slate-500">
                <span className="font-medium text-emerald-600">{userPermissions.length}</span> صلاحية محددة
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsPermissionDialogOpen(false)}>
                  إلغاء
                </Button>
                <Button onClick={savePermissions} className="bg-emerald-600 hover:bg-emerald-700">
                  <Save className="w-4 h-4 ml-2" />
                  حفظ الصلاحيات
                </Button>
              </div>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
