import { useState, useRef } from 'react';
import { Helmet } from 'react-helmet-async';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import {
  Palette,
  Image,
  Building2,
  Save,
  Upload,
  Check,
  Globe,
  Mail,
  Phone,
  MapPin,
  RefreshCw
} from 'lucide-react';

const colorThemes = [
  { name: 'أخضر زمردي', primary: '#059669', secondary: '#10b981', class: 'emerald' },
  { name: 'أزرق ملكي', primary: '#2563eb', secondary: '#3b82f6', class: 'blue' },
  { name: 'برتقالي', primary: '#ea580c', secondary: '#f97316', class: 'orange' },
  { name: 'بنفسجي', primary: '#7c3aed', secondary: '#8b5cf6', class: 'violet' },
  { name: 'أحمر', primary: '#dc2626', secondary: '#ef4444', class: 'red' },
  { name: 'وردي', primary: '#db2777', secondary: '#ec4899', class: 'pink' },
  { name: 'سماوي', primary: '#0891b2', secondary: '#06b6d4', class: 'cyan' },
  { name: 'أصفر ذهبي', primary: '#d97706', secondary: '#fbbf24', class: 'amber' },
];

export default function PlatformSettings() {
  const { toast } = useToast();
  const logoInputRef = useRef<HTMLInputElement>(null);
  const faviconInputRef = useRef<HTMLInputElement>(null);
  
  const [selectedTheme, setSelectedTheme] = useState(colorThemes[0]);
  const [isSaving, setIsSaving] = useState(false);
  
  const [platformInfo, setPlatformInfo] = useState({
    name: 'إنابة المستقبل',
    nameEn: 'Inabah Future',
    description: 'منصة العقارات الرائدة في المملكة العربية السعودية',
    email: 'info@inabah.sa',
    phone: '+966 50 123 4567',
    address: 'الرياض، المملكة العربية السعودية',
    website: 'https://inabah.sa',
  });

  const [features, setFeatures] = useState({
    enableRegistration: true,
    enablePropertySubmission: true,
    enableDeals: true,
    enableCommissions: true,
    enableMap: true,
    enableChat: false,
    maintenanceMode: false,
  });

  const [logo, setLogo] = useState<string | null>(null);
  const [favicon, setFavicon] = useState<string | null>(null);

  const handleImageUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    setImage: (url: string) => void
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        toast({
          title: 'تم رفع الصورة',
          description: 'تم رفع الصورة بنجاح',
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    
    // محاكاة حفظ الإعدادات
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    toast({
      title: 'تم الحفظ',
      description: 'تم حفظ إعدادات المنصة بنجاح',
    });
    
    setIsSaving(false);
  };

  const handleReset = () => {
    setSelectedTheme(colorThemes[0]);
    setPlatformInfo({
      name: 'إنابة المستقبل',
      nameEn: 'Inabah Future',
      description: 'منصة العقارات الرائدة في المملكة العربية السعودية',
      email: 'info@inabah.sa',
      phone: '+966 50 123 4567',
      address: 'الرياض، المملكة العربية السعودية',
      website: 'https://inabah.sa',
    });
    setFeatures({
      enableRegistration: true,
      enablePropertySubmission: true,
      enableDeals: true,
      enableCommissions: true,
      enableMap: true,
      enableChat: false,
      maintenanceMode: false,
    });
    setLogo(null);
    setFavicon(null);
    
    toast({
      title: 'تمت إعادة الضبط',
      description: 'تم إعادة الإعدادات الافتراضية',
    });
  };

  return (
    <>
      <Helmet>
        <title>إعدادات المنصة | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">إعدادات المنصة</h1>
            <p className="text-slate-500">تخصيص مظهر وإعدادات المنصة</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleReset}>
              <RefreshCw className="w-4 h-4 ml-2" />
              إعادة ضبط
            </Button>
            <Button 
              onClick={handleSave}
              disabled={isSaving}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-4 h-4 ml-2 animate-spin" />
                  جاري الحفظ...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 ml-2" />
                  حفظ التغييرات
                </>
              )}
            </Button>
          </div>
        </div>

        <Tabs defaultValue="appearance">
          <TabsList className="mb-4">
            <TabsTrigger value="appearance">
              <Palette className="w-4 h-4 ml-2" />
              المظهر
            </TabsTrigger>
            <TabsTrigger value="branding">
              <Image className="w-4 h-4 ml-2" />
              الهوية البصرية
            </TabsTrigger>
            <TabsTrigger value="info">
              <Building2 className="w-4 h-4 ml-2" />
              معلومات المنصة
            </TabsTrigger>
            <TabsTrigger value="features">
              <Globe className="w-4 h-4 ml-2" />
              الميزات
            </TabsTrigger>
          </TabsList>

          {/* Appearance Tab */}
          <TabsContent value="appearance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>اللون الرئيسي</CardTitle>
                <CardDescription>اختر لون المنصة الرئيسي</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {colorThemes.map((theme) => (
                    <button
                      key={theme.class}
                      onClick={() => setSelectedTheme(theme)}
                      className={`p-4 rounded-xl border-2 transition-all ${
                        selectedTheme.class === theme.class
                          ? 'border-slate-900 ring-2 ring-offset-2'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                      style={{ 
                        borderColor: selectedTheme.class === theme.class ? theme.primary : undefined 
                      }}
                    >
                      <div className="flex items-center gap-3 mb-3">
                        <div
                          className="w-10 h-10 rounded-lg"
                          style={{ backgroundColor: theme.primary }}
                        />
                        <div
                          className="w-6 h-6 rounded-lg"
                          style={{ backgroundColor: theme.secondary }}
                        />
                      </div>
                      <p className="font-medium text-right">{theme.name}</p>
                      {selectedTheme.class === theme.class && (
                        <div className="flex items-center gap-1 mt-2 text-emerald-600 text-sm">
                          <Check className="w-4 h-4" />
                          <span>مختار</span>
                        </div>
                      )}
                    </button>
                  ))}
                </div>

                {/* Preview */}
                <div className="mt-8 p-6 bg-slate-50 rounded-xl">
                  <h4 className="font-medium mb-4">معاينة</h4>
                  <div className="flex flex-wrap gap-3">
                    <button
                      className="px-6 py-3 rounded-lg text-white font-medium"
                      style={{ backgroundColor: selectedTheme.primary }}
                    >
                      زر رئيسي
                    </button>
                    <button
                      className="px-6 py-3 rounded-lg text-white font-medium"
                      style={{ backgroundColor: selectedTheme.secondary }}
                    >
                      زر ثانوي
                    </button>
                    <span
                      className="px-4 py-2 rounded-full text-white text-sm"
                      style={{ backgroundColor: selectedTheme.primary }}
                    >
                      شارة
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Branding Tab */}
          <TabsContent value="branding" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>الشعار</CardTitle>
                <CardDescription>رفع شعار المنصة</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Logo Upload */}
                <div>
                  <Label className="mb-3 block">شعار المنصة</Label>
                  <div className="flex items-center gap-6">
                    <div 
                      className="w-32 h-32 bg-slate-100 rounded-xl flex items-center justify-center overflow-hidden border-2 border-dashed border-slate-300"
                    >
                      {logo ? (
                        <img src={logo} alt="الشعار" className="w-full h-full object-contain p-2" />
                      ) : (
                        <Image className="w-12 h-12 text-slate-400" />
                      )}
                    </div>
                    <div className="space-y-3">
                      <Button
                        variant="outline"
                        onClick={() => logoInputRef.current?.click()}
                      >
                        <Upload className="w-4 h-4 ml-2" />
                        رفع شعار
                      </Button>
                      <input
                        ref={logoInputRef}
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleImageUpload(e, setLogo)}
                        className="hidden"
                      />
                      <p className="text-sm text-slate-500">
                        المقاس المفضل: 512×512 بكسل<br />
                        الصيغ المدعومة: PNG, JPG, SVG
                      </p>
                    </div>
                  </div>
                </div>

                {/* Favicon Upload */}
                <div>
                  <Label className="mb-3 block">أيقونة المتصفح (Favicon)</Label>
                  <div className="flex items-center gap-6">
                    <div 
                      className="w-16 h-16 bg-slate-100 rounded-lg flex items-center justify-center overflow-hidden border-2 border-dashed border-slate-300"
                    >
                      {favicon ? (
                        <img src={favicon} alt="Favicon" className="w-full h-full object-contain p-1" />
                      ) : (
                        <Globe className="w-6 h-6 text-slate-400" />
                      )}
                    </div>
                    <div className="space-y-3">
                      <Button
                        variant="outline"
                        onClick={() => faviconInputRef.current?.click()}
                      >
                        <Upload className="w-4 h-4 ml-2" />
                        رفع أيقونة
                      </Button>
                      <input
                        ref={faviconInputRef}
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleImageUpload(e, setFavicon)}
                        className="hidden"
                      />
                      <p className="text-sm text-slate-500">
                        المقاس المفضل: 32×32 أو 64×64 بكسل
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Info Tab */}
          <TabsContent value="info" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>معلومات المنصة</CardTitle>
                <CardDescription>بيانات التواصل والمعلومات الأساسية</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">اسم المنصة (عربي)</Label>
                    <Input
                      id="name"
                      value={platformInfo.name}
                      onChange={(e) => setPlatformInfo({ ...platformInfo, name: e.target.value })}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="nameEn">اسم المنصة (إنجليزي)</Label>
                    <Input
                      id="nameEn"
                      value={platformInfo.nameEn}
                      onChange={(e) => setPlatformInfo({ ...platformInfo, nameEn: e.target.value })}
                      className="mt-1"
                      dir="ltr"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">وصف المنصة</Label>
                  <textarea
                    id="description"
                    value={platformInfo.description}
                    onChange={(e) => setPlatformInfo({ ...platformInfo, description: e.target.value })}
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 min-h-[80px]"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="email">
                      <Mail className="w-4 h-4 inline ml-1" />
                      البريد الإلكتروني
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={platformInfo.email}
                      onChange={(e) => setPlatformInfo({ ...platformInfo, email: e.target.value })}
                      className="mt-1"
                      dir="ltr"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">
                      <Phone className="w-4 h-4 inline ml-1" />
                      رقم الهاتف
                    </Label>
                    <Input
                      id="phone"
                      value={platformInfo.phone}
                      onChange={(e) => setPlatformInfo({ ...platformInfo, phone: e.target.value })}
                      className="mt-1"
                      dir="ltr"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="address">
                    <MapPin className="w-4 h-4 inline ml-1" />
                    العنوان
                  </Label>
                  <Input
                    id="address"
                    value={platformInfo.address}
                    onChange={(e) => setPlatformInfo({ ...platformInfo, address: e.target.value })}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="website">
                    <Globe className="w-4 h-4 inline ml-1" />
                    الموقع الإلكتروني
                  </Label>
                  <Input
                    id="website"
                    value={platformInfo.website}
                    onChange={(e) => setPlatformInfo({ ...platformInfo, website: e.target.value })}
                    className="mt-1"
                    dir="ltr"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Features Tab */}
          <TabsContent value="features" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>تفعيل/تعطيل الميزات</CardTitle>
                <CardDescription>التحكم في الميزات المتاحة في المنصة</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium">التسجيل</p>
                      <p className="text-sm text-slate-500">السماح للمستخدمين بالتسجيل</p>
                    </div>
                    <Switch
                      checked={features.enableRegistration}
                      onCheckedChange={(checked) => setFeatures({ ...features, enableRegistration: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium">إضافة عقارات</p>
                      <p className="text-sm text-slate-500">السماح بإضافة عقارات جديدة</p>
                    </div>
                    <Switch
                      checked={features.enablePropertySubmission}
                      onCheckedChange={(checked) => setFeatures({ ...features, enablePropertySubmission: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium">الصفقات</p>
                      <p className="text-sm text-slate-500">تفعيل نظام الصفقات</p>
                    </div>
                    <Switch
                      checked={features.enableDeals}
                      onCheckedChange={(checked) => setFeatures({ ...features, enableDeals: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium">العمولات</p>
                      <p className="text-sm text-slate-500">تفعيل نظام العمولات</p>
                    </div>
                    <Switch
                      checked={features.enableCommissions}
                      onCheckedChange={(checked) => setFeatures({ ...features, enableCommissions: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium">الخريطة</p>
                      <p className="text-sm text-slate-500">عرض العقارات على الخريطة</p>
                    </div>
                    <Switch
                      checked={features.enableMap}
                      onCheckedChange={(checked) => setFeatures({ ...features, enableMap: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium">الدردشة</p>
                      <p className="text-sm text-slate-500">تفعيل الدردشة المباشرة</p>
                    </div>
                    <Switch
                      checked={features.enableChat}
                      onCheckedChange={(checked) => setFeatures({ ...features, enableChat: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg border border-red-200">
                    <div>
                      <p className="font-medium text-red-700">وضع الصيانة</p>
                      <p className="text-sm text-red-500">إيقاف المنصة مؤقتاً للصيانة</p>
                    </div>
                    <Switch
                      checked={features.maintenanceMode}
                      onCheckedChange={(checked) => setFeatures({ ...features, maintenanceMode: checked })}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}
