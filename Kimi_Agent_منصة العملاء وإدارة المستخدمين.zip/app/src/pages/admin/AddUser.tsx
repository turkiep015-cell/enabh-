import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { companies } from '@/data/mockData';
import {
  User,
  Mail,
  Phone,
  Building2,
  Shield,
  ArrowRight,
  Check,
  UserPlus,
  Briefcase,
  Home,
  Users,
  Key
} from 'lucide-react';

const userRoles = [
  { 
    id: 'broker', 
    name: 'وسيط عقاري', 
    description: 'يمكنه إضافة وإدارة العقارات والصفقات',
    icon: Briefcase,
    color: 'bg-emerald-100 text-emerald-700'
  },
  { 
    id: 'developer', 
    name: 'مطور عقاري', 
    description: 'يمكنه إضافة المشاريع وإدارتها',
    icon: Building2,
    color: 'bg-amber-100 text-amber-700'
  },
  { 
    id: 'owner', 
    name: 'مالك عقار', 
    description: 'يمكنه عرض عقاراته الخاصة',
    icon: Home,
    color: 'bg-rose-100 text-rose-700'
  },
  { 
    id: 'client', 
    name: 'عميل', 
    description: 'يمكنه البحث عن العقارات وإرسال الطلبات',
    icon: Users,
    color: 'bg-blue-100 text-blue-700'
  },
  { 
    id: 'admin', 
    name: 'مدير', 
    description: 'صلاحيات إدارية محدودة',
    icon: Shield,
    color: 'bg-purple-100 text-purple-700'
  },
];

export default function AddUser() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    role: '',
    companyId: '',
    password: '',
    confirmPassword: '',
    sendWelcomeEmail: true,
  });

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    // محاكاة إنشاء المستخدم
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    toast({
      title: 'تم إنشاء المستخدم',
      description: `تم إنشاء حساب ${formData.fullName} بنجاح`,
    });
    
    navigate('/admin/users/brokers');
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 1:
        return formData.fullName && formData.email && formData.phone;
      case 2:
        return formData.role;
      case 3:
        return formData.password && formData.password === formData.confirmPassword && formData.password.length >= 6;
      default:
        return true;
    }
  };

  const selectedRole = userRoles.find(r => r.id === formData.role);

  return (
    <>
      <Helmet>
        <title>إضافة مستخدم جديد | إنابة المستقبل</title>
      </Helmet>

      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-900 mb-2">إضافة مستخدم جديد</h1>
          <p className="text-slate-500">إنشاء حساب جديد في المنصة</p>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-between mb-8">
          {[
            { id: 1, title: 'المعلومات الأساسية' },
            { id: 2, title: 'نوع الحساب' },
            { id: 3, title: 'كلمة المرور' },
            { id: 4, title: 'المراجعة' },
          ].map((step, index) => (
            <div key={step.id} className="flex items-center">
              <div className={`
                w-10 h-10 rounded-full flex items-center justify-center font-semibold text-sm
                ${currentStep > step.id ? 'bg-emerald-600 text-white' : ''}
                ${currentStep === step.id ? 'bg-emerald-600 text-white' : ''}
                ${currentStep < step.id ? 'bg-slate-200 text-slate-500' : ''}
              `}>
                {currentStep > step.id ? <Check className="w-5 h-5" /> : step.id}
              </div>
              <span className={`
                hidden md:block mr-2 text-sm font-medium
                ${currentStep >= step.id ? 'text-emerald-600' : 'text-slate-400'}
              `}>
                {step.title}
              </span>
              {index < 3 && (
                <div className={`
                  hidden md:block w-12 h-0.5 mx-2
                  ${currentStep > step.id ? 'bg-emerald-600' : 'bg-slate-200'}
                `} />
              )}
            </div>
          ))}
        </div>

        <Card>
          <CardContent className="p-6">
            {/* Step 1: Basic Info */}
            {currentStep === 1 && (
              <div className="space-y-6">
                <div>
                  <Label htmlFor="fullName">الاسم الكامل *</Label>
                  <div className="relative mt-1">
                    <User className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <Input
                      id="fullName"
                      placeholder="محمد أحمد العلي"
                      value={formData.fullName}
                      onChange={(e) => handleInputChange('fullName', e.target.value)}
                      className="pr-10"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">البريد الإلكتروني *</Label>
                  <div className="relative mt-1">
                    <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="example@email.com"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      className="pr-10"
                      dir="ltr"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="phone">رقم الجوال *</Label>
                  <div className="relative mt-1">
                    <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <Input
                      id="phone"
                      placeholder="+966 50 123 4567"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      className="pr-10"
                      dir="ltr"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Role Selection */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <div>
                  <Label className="mb-4 block">اختر نوع الحساب *</Label>
                  <div className="grid gap-3">
                    {userRoles.map((role) => {
                      const Icon = role.icon;
                      return (
                        <button
                          key={role.id}
                          onClick={() => handleInputChange('role', role.id)}
                          className={`
                            flex items-center gap-4 p-4 rounded-xl border-2 transition-all text-right
                            ${formData.role === role.id 
                              ? 'border-emerald-600 bg-emerald-50' 
                              : 'border-slate-200 hover:border-emerald-300'}
                          `}
                        >
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${role.color}`}>
                            <Icon className="w-6 h-6" />
                          </div>
                          <div className="flex-1">
                            <p className="font-semibold text-slate-900">{role.name}</p>
                            <p className="text-sm text-slate-500">{role.description}</p>
                          </div>
                          {formData.role === role.id && (
                            <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                              <Check className="w-4 h-4" />
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Company Selection (for broker/developer) */}
                {(formData.role === 'broker' || formData.role === 'developer') && (
                  <div className="mt-6">
                    <Label htmlFor="company">الشركة (اختياري)</Label>
                    <select
                      id="company"
                      value={formData.companyId}
                      onChange={(e) => handleInputChange('companyId', e.target.value)}
                      className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="">اختر الشركة</option>
                      {companies.map(company => (
                        <option key={company.id} value={company.id}>{company.name}</option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            )}

            {/* Step 3: Password */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <div>
                  <Label htmlFor="password">كلمة المرور *</Label>
                  <div className="relative mt-1">
                    <Key className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={formData.password}
                      onChange={(e) => handleInputChange('password', e.target.value)}
                      className="pr-10"
                      dir="ltr"
                    />
                  </div>
                  <p className="text-sm text-slate-500 mt-1">
                    يجب أن تكون 6 أحرف على الأقل
                  </p>
                </div>

                <div>
                  <Label htmlFor="confirmPassword">تأكيد كلمة المرور *</Label>
                  <div className="relative mt-1">
                    <Key className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="••••••••"
                      value={formData.confirmPassword}
                      onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                      className="pr-10"
                      dir="ltr"
                    />
                  </div>
                  {formData.confirmPassword && formData.password !== formData.confirmPassword && (
                    <p className="text-sm text-red-500 mt-1">
                      كلمات المرور غير متطابقة
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-lg">
                  <input
                    type="checkbox"
                    id="sendWelcomeEmail"
                    checked={formData.sendWelcomeEmail}
                    onChange={(e) => handleInputChange('sendWelcomeEmail', e.target.checked)}
                    className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                  />
                  <Label htmlFor="sendWelcomeEmail" className="mb-0 cursor-pointer">
                    إرسال بريد ترحيبي للمستخدم
                  </Label>
                </div>
              </div>
            )}

            {/* Step 4: Review */}
            {currentStep === 4 && (
              <div className="space-y-6">
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
                  <h4 className="font-semibold text-emerald-800 mb-2">مراجعة المعلومات</h4>
                  <p className="text-emerald-700 text-sm">يرجى التحقق من المعلومات قبل الإنشاء</p>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between py-3 border-b">
                    <span className="text-slate-500">الاسم</span>
                    <span className="font-medium">{formData.fullName}</span>
                  </div>
                  <div className="flex justify-between py-3 border-b">
                    <span className="text-slate-500">البريد الإلكتروني</span>
                    <span className="font-medium" dir="ltr">{formData.email}</span>
                  </div>
                  <div className="flex justify-between py-3 border-b">
                    <span className="text-slate-500">رقم الجوال</span>
                    <span className="font-medium" dir="ltr">{formData.phone}</span>
                  </div>
                  <div className="flex justify-between py-3 border-b">
                    <span className="text-slate-500">نوع الحساب</span>
                    <Badge className={selectedRole?.color}>
                      {selectedRole?.name}
                    </Badge>
                  </div>
                  {formData.companyId && (
                    <div className="flex justify-between py-3 border-b">
                      <span className="text-slate-500">الشركة</span>
                      <span className="font-medium">
                        {companies.find(c => c.id === formData.companyId)?.name}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8 pt-6 border-t">
              <Button
                variant="outline"
                onClick={() => setCurrentStep(prev => prev - 1)}
                disabled={currentStep === 1}
              >
                السابق
              </Button>

              {currentStep < 4 ? (
                <Button
                  onClick={() => setCurrentStep(prev => prev + 1)}
                  disabled={!isStepValid()}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  التالي
                  <ArrowRight className="w-4 h-4 mr-2" />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin ml-2" />
                      جاري الإنشاء...
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-4 h-4 ml-2" />
                      إنشاء الحساب
                    </>
                  )}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
