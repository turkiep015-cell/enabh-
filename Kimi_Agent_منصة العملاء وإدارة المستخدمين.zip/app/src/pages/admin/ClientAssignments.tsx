import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Search,
  Users,
  UserCheck,
  UserX,
  Briefcase,
  ArrowRightLeft,
  Check,
  X,
  Phone,
  Mail,
  Building2,
  MapPin,
  Calendar,
  Filter,
  RotateCcw,
  UserPlus,
  UserMinus
} from 'lucide-react';

// بيانات تجريبية للوسطاء
const mockBrokers = [
  { id: 'b1', name: 'أحمد العلي', email: 'ahmed@example.com', phone: '+966 50 123 4567', avatar: 'أ', status: 'active', clientsCount: 5 },
  { id: 'b2', name: 'محمد السالم', email: 'mohammed@example.com', phone: '+966 55 987 6543', avatar: 'م', status: 'active', clientsCount: 3 },
  { id: 'b3', name: 'خالد العمران', email: 'khaled@example.com', phone: '+966 56 789 0123', avatar: 'خ', status: 'active', clientsCount: 8 },
  { id: 'b4', name: 'فهد الدوسري', email: 'fahad@example.com', phone: '+966 57 345 6789', avatar: 'ف', status: 'inactive', clientsCount: 0 },
  { id: 'b5', name: 'سعد الحربي', email: 'saad@example.com', phone: '+966 58 901 2345', avatar: 'س', status: 'active', clientsCount: 2 },
];

// بيانات تجريبية للعملاء
const mockClients = [
  { 
    id: 'c1', 
    name: 'نورة الفهد', 
    email: 'noura@example.com', 
    phone: '+966 59 234 5678',
    avatar: 'ن',
    status: 'active',
    assignedBroker: 'b1',
    requestType: 'شراء فيلا',
    budget: '2,000,000 ريال',
    location: 'الرياض',
    createdAt: '2024-01-15',
    lastContact: '2024-02-20'
  },
  { 
    id: 'c2', 
    name: 'عبدالله الراشد', 
    email: 'abdullah@example.com', 
    phone: '+966 57 345 6789',
    avatar: 'ع',
    status: 'active',
    assignedBroker: 'b2',
    requestType: 'استئجار شقة',
    budget: '50,000 ريال/سنة',
    location: 'جدة',
    createdAt: '2024-01-20',
    lastContact: '2024-02-18'
  },
  { 
    id: 'c3', 
    name: 'فاطمة الزهراني', 
    email: 'fatima@example.com', 
    phone: '+966 54 456 7890',
    avatar: 'ف',
    status: 'active',
    assignedBroker: 'b1',
    requestType: 'شراء أرض',
    budget: '1,500,000 ريال',
    location: 'الدمام',
    createdAt: '2024-02-01',
    lastContact: '2024-02-19'
  },
  { 
    id: 'c4', 
    name: 'سلطان القحطاني', 
    email: 'sultan@example.com', 
    phone: '+966 55 567 8901',
    avatar: 'س',
    status: 'inactive',
    assignedBroker: null,
    requestType: 'استثمار عقاري',
    budget: '5,000,000 ريال',
    location: 'الرياض',
    createdAt: '2024-02-05',
    lastContact: '2024-02-10'
  },
  { 
    id: 'c5', 
    name: 'هند المالكي', 
    email: 'hind@example.com', 
    phone: '+966 50 678 9012',
    avatar: 'ه',
    status: 'active',
    assignedBroker: 'b3',
    requestType: 'شراء شقة',
    budget: '800,000 ريال',
    location: 'مكة',
    createdAt: '2024-02-10',
    lastContact: '2024-02-21'
  },
  { 
    id: 'c6', 
    name: 'يوسف الشمري', 
    email: 'yousef@example.com', 
    phone: '+966 56 789 0123',
    avatar: 'ي',
    status: 'active',
    assignedBroker: null,
    requestType: 'شراء فيلا',
    budget: '3,000,000 ريال',
    location: 'الخبر',
    createdAt: '2024-02-12',
    lastContact: '2024-02-15'
  },
  { 
    id: 'c7', 
    name: 'ليلى الغامدي', 
    email: 'laila@example.com', 
    phone: '+966 59 890 1234',
    avatar: 'ل',
    status: 'active',
    assignedBroker: 'b3',
    requestType: 'استئجار محل',
    budget: '100,000 ريال/سنة',
    location: 'جدة',
    createdAt: '2024-02-14',
    lastContact: '2024-02-20'
  },
  { 
    id: 'c8', 
    name: 'عمر السبيعي', 
    email: 'omar@example.com', 
    phone: '+966 58 901 2345',
    avatar: 'ع',
    status: 'inactive',
    assignedBroker: 'b2',
    requestType: 'شراء مزرعة',
    budget: '4,000,000 ريال',
    location: 'أبها',
    createdAt: '2024-02-16',
    lastContact: '2024-02-17'
  },
];

export default function ClientAssignments() {
  const { toast } = useToast();
  const [clients, setClients] = useState(mockClients);
  const [brokers] = useState(mockBrokers);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBroker, setSelectedBroker] = useState<string>('all');
  const [assignmentFilter, setAssignmentFilter] = useState<string>('all');
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false);
  const [isTransferDialogOpen, setIsTransferDialogOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState<typeof mockClients[0] | null>(null);
  const [targetBroker, setTargetBroker] = useState<string>('');

  // تصفية العملاء
  const filteredClients = clients.filter(client => {
    const matchesSearch = client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         client.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         client.phone.includes(searchQuery);
    const matchesBroker = selectedBroker === 'all' || client.assignedBroker === selectedBroker;
    const matchesAssignment = assignmentFilter === 'all' || 
                             (assignmentFilter === 'assigned' && client.assignedBroker) ||
                             (assignmentFilter === 'unassigned' && !client.assignedBroker);
    return matchesSearch && matchesBroker && matchesAssignment;
  });

  // فتح نافذة التعيين
  const openAssignDialog = (client: typeof mockClients[0]) => {
    setSelectedClient(client);
    setTargetBroker(client.assignedBroker || '');
    setIsAssignDialogOpen(true);
  };

  // فتح نافذة النقل
  const openTransferDialog = (client: typeof mockClients[0]) => {
    setSelectedClient(client);
    setTargetBroker('');
    setIsTransferDialogOpen(true);
  };

  // تعيين عميل لوسيط
  const assignClient = () => {
    if (selectedClient && targetBroker) {
      setClients(prev => prev.map(c => 
        c.id === selectedClient.id 
          ? { ...c, assignedBroker: targetBroker }
          : c
      ));
      const broker = brokers.find(b => b.id === targetBroker);
      toast({
        title: 'تم التعيين بنجاح',
        description: `تم تعيين ${selectedClient.name} للوسيط ${broker?.name}`,
      });
      setIsAssignDialogOpen(false);
      setSelectedClient(null);
      setTargetBroker('');
    }
  };

  // نقل عميل من وسيط لآخر
  const transferClient = () => {
    if (selectedClient && targetBroker && selectedClient.assignedBroker !== targetBroker) {
      const oldBroker = brokers.find(b => b.id === selectedClient.assignedBroker);
      const newBroker = brokers.find(b => b.id === targetBroker);
      setClients(prev => prev.map(c => 
        c.id === selectedClient.id 
          ? { ...c, assignedBroker: targetBroker }
          : c
      ));
      toast({
        title: 'تم النقل بنجاح',
        description: `تم نقل ${selectedClient.name} من ${oldBroker?.name} إلى ${newBroker?.name}`,
      });
      setIsTransferDialogOpen(false);
      setSelectedClient(null);
      setTargetBroker('');
    } else if (selectedClient?.assignedBroker === targetBroker) {
      toast({
        title: 'تنبيه',
        description: 'العميل معين لهذا الوسيط بالفعل',
      });
    }
  };

  // إلغاء تعيين عميل
  const unassignClient = (client: typeof mockClients[0]) => {
    if (client.assignedBroker) {
      const broker = brokers.find(b => b.id === client.assignedBroker);
      setClients(prev => prev.map(c => 
        c.id === client.id 
          ? { ...c, assignedBroker: null }
          : c
      ));
      toast({
        title: 'تم إلغاء التعيين',
        description: `تم إلغاء تعيين ${client.name} من ${broker?.name}`,
      });
    }
  };

  // الحصول على معلومات الوسيط
  const getBrokerInfo = (brokerId: string | null) => {
    if (!brokerId) return null;
    return brokers.find(b => b.id === brokerId);
  };

  // إحصائيات
  const stats = {
    total: clients.length,
    assigned: clients.filter(c => c.assignedBroker).length,
    unassigned: clients.filter(c => !c.assignedBroker).length,
    active: clients.filter(c => c.status === 'active').length,
  };

  return (
    <>
      <Helmet>
        <title>تعيين العملاء للوسطاء | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">تعيين العملاء للوسطاء</h1>
            <p className="text-slate-500 mt-1">إدارة تعيين العملاء للوسطاء ونقلهم بينهم</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.total}</p>
                <p className="text-sm text-slate-500">إجمالي العملاء</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center">
                <UserCheck className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.assigned}</p>
                <p className="text-sm text-slate-500">معينين لوسطاء</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center">
                <UserX className="w-6 h-6 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.unassigned}</p>
                <p className="text-sm text-slate-500">غير معينين</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
                <Briefcase className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{brokers.filter(b => b.status === 'active').length}</p>
                <p className="text-sm text-slate-500">الوسطاء النشطين</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="البحث بالاسم أو البريد أو الجوال..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10"
                />
              </div>
              <div className="flex gap-2">
                <select
                  value={selectedBroker}
                  onChange={(e) => setSelectedBroker(e.target.value)}
                  className="px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">جميع الوسطاء</option>
                  {brokers.filter(b => b.status === 'active').map(broker => (
                    <option key={broker.id} value={broker.id}>{broker.name} ({broker.clientsCount})</option>
                  ))}
                </select>
                <select
                  value={assignmentFilter}
                  onChange={(e) => setAssignmentFilter(e.target.value)}
                  className="px-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">جميع الحالات</option>
                  <option value="assigned">معينين</option>
                  <option value="unassigned">غير معينين</option>
                </select>
              </div>
            </div>
          </CardHeader>

          {/* Clients Table */}
          <div className="border-t">
            <div className="grid grid-cols-12 gap-4 p-4 bg-slate-50 text-sm font-medium text-slate-600">
              <div className="col-span-3">العميل</div>
              <div className="col-span-2">الوسيط المسؤول</div>
              <div className="col-span-2">نوع الطلب</div>
              <div className="col-span-2">الميزانية</div>
              <div className="col-span-1">الحالة</div>
              <div className="col-span-2 text-left">الإجراءات</div>
            </div>

            {filteredClients.map((client) => {
              const broker = getBrokerInfo(client.assignedBroker);

              return (
                <div key={client.id} className="grid grid-cols-12 gap-4 p-4 border-b hover:bg-slate-50 transition-colors items-center">
                  <div className="col-span-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold">
                        {client.avatar}
                      </div>
                      <div>
                        <p className="font-medium text-slate-900">{client.name}</p>
                        <div className="flex items-center gap-2 text-xs text-slate-500">
                          <Phone className="w-3 h-3" />
                          <span dir="ltr">{client.phone}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="col-span-2">
                    {broker ? (
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-sm font-bold">
                          {broker.avatar}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-900">{broker.name}</p>
                          <p className="text-xs text-slate-500">{broker.clientsCount} عميل</p>
                        </div>
                      </div>
                    ) : (
                      <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                        <UserX className="w-3 h-3 ml-1" />
                        غير معين
                      </Badge>
                    )}
                  </div>

                  <div className="col-span-2">
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-slate-400" />
                      <span className="text-sm text-slate-700">{client.requestType}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                      <MapPin className="w-3 h-3" />
                      {client.location}
                    </div>
                  </div>

                  <div className="col-span-2">
                    <span className="text-sm font-medium text-emerald-600">{client.budget}</span>
                  </div>

                  <div className="col-span-1">
                    <Badge variant="outline" className={client.status === 'active' ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600'}>
                      {client.status === 'active' ? 'نشط' : 'غير نشط'}
                    </Badge>
                  </div>

                  <div className="col-span-2 flex items-center justify-end gap-1">
                    {client.assignedBroker ? (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openTransferDialog(client)}
                          className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                        >
                          <ArrowRightLeft className="w-4 h-4 ml-1" />
                          نقل
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => unassignClient(client)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <UserMinus className="w-4 h-4" />
                        </Button>
                      </>
                    ) : (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openAssignDialog(client)}
                        className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                      >
                        <UserPlus className="w-4 h-4 ml-1" />
                        تعيين
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}

            {filteredClients.length === 0 && (
              <div className="p-12 text-center">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-slate-400" />
                </div>
                <p className="text-slate-500">لا يوجد عملاء مطابقين للبحث</p>
              </div>
            )}
          </div>
        </Card>

        {/* Brokers Workload */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-bold flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-emerald-600" />
              توزيع العمل على الوسطاء
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {brokers.filter(b => b.status === 'active').map((broker) => {
                const brokerClients = clients.filter(c => c.assignedBroker === broker.id);
                const percentage = Math.round((brokerClients.length / Math.max(stats.assigned, 1)) * 100);
                
                return (
                  <div key={broker.id} className="p-4 border rounded-lg hover:border-emerald-200 transition-colors">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-lg">
                        {broker.avatar}
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-slate-900">{broker.name}</p>
                        <p className="text-sm text-slate-500">{broker.phone}</p>
                      </div>
                      <Badge className="bg-emerald-100 text-emerald-700">
                        {brokerClients.length} عميل
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-500">نسبة التحميل</span>
                        <span className="font-medium">{percentage}%</span>
                      </div>
                      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-emerald-500 rounded-full transition-all"
                          style={{ width: `${Math.min(percentage, 100)}%` }}
                        />
                      </div>
                    </div>

                    <div className="mt-3 pt-3 border-t">
                      <p className="text-xs text-slate-500 mb-2">آخر العملاء المعينين:</p>
                      <div className="flex flex-wrap gap-1">
                        {brokerClients.slice(0, 3).map(client => (
                          <Badge key={client.id} variant="secondary" className="text-xs">
                            {client.name}
                          </Badge>
                        ))}
                        {brokerClients.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{brokerClients.length - 3}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Assign Dialog */}
      <Dialog open={isAssignDialogOpen} onOpenChange={setIsAssignDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-emerald-600" />
              تعيين عميل لوسيط
            </DialogTitle>
            <DialogDescription>
              اختر الوسيط المسؤول عن هذا العميل
            </DialogDescription>
          </DialogHeader>

          {selectedClient && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-50 rounded-lg">
                <p className="font-medium text-slate-900">{selectedClient.name}</p>
                <p className="text-sm text-slate-500">{selectedClient.requestType} - {selectedClient.budget}</p>
              </div>

              <div>
                <label className="text-sm font-medium text-slate-700 mb-2 block">اختر الوسيط</label>
                <Select value={targetBroker} onValueChange={setTargetBroker}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر وسيط..." />
                  </SelectTrigger>
                  <SelectContent>
                    {brokers.filter(b => b.status === 'active').map((broker) => (
                      <SelectItem key={broker.id} value={broker.id}>
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-xs font-bold">
                            {broker.avatar}
                          </span>
                          <span>{broker.name}</span>
                          <span className="text-slate-400">({broker.clientsCount} عميل)</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAssignDialogOpen(false)}>
              إلغاء
            </Button>
            <Button 
              onClick={assignClient} 
              disabled={!targetBroker}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              <Check className="w-4 h-4 ml-2" />
              تعيين
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transfer Dialog */}
      <Dialog open={isTransferDialogOpen} onOpenChange={setIsTransferDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ArrowRightLeft className="w-5 h-5 text-blue-600" />
              نقل عميل لوسيط آخر
            </DialogTitle>
            <DialogDescription>
              اختر الوسيط الجديد لنقل العميل إليه
            </DialogDescription>
          </DialogHeader>

          {selectedClient && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-50 rounded-lg">
                <p className="font-medium text-slate-900">{selectedClient.name}</p>
                <p className="text-sm text-slate-500">{selectedClient.requestType} - {selectedClient.budget}</p>
                {selectedClient.assignedBroker && (
                  <div className="mt-2 pt-2 border-t flex items-center gap-2 text-sm">
                    <span className="text-slate-500">الوسيط الحالي:</span>
                    <span className="font-medium text-emerald-600">
                      {getBrokerInfo(selectedClient.assignedBroker)?.name}
                    </span>
                  </div>
                )}
              </div>

              <div>
                <label className="text-sm font-medium text-slate-700 mb-2 block">الوسيط الجديد</label>
                <Select value={targetBroker} onValueChange={setTargetBroker}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر وسيط..." />
                  </SelectTrigger>
                  <SelectContent>
                    {brokers
                      .filter(b => b.status === 'active' && b.id !== selectedClient.assignedBroker)
                      .map((broker) => (
                        <SelectItem key={broker.id} value={broker.id}>
                          <div className="flex items-center gap-2">
                            <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold">
                              {broker.avatar}
                            </span>
                            <span>{broker.name}</span>
                            <span className="text-slate-400">({broker.clientsCount} عميل)</span>
                          </div>
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsTransferDialogOpen(false)}>
              إلغاء
            </Button>
            <Button 
              onClick={transferClient} 
              disabled={!targetBroker}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <ArrowRightLeft className="w-4 h-4 ml-2" />
              نقل
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
