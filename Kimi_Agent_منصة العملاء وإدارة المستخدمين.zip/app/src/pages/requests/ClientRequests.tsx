import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { NavLink } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { clientRequests, users, cities, propertyTypes } from '@/data/mockData';
import {
  Search,
  MoreVertical,
  Calendar,
  User,
  MapPin,
  Home,
  CheckCircle2,
  Clock,
  XCircle,
  Eye,
  Edit,
  Trash2,
  Download,
  FileText,
  Phone,
  MessageSquare,
} from 'lucide-react';

export default function ClientRequests() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'open' | 'in_progress' | 'closed' | 'cancelled'>('all');

  const filteredRequests = clientRequests.filter((request) => {
    const client = users.find((u) => u.id === request.clientId);
    const matchesSearch =
      client?.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.requestNumber.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'all' ? true : request.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Get stats
  const openRequests = clientRequests.filter((r) => r.status === 'open').length;
  const inProgressRequests = clientRequests.filter((r) => r.status === 'in_progress').length;
  const closedRequests = clientRequests.filter((r) => r.status === 'closed').length;
  const cancelledRequests = clientRequests.filter((r) => r.status === 'cancelled').length;

  const handleDelete = (_requestId: string) => {
    toast({
      title: 'تم الحذف',
      description: 'تم حذف الطلب بنجاح',
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return (
          <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">
            <FileText className="w-3 h-3 ml-1" />
            جديد
          </Badge>
        );
      case 'in_progress':
        return (
          <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">
            <Clock className="w-3 h-3 ml-1" />
            قيد المعالجة
          </Badge>
        );
      case 'closed':
        return (
          <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
            <CheckCircle2 className="w-3 h-3 ml-1" />
            مغلق
          </Badge>
        );
      case 'cancelled':
        return (
          <Badge className="bg-red-100 text-red-700 hover:bg-red-100">
            <XCircle className="w-3 h-3 ml-1" />
            ملغي
          </Badge>
        );
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getClientName = (clientId: string) => {
    const user = users.find((u) => u.id === clientId);
    return user?.fullName || 'غير معروف';
  };

  const getClientPhone = (clientId: string) => {
    const user = users.find((u) => u.id === clientId);
    return user?.phone || '-';
  };

  const getCityName = (cityId?: string) => {
    if (!cityId) return 'غير محدد';
    const city = cities.find((c) => c.id === cityId);
    return city?.nameAr || 'غير محدد';
  };

  const getPropertyTypeName = (typeIds?: string[]) => {
    if (!typeIds || typeIds.length === 0) return 'غير محدد';
    const type = propertyTypes.find((t) => t.id === typeIds[0]);
    return type?.nameAr || 'غير محدد';
  };

  const formatCurrency = (amount?: number) => {
    if (!amount) return 'غير محدد';
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <>
      <Helmet>
        <title>طلبات العملاء | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">طلبات العملاء</h1>
            <p className="text-slate-500 mt-1">متابعة وإدارة طلبات العملاء العقارية</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              تصدير
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">الطلبات الجديدة</p>
                  <p className="text-2xl font-bold text-blue-600">{openRequests}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">قيد المعالجة</p>
                  <p className="text-2xl font-bold text-amber-600">{inProgressRequests}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">الطلبات المغلقة</p>
                  <p className="text-2xl font-bold text-emerald-600">{closedRequests}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">الطلبات الملغاة</p>
                  <p className="text-2xl font-bold text-red-600">{cancelledRequests}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
                  <XCircle className="w-5 h-5 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="البحث باسم العميل، رقم الطلب..."
                  className="pr-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Tabs
                value={statusFilter}
                onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}
                className="w-full sm:w-auto"
              >
                <TabsList>
                  <TabsTrigger value="all">الكل</TabsTrigger>
                  <TabsTrigger value="open">جديد</TabsTrigger>
                  <TabsTrigger value="in_progress">قيد المعالجة</TabsTrigger>
                  <TabsTrigger value="closed">مغلق</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Requests List */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">العميل</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">نوع العقار</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">المدينة</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الميزانية</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">التاريخ</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الحالة</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredRequests.map((request) => (
                    <tr key={request.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4 text-slate-400" />
                            <span className="font-medium text-slate-900">{getClientName(request.clientId)}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Phone className="w-4 h-4 text-slate-400" />
                            <span className="text-sm text-slate-500 ltr">{getClientPhone(request.clientId)}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <Home className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-700">{getPropertyTypeName(request.propertyTypeIds)}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-700">{getCityName(request.cityId)}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <div className="flex flex-col items-center">
                          <span className="font-medium text-slate-900">{formatCurrency(request.budgetMin)}</span>
                          <span className="text-xs text-slate-500">-</span>
                          <span className="font-medium text-slate-900">{formatCurrency(request.budgetMax)}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <Calendar className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-700">
                            {new Date(request.createdAt).toLocaleDateString('ar-SA')}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">{getStatusBadge(request.status)}</td>
                      <td className="px-4 py-4 text-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem asChild>
                              <NavLink to={`/requests/${request.id}`}>
                                <Eye className="w-4 h-4 ml-2" />
                                عرض التفاصيل
                              </NavLink>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <NavLink to={`/requests/${request.id}/edit`}>
                                <Edit className="w-4 h-4 ml-2" />
                                تعديل
                              </NavLink>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <MessageSquare className="w-4 h-4 ml-2" />
                              مراسلة العميل
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleDelete(request.id)}
                              className="text-red-600"
                            >
                              <Trash2 className="w-4 h-4 ml-2" />
                              حذف
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredRequests.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-2">لا توجد نتائج</h3>
                <p className="text-slate-500">لم يتم العثور على طلب يطابق معايير البحث</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pagination */}
        {filteredRequests.length > 0 && (
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-500">
              عرض {filteredRequests.length} من {clientRequests.length} طلب
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>
                السابق
              </Button>
              <Button variant="outline" size="sm" disabled>
                التالي
              </Button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
