import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { NavLink } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { deals, users } from '@/data/mockData';
import {
  Search,
  MoreVertical,
  Calendar,
  User,
  DollarSign,
  Percent,
  CheckCircle2,
  Clock,
  Wallet,
  FileText,
  Eye,
  Download,
  ArrowUpRight,
} from 'lucide-react';

export default function Commissions() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'paid' | 'pending'>('all');

  // Get commissions from completed deals
  const allCommissions = deals.flatMap((deal) => 
    (deal.commissions || []).map((comm) => ({
      id: comm.id,
      dealId: deal.id,
      dealNumber: deal.dealNumber,
      userId: comm.userId,
      amount: comm.amount,
      percentage: comm.percentage,
      roleType: comm.roleType,
      status: comm.status,
      paidAt: comm.paidAt,
      createdAt: comm.createdAt,
    }))
  );

  const filteredCommissions = allCommissions.filter((commission) => {
    const user = users.find((u) => u.id === commission.userId);
    const matchesSearch =
      commission.dealNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user?.fullName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'all' ? true : commission.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Get stats
  const paidCommissions = allCommissions.filter((c) => c.status === 'paid').length;
  const totalPaid = allCommissions
    .filter((c) => c.status === 'paid')
    .reduce((sum, c) => sum + c.amount, 0);
  const totalPending = allCommissions
    .filter((c) => c.status === 'pending')
    .reduce((sum, c) => sum + c.amount, 0);

  const handlePayCommission = (_commissionId: string) => {
    toast({
      title: 'تم الدفع',
      description: 'تم دفع العمولة بنجاح',
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return (
          <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
            <CheckCircle2 className="w-3 h-3 ml-1" />
            مدفوعة
          </Badge>
        );
      case 'pending':
        return (
          <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">
            <Clock className="w-3 h-3 ml-1" />
            مستحقة
          </Badge>
        );
      case 'approved':
        return (
          <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">
            <CheckCircle2 className="w-3 h-3 ml-1" />
            معتمدة
          </Badge>
        );
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getUserName = (userId: string) => {
    const user = users.find((u) => u.id === userId);
    return user?.fullName || 'غير معروف';
  };

  const getRoleLabel = (roleType: string) => {
    switch (roleType) {
      case 'listing_agent':
        return 'وكيل التسويق';
      case 'selling_agent':
        return 'وكيل البيع';
      default:
        return roleType;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <>
      <Helmet>
        <title>نظام العمولات | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">نظام العمولات</h1>
            <p className="text-slate-500 mt-1">إدارة ومتابعة عمولات الوسطاء العقاريين</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              تصدير
            </Button>
            <NavLink to="/commissions/rules">
              <Button variant="outline" className="gap-2">
                <Percent className="w-4 h-4" />
                قواعد العمولات
              </Button>
            </NavLink>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي العمولات</p>
                  <p className="text-2xl font-bold text-slate-900">{allCommissions.length}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">العمولات المدفوعة</p>
                  <p className="text-2xl font-bold text-emerald-600">{paidCommissions}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">إجمالي المدفوع</p>
                  <p className="text-2xl font-bold text-emerald-600">
                    {(totalPaid / 1000000).toFixed(1)}M
                  </p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <ArrowUpRight className="w-5 h-5 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">المستحق غير المدفوع</p>
                  <p className="text-2xl font-bold text-amber-600">
                    {(totalPending / 1000000).toFixed(1)}M
                  </p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                  <Wallet className="w-5 h-5 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="البحث برقم الصفقة، اسم الوسيط..."
                  className="pr-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Tabs
                value={statusFilter}
                onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}
                className="w-full sm:w-auto"
              >
                <TabsList>
                  <TabsTrigger value="all">الكل</TabsTrigger>
                  <TabsTrigger value="paid">مدفوعة</TabsTrigger>
                  <TabsTrigger value="pending">مستحقة</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Commissions List */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">رقم الصفقة</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-slate-700">المستفيد</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الدور</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">النسبة</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">المبلغ</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">التاريخ</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الحالة</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-slate-700">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredCommissions.map((commission) => (
                    <tr key={commission.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-slate-400" />
                          <span className="font-medium text-slate-900">{commission.dealNumber}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-700">{getUserName(commission.userId)}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                          {getRoleLabel(commission.roleType)}
                        </Badge>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                          <Percent className="w-3 h-3 ml-1" />
                          {commission.percentage}%
                        </Badge>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <span className="font-bold text-emerald-600">{formatCurrency(commission.amount)}</span>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <Calendar className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-700">
                            {new Date(commission.createdAt).toLocaleDateString('ar-SA')}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">{getStatusBadge(commission.status)}</td>
                      <td className="px-4 py-4 text-center">
                        {commission.status === 'pending' ? (
                          <Button
                            size="sm"
                            className="bg-emerald-600 hover:bg-emerald-700"
                            onClick={() => handlePayCommission(commission.id)}
                          >
                            <DollarSign className="w-4 h-4 ml-1" />
                            دفع
                          </Button>
                        ) : (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreVertical className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem asChild>
                                <NavLink to={`/commissions/${commission.id}`}>
                                  <Eye className="w-4 h-4 ml-2" />
                                  عرض التفاصيل
                                </NavLink>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredCommissions.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-2">لا توجد نتائج</h3>
                <p className="text-slate-500">لم يتم العثور على عمولة تطابق معايير البحث</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pagination */}
        {filteredCommissions.length > 0 && (
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-500">
              عرض {filteredCommissions.length} من {allCommissions.length} عمولة
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>
                السابق
              </Button>
              <Button variant="outline" size="sm" disabled>
                التالي
              </Button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
