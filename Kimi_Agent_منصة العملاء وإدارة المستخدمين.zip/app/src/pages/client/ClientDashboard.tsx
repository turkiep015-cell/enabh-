import { Helmet } from 'react-helmet-async';
import { NavLink } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/useAuth';
import { 
  properties, 
  clientRequests,
  projects,
  cities 
} from '@/data/mockData';
// Type imports are used implicitly
import {
  Home,
  Search,
  FileText,
  Clock,
  CheckCircle2,
  Plus,
  ArrowUpRight,
  MapPin,
  Building2,
  Bed,
  Bath,
  Maximize,
  Heart,
} from 'lucide-react';

export default function ClientDashboard() {
  const { user } = useAuth();

  // Filter data for this client
  const myRequests = clientRequests.filter(r => r.clientId === user?.id);
  
  // Get featured properties
  const featuredProperties = properties
    .filter(p => p.status === 'active' && p.isFeatured)
    .slice(0, 4);
  
  // Get new projects
  const newProjects = projects
    .filter(p => p.status === 'selling')
    .slice(0, 3);

  // Calculate stats
  const totalRequests = myRequests.length;
  const pendingRequests = myRequests.filter(r => r.status === 'open' || r.status === 'in_progress').length;
  const completedRequests = myRequests.filter(r => r.status === 'closed').length;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getRequestStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return <Badge className="bg-blue-100 text-blue-700">جديد</Badge>;
      case 'in_progress':
        return <Badge className="bg-amber-100 text-amber-700">قيد المعالجة</Badge>;
      case 'closed':
        return <Badge className="bg-emerald-100 text-emerald-700">مكتمل</Badge>;
      case 'cancelled':
        return <Badge className="bg-red-100 text-red-700">ملغي</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <>
      <Helmet>
        <title>لوحة تحكم العميل | إنابة المستقبل</title>
      </Helmet>

      <div className="space-y-6">
        {/* Welcome Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              مرحباً، {user?.fullName}
            </h1>
            <p className="text-slate-500 mt-1">
              ابحث عن عقارك المثالي
            </p>
          </div>
          <div className="flex items-center gap-2">
            <NavLink to="/client/properties-search">
              <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700">
                <Search className="w-4 h-4" />
                البحث عن عقار
              </Button>
            </NavLink>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">طلباتي</p>
                  <p className="text-xl font-bold text-slate-900">{totalRequests}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">قيد المعالجة</p>
                  <p className="text-xl font-bold text-amber-600">{pendingRequests}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">مكتملة</p>
                  <p className="text-xl font-bold text-emerald-600">{completedRequests}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Featured Properties */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-semibold">عقارات مميزة</CardTitle>
            <NavLink to="/client/properties-search">
              <Button variant="ghost" size="sm" className="gap-1">
                عرض الكل
                <ArrowUpRight className="w-4 h-4" />
              </Button>
            </NavLink>
          </CardHeader>
          <CardContent>
            {featuredProperties.length > 0 ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {featuredProperties.map((property) => (
                  <NavLink 
                    key={property.id} 
                    to={`/client/properties/${property.id}`}
                    className="group block"
                  >
                    <div className="relative rounded-lg overflow-hidden border border-slate-200 hover:border-emerald-300 transition-all">
                      <div className="aspect-[4/3] bg-slate-100 relative">
                        {property.images?.[0] ? (
                          <img 
                            src={property.images[0].imageUrl} 
                            alt={property.titleAr}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Home className="w-10 h-10 text-slate-300" />
                          </div>
                        )}
                        {property.isFeatured && (
                          <Badge className="absolute top-2 left-2 bg-emerald-600">
                            مميز
                          </Badge>
                        )}
                      </div>
                      <div className="p-3">
                        <p className="font-medium text-slate-900 truncate">{property.titleAr}</p>
                        <p className="text-sm text-slate-500 flex items-center gap-1 mt-1">
                          <MapPin className="w-3 h-3" />
                          {cities.find(c => c.id === property.cityId)?.nameAr}
                        </p>
                        <p className="text-emerald-600 font-semibold mt-2">
                          {formatCurrency(property.price)}
                        </p>
                        <div className="flex items-center gap-3 mt-2 text-xs text-slate-500">
                          {property.bedrooms && (
                            <span className="flex items-center gap-1">
                              <Bed className="w-3 h-3" />
                              {property.bedrooms}
                            </span>
                          )}
                          {property.bathrooms && (
                            <span className="flex items-center gap-1">
                              <Bath className="w-3 h-3" />
                              {property.bathrooms}
                            </span>
                          )}
                          {property.area && (
                            <span className="flex items-center gap-1">
                              <Maximize className="w-3 h-3" />
                              {property.area} م²
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </NavLink>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Home className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500">لا توجد عقارات مميزة حالياً</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* New Projects */}
        {newProjects.length > 0 && (
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-semibold">مشاريع جديدة</CardTitle>
              <NavLink to="/client/projects">
                <Button variant="ghost" size="sm" className="gap-1">
                  عرض الكل
                  <ArrowUpRight className="w-4 h-4" />
                </Button>
              </NavLink>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {newProjects.map((project) => (
                  <NavLink 
                    key={project.id} 
                    to={`/client/projects/${project.id}`}
                    className="flex gap-4 p-4 rounded-lg border border-slate-100 hover:border-emerald-200 hover:bg-emerald-50/30 transition-all"
                  >
                    <div className="w-24 h-24 rounded-lg bg-slate-100 flex items-center justify-center flex-shrink-0 overflow-hidden">
                      {project.images?.[0] ? (
                        <img 
                          src={project.images[0]} 
                          alt={project.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Building2 className="w-8 h-8 text-slate-400" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-900">{project.name}</h3>
                      <p className="text-sm text-slate-500 flex items-center gap-1 mt-1">
                        <MapPin className="w-4 h-4" />
                        {project.city?.nameAr}
                      </p>
                      <p className="text-sm text-slate-600 mt-2 line-clamp-2">
                        {project.description}
                      </p>
                      <div className="flex items-center gap-4 mt-3">
                        <Badge className="bg-emerald-100 text-emerald-700">قيد البيع</Badge>
                        <span className="text-sm text-slate-500">
                          {properties.filter(p => p.projectId === project.id).length} وحدة
                        </span>
                      </div>
                    </div>
                  </NavLink>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* My Requests */}
        {myRequests.length > 0 && (
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-semibold">طلباتي</CardTitle>
              <NavLink to="/client/my-requests">
                <Button variant="ghost" size="sm" className="gap-1">
                  عرض الكل
                  <ArrowUpRight className="w-4 h-4" />
                </Button>
              </NavLink>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {myRequests.slice(0, 3).map((request) => (
                  <div 
                    key={request.id} 
                    className="flex items-center justify-between p-3 rounded-lg border border-slate-100"
                  >
                    <div>
                      <p className="font-medium text-slate-900">
                        طلب #{request.requestNumber}
                      </p>
                      <p className="text-sm text-slate-500 mt-1">
                        {new Date(request.createdAt).toLocaleDateString('ar-SA')}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      {getRequestStatusBadge(request.status)}
                      <NavLink to={`/client/requests/${request.id}`}>
                        <Button variant="ghost" size="sm">
                          <ArrowUpRight className="w-4 h-4" />
                        </Button>
                      </NavLink>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Actions */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <NavLink to="/client/properties-search">
            <Card className="hover:border-emerald-300 transition-colors cursor-pointer h-full">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <Search className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="font-medium text-slate-900">البحث عن عقار</p>
                  <p className="text-sm text-slate-500">ابحث في آلاف العقارات</p>
                </div>
              </CardContent>
            </Card>
          </NavLink>

          <NavLink to="/client/submit-request">
            <Card className="hover:border-emerald-300 transition-colors cursor-pointer h-full">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Plus className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium text-slate-900">طلب عقار</p>
                  <p className="text-sm text-slate-500">أخبرنا بما تبحث عنه</p>
                </div>
              </CardContent>
            </Card>
          </NavLink>

          <NavLink to="/client/my-requests">
            <Card className="hover:border-emerald-300 transition-colors cursor-pointer h-full">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <p className="font-medium text-slate-900">طلباتي</p>
                  <p className="text-sm text-slate-500">متابعة حالة الطلبات</p>
                </div>
              </CardContent>
            </Card>
          </NavLink>

          <NavLink to="/client/favorites">
            <Card className="hover:border-emerald-300 transition-colors cursor-pointer h-full">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
                  <Heart className="w-5 h-5 text-red-600" />
                </div>
                <div>
                  <p className="font-medium text-slate-900">المفضلة</p>
                  <p className="text-sm text-slate-500">العقارات المحفوظة</p>
                </div>
              </CardContent>
            </Card>
          </NavLink>
        </div>
      </div>
    </>
  );
}
