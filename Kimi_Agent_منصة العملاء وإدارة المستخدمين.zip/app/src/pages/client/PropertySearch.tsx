import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
// Card component will be imported when needed
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { PropertyCard } from '@/components/common/PropertyCard';
import {
  Search,
  SlidersHorizontal,
  Grid3X3,
  List,
  Map,
} from 'lucide-react';
import { properties, cities, propertyTypes } from '@/data/mockData';

export default function PropertySearch() {
  const [viewMode, setViewMode] = useState<'grid' | 'list' | 'map'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Filters
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [priceRange, setPriceRange] = useState<number[]>([0, 5000000]);
  const [areaRange, setAreaRange] = useState<number[]>([0, 1000]);
  const [bedrooms, setBedrooms] = useState<number | null>(null);
  const [bathrooms, setBathrooms] = useState<number | null>(null);
  const [listingType, setListingType] = useState<'all' | 'sale' | 'rent'>('all');

  const filteredProperties = properties.filter(property => {
    const matchesSearch = property.titleAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         property.address?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCity = selectedCity === 'all' || property.cityId === selectedCity;
    const matchesType = selectedType === 'all' || property.typeId === selectedType;
    const matchesPrice = property.price >= priceRange[0] && property.price <= priceRange[1];
    const matchesArea = !property.area || (property.area >= areaRange[0] && property.area <= areaRange[1]);
    const matchesBedrooms = bedrooms === null || property.bedrooms === bedrooms;
    const matchesBathrooms = bathrooms === null || property.bathrooms === bathrooms;
    const matchesListingType = listingType === 'all' || property.listingType === listingType;
    
    return matchesSearch && matchesCity && matchesType && matchesPrice && matchesArea && 
           matchesBedrooms && matchesBathrooms && matchesListingType;
  });

  const formatPrice = (price: number) => {
    if (price >= 1000000) return `${(price / 1000000).toFixed(1)}M`;
    if (price >= 1000) return `${(price / 1000).toFixed(0)}K`;
    return price.toString();
  };

  const activeFiltersCount = [
    selectedCity !== 'all',
    selectedType !== 'all',
    priceRange[0] > 0 || priceRange[1] < 5000000,
    bedrooms !== null,
    bathrooms !== null,
    listingType !== 'all',
  ].filter(Boolean).length;

  return (
    <>
      <Helmet>
        <title>البحث عن العقارات | إنابة المستقبل</title>
      </Helmet>

      <div className="min-h-screen bg-slate-50">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex flex-col lg:flex-row gap-4">
              {/* Search */}
              <div className="relative flex-1">
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  placeholder="ابحث عن عقارك المثالي..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-12 h-12 text-lg"
                />
              </div>

              {/* Quick Filters */}
              <div className="flex items-center gap-2 overflow-x-auto pb-2 lg:pb-0">
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="outline" className="gap-2 whitespace-nowrap">
                      <SlidersHorizontal className="w-4 h-4" />
                      الفلاتر
                      {activeFiltersCount > 0 && (
                        <Badge className="bg-emerald-600 text-white">{activeFiltersCount}</Badge>
                      )}
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="right" className="w-full sm:max-w-md overflow-y-auto">
                    <SheetHeader>
                      <SheetTitle className="flex items-center justify-between">
                        <span>فلاتر البحث</span>
                        {activeFiltersCount > 0 && (
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => {
                              setSelectedCity('all');
                              setSelectedType('all');
                              setPriceRange([0, 5000000]);
                              setAreaRange([0, 1000]);
                              setBedrooms(null);
                              setBathrooms(null);
                              setListingType('all');
                            }}
                          >
                            إعادة ضبط
                          </Button>
                        )}
                      </SheetTitle>
                    </SheetHeader>

                    <div className="space-y-6 mt-6">
                      {/* Listing Type */}
                      <div className="space-y-3">
                        <Label>نوع العرض</Label>
                        <div className="flex gap-2">
                          {[
                            { value: 'all', label: 'الكل' },
                            { value: 'sale', label: 'للبيع' },
                            { value: 'rent', label: 'للإيجار' },
                          ].map((type) => (
                            <button
                              key={type.value}
                              onClick={() => setListingType(type.value as 'all' | 'sale' | 'rent')}
                              className={cn(
                                'flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-colors',
                                listingType === type.value
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              )}
                            >
                              {type.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* City */}
                      <div className="space-y-3">
                        <Label>المدينة</Label>
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            onClick={() => setSelectedCity('all')}
                            className={cn(
                              'py-2 px-3 rounded-lg text-sm transition-colors',
                              selectedCity === 'all'
                                ? 'bg-emerald-600 text-white'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            )}
                          >
                            جميع المدن
                          </button>
                          {cities.map((city) => (
                            <button
                              key={city.id}
                              onClick={() => setSelectedCity(city.id)}
                              className={cn(
                                'py-2 px-3 rounded-lg text-sm transition-colors',
                                selectedCity === city.id
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              )}
                            >
                              {city.nameAr}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Property Type */}
                      <div className="space-y-3">
                        <Label>نوع العقار</Label>
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            onClick={() => setSelectedType('all')}
                            className={cn(
                              'py-2 px-3 rounded-lg text-sm transition-colors',
                              selectedType === 'all'
                                ? 'bg-emerald-600 text-white'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            )}
                          >
                            جميع الأنواع
                          </button>
                          {propertyTypes.map((type) => (
                            <button
                              key={type.id}
                              onClick={() => setSelectedType(type.id)}
                              className={cn(
                                'py-2 px-3 rounded-lg text-sm transition-colors',
                                selectedType === type.id
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              )}
                            >
                              {type.nameAr}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Price Range */}
                      <div className="space-y-3">
                        <Label>نطاق السعر</Label>
                        <Slider
                          value={priceRange}
                          onValueChange={setPriceRange}
                          max={5000000}
                          step={50000}
                          className="py-4"
                        />
                        <div className="flex justify-between text-sm text-slate-600">
                          <span>{formatPrice(priceRange[0])} ر.س</span>
                          <span>{formatPrice(priceRange[1])} ر.س</span>
                        </div>
                      </div>

                      {/* Area Range */}
                      <div className="space-y-3">
                        <Label>المساحة (م²)</Label>
                        <Slider
                          value={areaRange}
                          onValueChange={setAreaRange}
                          max={1000}
                          step={10}
                          className="py-4"
                        />
                        <div className="flex justify-between text-sm text-slate-600">
                          <span>{areaRange[0]} م²</span>
                          <span>{areaRange[1]} م²</span>
                        </div>
                      </div>

                      {/* Bedrooms */}
                      <div className="space-y-3">
                        <Label>عدد الغرف</Label>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setBedrooms(null)}
                            className={cn(
                              'flex-1 py-2 rounded-lg text-sm transition-colors',
                              bedrooms === null
                                ? 'bg-emerald-600 text-white'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            )}
                          >
                            الكل
                          </button>
                          {[1, 2, 3, 4, 5].map((num) => (
                            <button
                              key={num}
                              onClick={() => setBedrooms(num)}
                              className={cn(
                                'flex-1 py-2 rounded-lg text-sm transition-colors',
                                bedrooms === num
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              )}
                            >
                              {num}+
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Bathrooms */}
                      <div className="space-y-3">
                        <Label>عدد الحمامات</Label>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setBathrooms(null)}
                            className={cn(
                              'flex-1 py-2 rounded-lg text-sm transition-colors',
                              bathrooms === null
                                ? 'bg-emerald-600 text-white'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            )}
                          >
                            الكل
                          </button>
                          {[1, 2, 3, 4].map((num) => (
                            <button
                              key={num}
                              onClick={() => setBathrooms(num)}
                              className={cn(
                                'flex-1 py-2 rounded-lg text-sm transition-colors',
                                bathrooms === num
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              )}
                            >
                              {num}+
                            </button>
                          ))}
                        </div>
                      </div>

                      <Button 
                        className="w-full bg-emerald-600 hover:bg-emerald-700"
                      >
                        عرض النتائج ({filteredProperties.length})
                      </Button>
                    </div>
                  </SheetContent>
                </Sheet>

                {/* View Mode */}
                <div className="flex items-center bg-slate-100 rounded-lg p-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setViewMode('grid')}
                    className={cn('h-9 w-9', viewMode === 'grid' && 'bg-white shadow-sm text-emerald-600')}
                  >
                    <Grid3X3 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setViewMode('list')}
                    className={cn('h-9 w-9', viewMode === 'list' && 'bg-white shadow-sm text-emerald-600')}
                  >
                    <List className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setViewMode('map')}
                    className={cn('h-9 w-9', viewMode === 'map' && 'bg-white shadow-sm text-emerald-600')}
                  >
                    <Map className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Results Count */}
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-100">
              <p className="text-slate-600">
                تم العثور على <span className="font-bold text-slate-900">{filteredProperties.length}</span> عقار
              </p>
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-500">الترتيب:</span>
                <select className="text-sm border-0 bg-transparent font-medium text-slate-700 focus:ring-0">
                  <option>الأحدث</option>
                  <option>السعر: من الأقل للأعلى</option>
                  <option>السعر: من الأعلى للأقل</option>
                  <option>الأكثر مشاهدة</option>
                </select>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {viewMode === 'map' ? (
            <div className="h-[600px] bg-slate-200 rounded-2xl flex items-center justify-center">
              <div className="text-center">
                <Map className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-600">الخريطة التفاعلية قيد التطوير</p>
              </div>
            </div>
          ) : (
            <div className={cn(
              viewMode === 'grid' 
                ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6'
                : 'space-y-4'
            )}>
              {filteredProperties.map((property) => (
                <PropertyCard 
                  key={property.id} 
                  property={property}
                  variant={viewMode === 'list' ? 'horizontal' : 'default'}
                />
              ))}
            </div>
          )}

          {filteredProperties.length === 0 && (
            <div className="text-center py-16">
              <div className="w-24 h-24 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-6">
                <Search className="w-12 h-12 text-slate-400" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">لا توجد نتائج</h3>
              <p className="text-slate-600 mb-6">لم يتم العثور على عقارات تطابق معايير البحث</p>
              <Button 
                variant="outline"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCity('all');
                  setSelectedType('all');
                  setPriceRange([0, 5000000]);
                  setBedrooms(null);
                  setBathrooms(null);
                }}
              >
                إعادة ضبط الفلاتر
              </Button>
            </div>
          )}
        </main>
      </div>
    </>
  );
}
