import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { NavLink } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import {
  Plus,
  Clock,
  CheckCircle2,
  XCircle,
  MessageSquare,
  Phone,
  MapPin,
  Home,
  DollarSign,
  Calendar,
  FileText,
  Eye,
  Star,
} from 'lucide-react';
import { clientRequests, cities } from '@/data/mockData';
import type { ClientRequest } from '@/types';

export default function MyRequests() {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [activeTab, setActiveTab] = useState('all');
  const [selectedRequest, setSelectedRequest] = useState<ClientRequest | null>(null);

  const getStatusConfig = (status: ClientRequest['status']) => {
    const configs = {
      open: { label: 'مفتوح', color: 'bg-blue-100 text-blue-700', icon: Clock },
      in_progress: { label: 'قيد المعالجة', color: 'bg-amber-100 text-amber-700', icon: Clock },
      closed: { label: 'مغلق', color: 'bg-emerald-100 text-emerald-700', icon: CheckCircle2 },
      cancelled: { label: 'ملغي', color: 'bg-red-100 text-red-700', icon: XCircle },
    };
    return configs[status];
  };

  const getRequestTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      buy: 'شراء',
      rent: 'إيجار',
      invest: 'استثمار',
    };
    return types[type] || type;
  };

  const filteredRequests = clientRequests.filter(request => {
    if (activeTab === 'all') return true;
    return request.status === activeTab;
  });

  const stats = {
    total: clientRequests.length,
    open: clientRequests.filter(r => r.status === 'open').length,
    inProgress: clientRequests.filter(r => r.status === 'in_progress').length,
    closed: clientRequests.filter(r => r.status === 'closed').length,
  };

  return (
    <>
      <Helmet>
        <title>طلباتي | إنابة المستقبل</title>
      </Helmet>

      <div className="min-h-screen bg-slate-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">طلباتي</h1>
              <p className="text-slate-600 mt-1">متابعة حالة طلباتك العقارية</p>
            </div>
            <NavLink to="/submit-request">
              <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4" />
                طلب جديد
              </Button>
            </NavLink>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100/50 border-blue-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-500 text-white flex items-center justify-center">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">إجمالي الطلبات</p>
                    <p className="text-2xl font-bold text-slate-900">{stats.total}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-amber-50 to-amber-100/50 border-amber-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-amber-500 text-white flex items-center justify-center">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">مفتوحة</p>
                    <p className="text-2xl font-bold text-slate-900">{stats.open}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-50 to-purple-100/50 border-purple-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-purple-500 text-white flex items-center justify-center">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">قيد المعالجة</p>
                    <p className="text-2xl font-bold text-slate-900">{stats.inProgress}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100/50 border-emerald-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500 text-white flex items-center justify-center">
                    <Star className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">مغلقة</p>
                    <p className="text-2xl font-bold text-slate-900">{stats.closed}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="all">الكل ({stats.total})</TabsTrigger>
              <TabsTrigger value="open">مفتوحة ({stats.open})</TabsTrigger>
              <TabsTrigger value="in_progress">قيد المعالجة ({stats.inProgress})</TabsTrigger>
              <TabsTrigger value="closed">مغلقة ({stats.closed})</TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="space-y-6">
              {filteredRequests.length === 0 ? (
                <Card className="py-16">
                  <CardContent className="text-center">
                    <div className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                      <FileText className="w-10 h-10 text-slate-400" />
                    </div>
                    <h3 className="text-lg font-medium text-slate-900 mb-2">لا توجد طلبات</h3>
                    <p className="text-slate-500 mb-4">لم تقم بتقديم أي طلبات بعد</p>
                    <NavLink to="/submit-request">
                      <Button className="bg-emerald-600 hover:bg-emerald-700">
                        تقديم طلب جديد
                      </Button>
                    </NavLink>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {filteredRequests.map((request) => {
                    const statusConfig = getStatusConfig(request.status);
                    const StatusIcon = statusConfig.icon;
                    
                    return (
                      <Card 
                        key={request.id} 
                        className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => setSelectedRequest(request)}
                      >
                        <CardContent className="p-6">
                          <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                            {/* Request Info */}
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <h3 className="font-bold text-lg text-slate-900">{request.requestNumber}</h3>
                                <Badge className={cn(statusConfig.color)}>
                                  <StatusIcon className="w-3 h-3 ml-1" />
                                  {statusConfig.label}
                                </Badge>
                              </div>
                              
                              <div className="flex flex-wrap items-center gap-4 text-sm text-slate-600">
                                <span className="flex items-center gap-1">
                                  <Home className="w-4 h-4" />
                                  {getRequestTypeLabel(request.requestType)}
                                </span>
                                <span className="flex items-center gap-1">
                                  <MapPin className="w-4 h-4" />
                                  {cities.find(c => c.id === request.cityId)?.nameAr}
                                </span>
                                <span className="flex items-center gap-1">
                                  <DollarSign className="w-4 h-4" />
                                  {request.budgetMin ? (request.budgetMin / 1000000).toFixed(1) : '0'}M - {request.budgetMax ? (request.budgetMax / 1000000).toFixed(1) : '0'}M ر.س
                                </span>
                                <span className="flex items-center gap-1">
                                  <Calendar className="w-4 h-4" />
                                  {new Date(request.createdAt).toLocaleDateString('ar-SA')}
                                </span>
                              </div>
                            </div>

                            {/* Progress */}
                            <div className="lg:w-48">
                              <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                                <span>التقدم</span>
                                <span>
                                  {request.status === 'open' ? '25%' : 
                                   request.status === 'in_progress' ? '60%' : '100%'}
                                </span>
                              </div>
                              <Progress 
                                value={request.status === 'open' ? 25 : request.status === 'in_progress' ? 60 : 100} 
                                className="h-2"
                              />
                            </div>

                            {/* Actions */}
                            <div className="flex items-center gap-2">
                              <Button variant="outline" size="sm" className="gap-1">
                                <Eye className="w-4 h-4" />
                                التفاصيل
                              </Button>
                              <Button variant="ghost" size="icon">
                                <MessageSquare className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </TabsContent>
          </Tabs>

          {/* Request Details Modal */}
          {selectedRequest && (
            <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
              <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                <CardHeader className="border-b border-slate-100">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-xl">تفاصيل الطلب</CardTitle>
                      <p className="text-slate-500 text-sm mt-1">{selectedRequest.requestNumber}</p>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => setSelectedRequest(null)}
                    >
                      <XCircle className="w-5 h-5" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  {/* Status */}
                  <div className="flex items-center gap-3">
                    <span className="text-slate-600">الحالة:</span>
                    <Badge className={getStatusConfig(selectedRequest.status).color}>
                      {getStatusConfig(selectedRequest.status).label}
                    </Badge>
                  </div>

                  {/* Details Grid */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="bg-slate-50 rounded-lg p-4">
                      <p className="text-sm text-slate-500 mb-1">نوع الطلب</p>
                      <p className="font-medium">{getRequestTypeLabel(selectedRequest.requestType)}</p>
                    </div>
                    <div className="bg-slate-50 rounded-lg p-4">
                      <p className="text-sm text-slate-500 mb-1">المدينة</p>
                      <p className="font-medium">{cities.find(c => c.id === selectedRequest.cityId)?.nameAr}</p>
                    </div>
                    <div className="bg-slate-50 rounded-lg p-4">
                      <p className="text-sm text-slate-500 mb-1">الميزانية</p>
                      <p className="font-medium">
                        {selectedRequest.budgetMin ? (selectedRequest.budgetMin / 1000000).toFixed(1) : '0'}M - {selectedRequest.budgetMax ? (selectedRequest.budgetMax / 1000000).toFixed(1) : '0'}M ر.س
                      </p>
                    </div>
                    <div className="bg-slate-50 rounded-lg p-4">
                      <p className="text-sm text-slate-500 mb-1">تاريخ التقديم</p>
                      <p className="font-medium">
                        {new Date(selectedRequest.createdAt).toLocaleDateString('ar-SA')}
                      </p>
                    </div>
                  </div>

                  {/* Progress Timeline */}
                  <div>
                    <h4 className="font-bold text-slate-900 mb-4">تتبع الطلب</h4>
                    <div className="space-y-4">
                      {[
                        { title: 'تم استلام الطلب', date: selectedRequest.createdAt, completed: true },
                        { title: 'قيد المراجعة', date: null, completed: selectedRequest.status !== 'open' },
                        { title: 'تم تعيين وسيط', date: null, completed: selectedRequest.assignedTo !== undefined },
                        { title: 'تم إغلاق الطلب', date: null, completed: selectedRequest.status === 'closed' },
                      ].map((step, index) => (
                        <div key={index} className="flex items-start gap-3">
                          <div className={cn(
                            'w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0',
                            step.completed ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-400'
                          )}>
                            {step.completed ? <CheckCircle2 className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                          </div>
                          <div>
                            <p className={cn('font-medium', step.completed ? 'text-slate-900' : 'text-slate-400')}>
                              {step.title}
                            </p>
                            {step.date && (
                              <p className="text-sm text-slate-500">
                                {new Date(step.date).toLocaleDateString('ar-SA')}
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3 pt-4 border-t border-slate-100">
                    <Button className="flex-1 bg-emerald-600 hover:bg-emerald-700 gap-2">
                      <Phone className="w-4 h-4" />
                      الاتصال بالوسيط
                    </Button>
                    <Button variant="outline" className="flex-1 gap-2">
                      <MessageSquare className="w-4 h-4" />
                      مراسلة
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
