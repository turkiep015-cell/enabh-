import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import {
  ArrowRight,
  ArrowLeft,
  Home,
  DollarSign,
  CheckCircle2,
  Phone,
  Mail,
  User,
  Building2,
} from 'lucide-react';
import { cities, propertyTypes } from '@/data/mockData';

export default function SubmitRequest() {
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    // Step 1: Request Details
    requestType: 'buy' as 'buy' | 'rent' | 'invest',
    propertyTypeIds: [] as string[],
    cityId: '',
    districtIds: [] as string[],
    
    // Step 2: Budget & Requirements
    budgetMin: 500000,
    budgetMax: 2000000,
    minArea: 100,
    maxArea: 500,
    bedrooms: null as number | null,
    bathrooms: null as number | null,
    furnishing: 'any' as 'any' | 'furnished' | 'semi_furnished' | 'unfurnished',
    
    // Step 3: Personal Info
    fullName: '',
    email: '',
    phone: '',
    idNumber: '',
    employmentStatus: '',
    monthlyIncome: '',
    
    // Step 4: Additional
    notes: '',
    preferredContactTime: 'anytime' as 'morning' | 'afternoon' | 'evening' | 'anytime',
    hasFinancing: false,
    financingAmount: '',
    agreeTerms: false,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // محاكاة إرسال الطلب
    setTimeout(() => {
      toast({
        title: 'تم إرسال طلبك بنجاح',
        description: 'رقم الطلب: REQ-2024-004 - سنتواصل معك قريباً',
      });
      setIsSubmitting(false);
    }, 2000);
  };

  const steps = [
    { number: 1, title: 'تفاصيل الطلب' },
    { number: 2, title: 'الميزانية والمتطلبات' },
    { number: 3, title: 'المعلومات الشخصية' },
    { number: 4, title: 'ملخص وإرسال' },
  ];

  const requestTypes = [
    { value: 'buy', label: 'شراء', icon: Home },
    { value: 'rent', label: 'إيجار', icon: Building2 },
    { value: 'invest', label: 'استثمار', icon: DollarSign },
  ];

  const employmentOptions = [
    { value: 'employed', label: 'موظف' },
    { value: 'self_employed', label: 'عمل حر' },
    { value: 'business_owner', label: 'صاحب عمل' },
    { value: 'retired', label: 'متقاعد' },
  ];

  const canProceed = () => {
    switch (step) {
      case 1:
        return formData.requestType && formData.propertyTypeIds.length > 0 && formData.cityId;
      case 2:
        return formData.budgetMin > 0 && formData.budgetMax > formData.budgetMin;
      case 3:
        return formData.fullName && formData.email && formData.phone && formData.idNumber;
      case 4:
        return formData.agreeTerms;
      default:
        return false;
    }
  };

  return (
    <>
      <Helmet>
        <title>تقديم طلب عقار | إنابة المستقبل</title>
      </Helmet>

      <div className="min-h-screen bg-slate-50 py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-slate-900 mb-2">تقديم طلب عقار</h1>
            <p className="text-slate-600">أخبرنا بمتطلباتك وسنساعدك في finding عقارك المثالي</p>
          </div>

          {/* Progress Steps */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              {steps.map((s, index) => (
                <div key={s.number} className="flex items-center flex-1">
                  <div className={cn(
                    'w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-colors',
                    step >= s.number 
                      ? 'bg-emerald-600 text-white' 
                      : 'bg-slate-200 text-slate-500'
                  )}>
                    {step > s.number ? <CheckCircle2 className="w-5 h-5" /> : s.number}
                  </div>
                  <span className={cn(
                    'hidden sm:block mr-3 text-sm font-medium',
                    step >= s.number ? 'text-emerald-600' : 'text-slate-400'
                  )}>
                    {s.title}
                  </span>
                  {index < steps.length - 1 && (
                    <div className={cn(
                      'flex-1 h-0.5 mx-4',
                      step > s.number ? 'bg-emerald-600' : 'bg-slate-200'
                    )} />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Form Card */}
          <Card className="shadow-lg">
            <CardContent className="p-8">
              <form onSubmit={handleSubmit}>
                {/* Step 1: Request Details */}
                {step === 1 && (
                  <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                    {/* Request Type */}
                    <div className="space-y-3">
                      <Label>نوع الطلب</Label>
                      <div className="grid grid-cols-3 gap-4">
                        {requestTypes.map((type) => (
                          <button
                            key={type.value}
                            type="button"
                            onClick={() => setFormData({ ...formData, requestType: type.value as 'buy' | 'rent' | 'invest' })}
                            className={cn(
                              'flex flex-col items-center gap-3 p-6 rounded-xl border-2 transition-all',
                              formData.requestType === type.value
                                ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                                : 'border-slate-200 hover:border-emerald-300'
                            )}
                          >
                            <type.icon className="w-8 h-8" />
                            <span className="font-medium">{type.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Property Types */}
                    <div className="space-y-3">
                      <Label>نوع العقار المطلوب</Label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        {propertyTypes.map((type) => (
                          <button
                            key={type.id}
                            type="button"
                            onClick={() => {
                              const newTypes = formData.propertyTypeIds.includes(type.id)
                                ? formData.propertyTypeIds.filter(id => id !== type.id)
                                : [...formData.propertyTypeIds, type.id];
                              setFormData({ ...formData, propertyTypeIds: newTypes });
                            }}
                            className={cn(
                              'p-4 rounded-xl border-2 text-sm font-medium transition-all',
                              formData.propertyTypeIds.includes(type.id)
                                ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                                : 'border-slate-200 hover:border-emerald-300'
                            )}
                          >
                            {type.nameAr}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* City */}
                    <div className="space-y-3">
                      <Label>المدينة</Label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        {cities.map((city) => (
                          <button
                            key={city.id}
                            type="button"
                            onClick={() => setFormData({ ...formData, cityId: city.id })}
                            className={cn(
                              'p-4 rounded-xl border-2 text-sm font-medium transition-all',
                              formData.cityId === city.id
                                ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                                : 'border-slate-200 hover:border-emerald-300'
                            )}
                          >
                            {city.nameAr}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Step 2: Budget & Requirements */}
                {step === 2 && (
                  <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                    {/* Budget */}
                    <div className="space-y-4">
                      <Label>الميزانية</Label>
                      <div className="bg-slate-50 rounded-xl p-6">
                        <Slider
                          value={[formData.budgetMin, formData.budgetMax]}
                          onValueChange={([min, max]) => setFormData({ ...formData, budgetMin: min, budgetMax: max })}
                          max={5000000}
                          step={50000}
                          className="py-4"
                        />
                        <div className="flex justify-between mt-4">
                          <div className="text-center">
                            <p className="text-sm text-slate-500">من</p>
                            <p className="text-lg font-bold text-emerald-600">
                              {(formData.budgetMin / 1000000).toFixed(1)}M ر.س
                            </p>
                          </div>
                          <div className="text-center">
                            <p className="text-sm text-slate-500">إلى</p>
                            <p className="text-lg font-bold text-emerald-600">
                              {(formData.budgetMax / 1000000).toFixed(1)}M ر.س
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Area */}
                    <div className="space-y-4">
                      <Label>المساحة (م²)</Label>
                      <div className="bg-slate-50 rounded-xl p-6">
                        <Slider
                          value={[formData.minArea, formData.maxArea]}
                          onValueChange={([min, max]) => setFormData({ ...formData, minArea: min, maxArea: max })}
                          max={1000}
                          step={10}
                          className="py-4"
                        />
                        <div className="flex justify-between mt-4">
                          <div className="text-center">
                            <p className="text-sm text-slate-500">من</p>
                            <p className="text-lg font-bold text-emerald-600">{formData.minArea} م²</p>
                          </div>
                          <div className="text-center">
                            <p className="text-sm text-slate-500">إلى</p>
                            <p className="text-lg font-bold text-emerald-600">{formData.maxArea} م²</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Bedrooms */}
                    <div className="space-y-3">
                      <Label>عدد الغرف</Label>
                      <div className="flex gap-3">
                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, bedrooms: null })}
                          className={cn(
                            'flex-1 py-3 rounded-xl border-2 font-medium transition-all',
                            formData.bedrooms === null
                              ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                              : 'border-slate-200 hover:border-emerald-300'
                          )}
                        >
                          غير محدد
                        </button>
                        {[1, 2, 3, 4, 5].map((num) => (
                          <button
                            key={num}
                            type="button"
                            onClick={() => setFormData({ ...formData, bedrooms: num })}
                            className={cn(
                              'flex-1 py-3 rounded-xl border-2 font-medium transition-all',
                              formData.bedrooms === num
                                ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                                : 'border-slate-200 hover:border-emerald-300'
                            )}
                          >
                            {num}+
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Bathrooms */}
                    <div className="space-y-3">
                      <Label>عدد الحمامات</Label>
                      <div className="flex gap-3">
                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, bathrooms: null })}
                          className={cn(
                            'flex-1 py-3 rounded-xl border-2 font-medium transition-all',
                            formData.bathrooms === null
                              ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                              : 'border-slate-200 hover:border-emerald-300'
                          )}
                        >
                          غير محدد
                        </button>
                        {[1, 2, 3, 4].map((num) => (
                          <button
                            key={num}
                            type="button"
                            onClick={() => setFormData({ ...formData, bathrooms: num })}
                            className={cn(
                              'flex-1 py-3 rounded-xl border-2 font-medium transition-all',
                              formData.bathrooms === num
                                ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                                : 'border-slate-200 hover:border-emerald-300'
                            )}
                          >
                            {num}+
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Step 3: Personal Info */}
                {step === 3 && (
                  <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                    <div className="grid sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="fullName">الاسم الكامل *</Label>
                        <div className="relative">
                          <User className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                          <Input
                            id="fullName"
                            placeholder="محمد عبدالله"
                            className="pr-10"
                            value={formData.fullName}
                            onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="idNumber">رقم الهوية *</Label>
                        <Input
                          id="idNumber"
                          placeholder="1012345678"
                          value={formData.idNumber}
                          onChange={(e) => setFormData({ ...formData, idNumber: e.target.value })}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email">البريد الإلكتروني *</Label>
                        <div className="relative">
                          <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                          <Input
                            id="email"
                            type="email"
                            placeholder="example@email.com"
                            className="pr-10"
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="phone">رقم الجوال *</Label>
                        <div className="relative">
                          <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                          <Input
                            id="phone"
                            type="tel"
                            placeholder="+966 50 123 4567"
                            className="pr-10"
                            value={formData.phone}
                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="employmentStatus">الحالة الوظيفية</Label>
                        <select
                          id="employmentStatus"
                          className="w-full h-10 px-3 rounded-md border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 outline-none"
                          value={formData.employmentStatus}
                          onChange={(e) => setFormData({ ...formData, employmentStatus: e.target.value })}
                        >
                          <option value="">اختر</option>
                          {employmentOptions.map((opt) => (
                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="monthlyIncome">الدخل الشهري</Label>
                        <Input
                          id="monthlyIncome"
                          type="number"
                          placeholder="15000"
                          value={formData.monthlyIncome}
                          onChange={(e) => setFormData({ ...formData, monthlyIncome: e.target.value })}
                        />
                      </div>
                    </div>

                    {/* Financing */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <Checkbox
                          id="hasFinancing"
                          checked={formData.hasFinancing}
                          onCheckedChange={(checked) => setFormData({ ...formData, hasFinancing: checked as boolean })}
                        />
                        <Label htmlFor="hasFinancing" className="cursor-pointer">
                          لدي تمويل عقاري معتمد
                        </Label>
                      </div>
                      
                      {formData.hasFinancing && (
                        <div className="space-y-2">
                          <Label htmlFor="financingAmount">مبلغ التمويل</Label>
                          <Input
                            id="financingAmount"
                            type="number"
                            placeholder="1000000"
                            value={formData.financingAmount}
                            onChange={(e) => setFormData({ ...formData, financingAmount: e.target.value })}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Step 4: Summary & Submit */}
                {step === 4 && (
                  <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                    {/* Summary */}
                    <div className="bg-slate-50 rounded-xl p-6 space-y-4">
                      <h3 className="font-bold text-lg text-slate-900">ملخص الطلب</h3>
                      
                      <div className="grid sm:grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-slate-500">نوع الطلب:</span>
                          <span className="mr-2 font-medium">
                            {formData.requestType === 'buy' ? 'شراء' : formData.requestType === 'rent' ? 'إيجار' : 'استثمار'}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500">المدينة:</span>
                          <span className="mr-2 font-medium">
                            {cities.find(c => c.id === formData.cityId)?.nameAr}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500">الميزانية:</span>
                          <span className="mr-2 font-medium">
                            {(formData.budgetMin / 1000000).toFixed(1)}M - {(formData.budgetMax / 1000000).toFixed(1)}M ر.س
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500">المساحة:</span>
                          <span className="mr-2 font-medium">{formData.minArea} - {formData.maxArea} م²</span>
                        </div>
                        <div>
                          <span className="text-slate-500">الغرف:</span>
                          <span className="mr-2 font-medium">{formData.bedrooms || 'غير محدد'}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">الحمامات:</span>
                          <span className="mr-2 font-medium">{formData.bathrooms || 'غير محدد'}</span>
                        </div>
                      </div>
                    </div>

                    {/* Notes */}
                    <div className="space-y-2">
                      <Label htmlFor="notes">ملاحظات إضافية</Label>
                      <Textarea
                        id="notes"
                        placeholder="أخبرنا بأي متطلبات إضافية..."
                        rows={4}
                        value={formData.notes}
                        onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      />
                    </div>

                    {/* Terms */}
                    <div className="flex items-start gap-3">
                      <Checkbox
                        id="terms"
                        checked={formData.agreeTerms}
                        onCheckedChange={(checked) => setFormData({ ...formData, agreeTerms: checked as boolean })}
                      />
                      <Label htmlFor="terms" className="text-sm text-slate-600 leading-relaxed cursor-pointer">
                        أوافق على مشاركة معلوماتي مع الوسطاء العقاريين المعتمدين في المنصة
                      </Label>
                    </div>
                  </div>
                )}

                {/* Navigation Buttons */}
                <div className="flex justify-between pt-6 border-t border-slate-100">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setStep(step - 1)}
                    disabled={step === 1}
                    className="gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    السابق
                  </Button>
                  
                  {step < 4 ? (
                    <Button
                      type="button"
                      onClick={() => setStep(step + 1)}
                      disabled={!canProceed()}
                      className="gap-2 bg-emerald-600 hover:bg-emerald-700"
                    >
                      التالي
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  ) : (
                    <Button
                      type="submit"
                      disabled={isSubmitting || !canProceed()}
                      className="gap-2 bg-emerald-600 hover:bg-emerald-700"
                    >
                      {isSubmitting ? (
                        <>
                          <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          جاري الإرسال...
                        </>
                      ) : (
                        <>
                          إرسال الطلب
                          <CheckCircle2 className="w-4 h-4" />
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
