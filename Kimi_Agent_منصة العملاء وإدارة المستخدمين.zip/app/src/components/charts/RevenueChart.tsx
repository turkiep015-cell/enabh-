import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

import { cn } from '@/lib/utils';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { TrendingUp, Calendar, Download } from 'lucide-react';

interface RevenueChartProps {
  className?: string;
}

const monthlyData = [
  { month: 'يناير', revenue: 450000, deals: 12, commission: 112500 },
  { month: 'فبراير', revenue: 520000, deals: 15, commission: 130000 },
  { month: 'مارس', revenue: 480000, deals: 13, commission: 120000 },
  { month: 'أبريل', revenue: 610000, deals: 18, commission: 152500 },
  { month: 'مايو', revenue: 580000, deals: 16, commission: 145000 },
  { month: 'يونيو', revenue: 720000, deals: 22, commission: 180000 },
  { month: 'يوليو', revenue: 690000, deals: 20, commission: 172500 },
  { month: 'أغسطس', revenue: 750000, deals: 24, commission: 187500 },
  { month: 'سبتمبر', revenue: 680000, deals: 19, commission: 170000 },
  { month: 'أكتوبر', revenue: 820000, deals: 26, commission: 205000 },
  { month: 'نوفمبر', revenue: 790000, deals: 25, commission: 197500 },
  { month: 'ديسمبر', revenue: 850000, deals: 28, commission: 212500 },
];

const revenueBreakdown = [
  { name: 'عمولات الصفقات', value: 65, color: '#10b981' },
  { name: 'رسوم الإدراج', value: 20, color: '#3b82f6' },
  { name: 'الإعلانات', value: 10, color: '#f59e0b' },
  { name: 'اشتراكات', value: 5, color: '#8b5cf6' },
];

const formatCurrency = (value: number) => {
  return `${(value / 1000).toFixed(0)}K`;
};

export function RevenueChart({ className }: RevenueChartProps) {
  const [period, setPeriod] = useState<'month' | 'quarter' | 'year'>('month');
  const [chartType, setChartType] = useState<'bar' | 'line' | 'area'>('area');

  const totalRevenue = monthlyData.reduce((sum, item) => sum + item.revenue, 0);
  const totalDeals = monthlyData.reduce((sum, item) => sum + item.deals, 0);
  const totalCommission = monthlyData.reduce((sum, item) => sum + item.commission, 0);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 rounded-lg shadow-lg border border-slate-200">
          <p className="font-medium text-slate-900 mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <div key={index} className="flex items-center gap-2 text-sm">
              <span 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: entry.color }}
              />
              <span className="text-slate-600">{entry.name}:</span>
              <span className="font-medium text-slate-900">
                {entry.name === 'revenue' || entry.name === 'commission' 
                  ? `${(entry.value / 1000).toFixed(0)}K ر.س`
                  : entry.value
                }
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  const renderChart = () => {
    const commonProps = {
      data: monthlyData,
      margin: { top: 10, right: 10, left: 0, bottom: 0 },
    };

    switch (chartType) {
      case 'bar':
        return (
          <BarChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
            <XAxis 
              dataKey="month" 
              stroke="#64748b" 
              fontSize={12}
              tickLine={false}
              axisLine={false}
            />
            <YAxis 
              stroke="#64748b" 
              fontSize={12}
              tickLine={false}
              axisLine={false}
              tickFormatter={formatCurrency}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="revenue" name="الإيرادات" fill="#10b981" radius={[4, 4, 0, 0]} />
            <Bar dataKey="commission" name="العمولات" fill="#3b82f6" radius={[4, 4, 0, 0]} />
          </BarChart>
        );
      case 'line':
        return (
          <LineChart {...commonProps}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
            <XAxis 
              dataKey="month" 
              stroke="#64748b" 
              fontSize={12}
              tickLine={false}
              axisLine={false}
            />
            <YAxis 
              stroke="#64748b" 
              fontSize={12}
              tickLine={false}
              axisLine={false}
              tickFormatter={formatCurrency}
            />
            <Tooltip content={<CustomTooltip />} />
            <Line 
              type="monotone" 
              dataKey="revenue" 
              name="الإيرادات"
              stroke="#10b981" 
              strokeWidth={3}
              dot={{ fill: '#10b981', strokeWidth: 2, r: 4 }}
              activeDot={{ r: 6 }}
            />
            <Line 
              type="monotone" 
              dataKey="commission" 
              name="العمولات"
              stroke="#3b82f6" 
              strokeWidth={3}
              dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
              activeDot={{ r: 6 }}
            />
          </LineChart>
        );
      case 'area':
        return (
          <AreaChart {...commonProps}>
            <defs>
              <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorCommission" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
            <XAxis 
              dataKey="month" 
              stroke="#64748b" 
              fontSize={12}
              tickLine={false}
              axisLine={false}
            />
            <YAxis 
              stroke="#64748b" 
              fontSize={12}
              tickLine={false}
              axisLine={false}
              tickFormatter={formatCurrency}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area 
              type="monotone" 
              dataKey="revenue" 
              name="الإيرادات"
              stroke="#10b981" 
              strokeWidth={3}
              fillOpacity={1} 
              fill="url(#colorRevenue)" 
            />
            <Area 
              type="monotone" 
              dataKey="commission" 
              name="العمولات"
              stroke="#3b82f6" 
              strokeWidth={3}
              fillOpacity={1} 
              fill="url(#colorCommission)" 
            />
          </AreaChart>
        );
    }
  };

  return (
    <Card className={cn('overflow-hidden', className)}>
      <CardHeader className="pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="space-y-1">
            <CardTitle className="text-lg font-bold text-slate-900">
              تحليل الإيرادات
            </CardTitle>
            <p className="text-sm text-slate-500">
              إجمالي الإيرادات: <span className="font-medium text-emerald-600">{(totalRevenue / 1000000).toFixed(2)} مليون ر.س</span>
            </p>
          </div>
          
          <div className="flex items-center gap-2 flex-wrap">
            {/* Period Selector */}
            <div className="flex items-center bg-slate-100 rounded-lg p-1">
              {(['month', 'quarter', 'year'] as const).map((p) => (
                <Button
                  key={p}
                  variant="ghost"
                  size="sm"
                  onClick={() => setPeriod(p)}
                  className={cn(
                    'text-xs font-medium transition-all',
                    period === p 
                      ? 'bg-white text-emerald-600 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-700'
                  )}
                >
                  {p === 'month' && 'شهري'}
                  {p === 'quarter' && 'ربعي'}
                  {p === 'year' && 'سنوي'}
                </Button>
              ))}
            </div>

            {/* Chart Type Selector */}
            <div className="flex items-center bg-slate-100 rounded-lg p-1">
              {(['area', 'bar', 'line'] as const).map((type) => (
                <Button
                  key={type}
                  variant="ghost"
                  size="sm"
                  onClick={() => setChartType(type)}
                  className={cn(
                    'text-xs font-medium transition-all capitalize',
                    chartType === type 
                      ? 'bg-white text-emerald-600 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-700'
                  )}
                >
                  {type === 'area' && 'مساحي'}
                  {type === 'bar' && 'أعمدة'}
                  {type === 'line' && 'خطي'}
                </Button>
              ))}
            </div>

            <Button variant="outline" size="icon" className="h-8 w-8">
              <Download className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {/* Stats Row */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="flex items-center gap-3 bg-emerald-50 rounded-lg px-4 py-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
            </div>
            <div>
              <p className="text-xs text-slate-500">الصفقات</p>
              <p className="text-sm font-bold text-slate-900">{totalDeals}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3 bg-blue-50 rounded-lg px-4 py-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
              <Calendar className="w-4 h-4 text-blue-600" />
            </div>
            <div>
              <p className="text-xs text-slate-500">متوسط العمولة</p>
              <p className="text-sm font-bold text-slate-900">{(totalCommission / totalDeals / 1000).toFixed(1)}K ر.س</p>
            </div>
          </div>
        </div>

        {/* Chart */}
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            {renderChart()}
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

// Pie Chart for Revenue Breakdown
export function RevenueBreakdownChart({ className }: RevenueChartProps) {
  return (
    <Card className={cn('overflow-hidden', className)}>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-bold text-slate-900">
          توزيع الإيرادات
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        <div className="h-[250px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={revenueBreakdown}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={4}
                dataKey="value"
              >
                {revenueBreakdown.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-white p-3 rounded-lg shadow-lg border border-slate-200">
                        <p className="font-medium text-slate-900">{payload[0].name}</p>
                        <p className="text-emerald-600 font-bold">{payload[0].value}%</p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Legend */}
        <div className="grid grid-cols-2 gap-3 mt-4">
          {revenueBreakdown.map((item, index) => (
            <div key={index} className="flex items-center gap-2">
              <span 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: item.color }}
              />
              <span className="text-sm text-slate-600">{item.name}</span>
              <span className="text-sm font-medium text-slate-900 mr-auto">{item.value}%</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
