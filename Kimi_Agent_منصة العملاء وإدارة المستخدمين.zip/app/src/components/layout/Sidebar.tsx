import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';

import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  LayoutDashboard,
  Users,
  Building2,
  Home,
  Handshake,
  DollarSign,
  FileText,
  Megaphone,
  BarChart3,
  Settings,
  Shield,
  ChevronRight,
  ChevronLeft,
  LogOut,
  Award,
  Briefcase,
  MapPin,
  MessageSquare,
  Bell,
  X,
} from 'lucide-react';

interface SidebarProps {
  userRole: 'super_admin' | 'admin' | 'broker' | 'client' | 'developer' | 'owner';
  isCollapsed: boolean;
  onToggle: () => void;
  isMobileOpen: boolean;
  onMobileClose: () => void;
}

interface NavItem {
  title: string;
  titleEn: string;
  href: string;
  icon: React.ElementType;
  badge?: number;
  children?: NavItem[];
  roles: string[];
}

const navigationItems: NavItem[] = [
  {
    title: 'لوحة التحكم',
    titleEn: 'Dashboard',
    href: '/dashboard',
    icon: LayoutDashboard,
    roles: ['super_admin', 'admin', 'broker'],
  },
  {
    title: 'المستخدمون',
    titleEn: 'Users',
    href: '/users',
    icon: Users,
    roles: ['super_admin', 'admin'],
    children: [
      { title: 'جميع المستخدمين', titleEn: 'All Users', href: '/users', icon: Users, roles: ['super_admin', 'admin'] },
      { title: 'إضافة مستخدم', titleEn: 'Add User', href: '/admin/users/add', icon: Users, roles: ['super_admin', 'admin'] },
      { title: 'الصلاحيات', titleEn: 'Permissions', href: '/admin/users/permissions', icon: Shield, roles: ['super_admin', 'admin'] },
      { title: 'الوسطاء', titleEn: 'Brokers', href: '/users/brokers', icon: Briefcase, roles: ['super_admin', 'admin'] },
      { title: 'العملاء', titleEn: 'Clients', href: '/users/clients', icon: Users, roles: ['super_admin', 'admin'] },
      { title: 'المطورين', titleEn: 'Developers', href: '/users/developers', icon: Building2, roles: ['super_admin', 'admin'] },
    ],
  },
  {
    title: 'الشركات',
    titleEn: 'Companies',
    href: '/companies',
    icon: Building2,
    roles: ['super_admin', 'admin'],
  },
  {
    title: 'العقارات',
    titleEn: 'Properties',
    href: '/properties',
    icon: Home,
    badge: 12,
    roles: ['super_admin', 'admin', 'broker'],
    children: [
      { title: 'جميع العقارات', titleEn: 'All Properties', href: '/properties', icon: Home, roles: ['super_admin', 'admin', 'broker'] },
      { title: 'إضافة عقار', titleEn: 'Add Property', href: '/properties/add', icon: MapPin, roles: ['super_admin', 'admin', 'broker'] },
      { title: 'بانتظار الموافقة', titleEn: 'Pending Approval', href: '/properties/pending', icon: Bell, badge: 5, roles: ['super_admin', 'admin'] },
      { title: 'العقارات المميزة', titleEn: 'Featured', href: '/properties/featured', icon: Award, roles: ['super_admin', 'admin'] },
    ],
  },
  {
    title: 'الصفقات',
    titleEn: 'Deals',
    href: '/deals',
    icon: Handshake,
    badge: 3,
    roles: ['super_admin', 'admin', 'broker'],
    children: [
      { title: 'جميع الصفقات', titleEn: 'All Deals', href: '/deals', icon: Handshake, roles: ['super_admin', 'admin', 'broker'] },
      { title: 'بانتظار الموافقة', titleEn: 'Pending Approval', href: '/deals/pending', icon: Bell, badge: 3, roles: ['super_admin', 'admin'] },
      { title: 'المكتملة', titleEn: 'Completed', href: '/deals/completed', icon: Award, roles: ['super_admin', 'admin', 'broker'] },
    ],
  },
  {
    title: 'العمولات',
    titleEn: 'Commissions',
    href: '/commissions',
    icon: DollarSign,
    roles: ['super_admin', 'admin', 'broker'],
    children: [
      { title: 'نظرة عامة', titleEn: 'Overview', href: '/commissions', icon: DollarSign, roles: ['super_admin', 'admin', 'broker'] },
      { title: 'قواعد العمولات', titleEn: 'Rules', href: '/commissions/rules', icon: Settings, roles: ['super_admin', 'admin'] },
      { title: 'التسويات', titleEn: 'Settlements', href: '/commissions/settlements', icon: FileText, roles: ['super_admin', 'admin'] },
    ],
  },
  {
    title: 'طلبات العملاء',
    titleEn: 'Client Requests',
    href: '/requests',
    icon: MessageSquare,
    badge: 8,
    roles: ['super_admin', 'admin', 'broker'],
  },
  {
    title: 'الملفات',
    titleEn: 'Files',
    href: '/files',
    icon: FileText,
    roles: ['super_admin', 'admin', 'broker'],
  },
  {
    title: 'الإعلانات',
    titleEn: 'Advertisements',
    href: '/ads',
    icon: Megaphone,
    roles: ['super_admin', 'admin'],
  },
  {
    title: 'التقارير',
    titleEn: 'Reports',
    href: '/reports',
    icon: BarChart3,
    roles: ['super_admin', 'admin'],
    children: [
      { title: 'لوحة التحكم', titleEn: 'Dashboard', href: '/reports', icon: LayoutDashboard, roles: ['super_admin', 'admin'] },
      { title: 'أداء الوسطاء', titleEn: 'Broker Performance', href: '/reports/brokers', icon: Users, roles: ['super_admin', 'admin'] },
      { title: 'الصفقات', titleEn: 'Deals', href: '/reports/deals', icon: Handshake, roles: ['super_admin', 'admin'] },
      { title: 'الإيرادات', titleEn: 'Revenue', href: '/reports/revenue', icon: DollarSign, roles: ['super_admin', 'admin'] },
    ],
  },
  {
    title: 'الهوية المؤسسية',
    titleEn: 'Corporate Profile',
    href: '/corporate',
    icon: Award,
    roles: ['super_admin', 'admin'],
    children: [
      { title: 'الشهادات', titleEn: 'Certificates', href: '/corporate/certificates', icon: Award, roles: ['super_admin', 'admin'] },
      { title: 'التراخيص', titleEn: 'Licenses', href: '/corporate/licenses', icon: Shield, roles: ['super_admin', 'admin'] },
      { title: 'الشراكات', titleEn: 'Partners', href: '/corporate/partners', icon: Handshake, roles: ['super_admin', 'admin'] },
      { title: 'الإنجازات', titleEn: 'Achievements', href: '/corporate/achievements', icon: BarChart3, roles: ['super_admin', 'admin'] },
    ],
  },
  {
    title: 'الإعدادات',
    titleEn: 'Settings',
    href: '/admin/settings',
    icon: Settings,
    roles: ['super_admin', 'admin'],
  },
];

export function Sidebar({ 
  userRole, 
  isCollapsed, 
  onToggle, 
  isMobileOpen, 
  onMobileClose 
}: SidebarProps) {
  const location = useLocation();
  const [expandedItems, setExpandedItems] = useState<string[]>([]);

  const filteredNavItems = navigationItems.filter(item => 
    item.roles.includes(userRole)
  );

  const toggleExpand = (href: string) => {
    setExpandedItems(prev => 
      prev.includes(href) 
        ? prev.filter(item => item !== href)
        : [...prev, href]
    );
  };

  const isActive = (href: string) => {
    return location.pathname === href || location.pathname.startsWith(href + '/');
  };

  const renderNavItem = (item: NavItem, isChild = false) => {
    const hasChildren = item.children && item.children.length > 0;
    const isExpanded = expandedItems.includes(item.href);
    const active = isActive(item.href);

    if (isCollapsed && !isChild) {
      return (
        <TooltipProvider key={item.href} delayDuration={0}>
          <Tooltip>
            <TooltipTrigger asChild>
              <NavLink
                to={item.href}
                className={cn(
                  'flex items-center justify-center w-10 h-10 rounded-lg mx-auto',
                  'transition-all duration-200',
                  active
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-400 hover:text-white hover:bg-white/10'
                )}
              >
                <item.icon className="w-5 h-5" />
                {item.badge && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </NavLink>
            </TooltipTrigger>
            <TooltipContent side="right" className="bg-slate-800 text-white border-slate-700">
              <p>{item.title}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      );
    }

    return (
      <div key={item.href} className={cn('space-y-1', isChild && 'ml-4')}>
        <NavLink
          to={hasChildren ? '#' : item.href}
          onClick={(e: React.MouseEvent) => {
            if (hasChildren) {
              e.preventDefault();
              toggleExpand(item.href);
            }
          }}
          className={cn(
            'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium',
            'transition-all duration-200',
            active && !hasChildren
              ? 'bg-emerald-600 text-white'
              : 'text-slate-400 hover:text-white hover:bg-white/10'
          )}
        >
          <item.icon className={cn('w-5 h-5', active && !hasChildren && 'text-white')} />
          <span className="flex-1">{item.title}</span>
          {item.badge && (
            <Badge variant="secondary" className="bg-red-500 text-white text-[10px] px-1.5 py-0">
              {item.badge}
            </Badge>
          )}
          {hasChildren && (
            <ChevronRight 
              className={cn(
                'w-4 h-4 transition-transform duration-200',
                isExpanded && 'rotate-90'
              )} 
            />
          )}
        </NavLink>

        {hasChildren && isExpanded && !isCollapsed && (
          <div className="space-y-1 mt-1 animate-in slide-in-from-top-1 duration-200">
            {item.children?.map(child => renderNavItem(child, true))}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onMobileClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 right-0 h-full z-50',
          'bg-gradient-to-b from-slate-900 to-slate-950',
          'border-l border-slate-800',
          'transition-all duration-300 ease-in-out',
          'flex flex-col',
          isCollapsed ? 'w-20' : 'w-72',
          isMobileOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          {!isCollapsed && (
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-white font-bold text-sm">إنابة المستقبل</span>
                <span className="text-slate-400 text-xs">للخدمات العقارية</span>
              </div>
            </div>
          )}
          
          {isCollapsed && (
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center mx-auto">
              <Building2 className="w-6 h-6 text-white" />
            </div>
          )}

          {/* Toggle Button - Desktop Only */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggle}
            className="hidden lg:flex text-slate-400 hover:text-white hover:bg-white/10"
          >
            {isCollapsed ? (
              <ChevronLeft className="w-5 h-5" />
            ) : (
              <ChevronRight className="w-5 h-5" />
            )}
          </Button>

          {/* Close Button - Mobile Only */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onMobileClose}
            className="lg:hidden text-slate-400 hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Navigation */}
        <ScrollArea className="flex-1 py-4 px-3">
          <nav className={cn('space-y-1', isCollapsed && 'space-y-4')}>
            {filteredNavItems.map(item => renderNavItem(item))}
          </nav>
        </ScrollArea>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800">
          {!isCollapsed ? (
            <div className="space-y-3">
              <div className="flex items-center gap-3 px-3 py-2 rounded-lg bg-slate-800/50">
                <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center">
                  <span className="text-white text-xs font-bold">أ</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-medium truncate">أحمد العلي</p>
                  <p className="text-slate-400 text-xs truncate">مدير النظام</p>
                </div>
              </div>
              <Button 
                variant="ghost" 
                className="w-full justify-start gap-3 text-slate-400 hover:text-red-400 hover:bg-red-500/10"
              >
                <LogOut className="w-5 h-5" />
                <span>تسجيل الخروج</span>
              </Button>
            </div>
          ) : (
            <TooltipProvider delayDuration={0}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    className="w-full text-slate-400 hover:text-red-400 hover:bg-red-500/10"
                  >
                    <LogOut className="w-5 h-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="right" className="bg-slate-800 text-white border-slate-700">
                  <p>تسجيل الخروج</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </div>
      </aside>
    </>
  );
}
