import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Search,
  Bell,
  MessageSquare,
  User,
  Settings,
  LogOut,
  Menu,
  Globe,
  Moon,
  Sun,
  ChevronDown,
  Building2,
} from 'lucide-react';
import { notifications } from '@/data/mockData';

interface HeaderProps {
  onMenuClick: () => void;
  isSidebarCollapsed: boolean;
}

export function Header({ onMenuClick, isSidebarCollapsed }: HeaderProps) {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentLang, setCurrentLang] = useState<'ar' | 'en' | 'id'>('ar');
  const unreadNotifications = notifications.filter(n => !n.isRead).length;

  const languages = [
    { code: 'ar' as const, name: 'العربية', flag: '🇸🇦' },
    { code: 'en' as const, name: 'English', flag: '🇬🇧' },
    { code: 'id' as const, name: 'Bahasa Indonesia', flag: '🇮🇩' },
  ];

  return (
    <header 
      className={cn(
        'fixed top-0 left-0 right-0 h-16 z-30',
        'bg-white/80 backdrop-blur-xl border-b border-slate-200',
        'transition-all duration-300',
        isSidebarCollapsed ? 'lg:right-20' : 'lg:right-72'
      )}
    >
      <div className="h-full px-4 flex items-center justify-between gap-4">
        {/* Left Section - Search & Menu */}
        <div className="flex items-center gap-3 flex-1">
          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onMenuClick}
            className="lg:hidden text-slate-600 hover:text-emerald-600 hover:bg-emerald-50"
          >
            <Menu className="w-5 h-5" />
          </Button>

          {/* Search */}
          <div className="relative max-w-md w-full hidden sm:block">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              type="search"
              placeholder="البحث في المنصة..."
              className="pr-10 pl-4 h-10 bg-slate-100 border-0 focus:bg-white focus:ring-2 focus:ring-emerald-500/20"
            />
          </div>
        </div>

        {/* Right Section - Actions */}
        <div className="flex items-center gap-2">
          {/* Language Switcher */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="gap-2 text-slate-600 hover:text-emerald-600 hover:bg-emerald-50"
              >
                <Globe className="w-4 h-4" />
                <span className="hidden sm:inline">
                  {languages.find(l => l.code === currentLang)?.name}
                </span>
                <ChevronDown className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel>اختر اللغة</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {languages.map(lang => (
                <DropdownMenuItem
                  key={lang.code}
                  onClick={() => setCurrentLang(lang.code)}
                  className={cn(
                    'gap-2 cursor-pointer',
                    currentLang === lang.code && 'bg-emerald-50 text-emerald-600'
                  )}
                >
                  <span>{lang.flag}</span>
                  <span>{lang.name}</span>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Dark Mode Toggle */}
          <TooltipProvider delayDuration={0}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsDarkMode(!isDarkMode)}
                  className="text-slate-600 hover:text-emerald-600 hover:bg-emerald-50"
                >
                  {isDarkMode ? (
                    <Sun className="w-4 h-4" />
                  ) : (
                    <Moon className="w-4 h-4" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{isDarkMode ? 'الوضع النهاري' : 'الوضع الليلي'}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          {/* Messages */}
          <TooltipProvider delayDuration={0}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="relative text-slate-600 hover:text-emerald-600 hover:bg-emerald-50"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                    3
                  </span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>الرسائل</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="relative text-slate-600 hover:text-emerald-600 hover:bg-emerald-50"
              >
                <Bell className="w-4 h-4" />
                {unreadNotifications > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                    {unreadNotifications}
                  </span>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <DropdownMenuLabel className="flex items-center justify-between">
                <span>الإشعارات</span>
                <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                  {unreadNotifications} جديد
                </Badge>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <div className="max-h-80 overflow-y-auto">
                {notifications.slice(0, 5).map((notification) => (
                  <DropdownMenuItem
                    key={notification.id}
                    className={cn(
                      'flex flex-col items-start gap-1 p-3 cursor-pointer',
                      !notification.isRead && 'bg-slate-50'
                    )}
                  >
                    <div className="flex items-center gap-2 w-full">
                      <span className={cn(
                        'w-2 h-2 rounded-full',
                        !notification.isRead ? 'bg-emerald-500' : 'bg-slate-300'
                      )} />
                      <span className="font-medium text-sm flex-1">{notification.title}</span>
                      <span className="text-xs text-slate-400">
                        {new Date(notification.createdAt).toLocaleDateString('ar-SA')}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 pr-4 line-clamp-2">
                      {notification.message}
                    </p>
                  </DropdownMenuItem>
                ))}
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild className="justify-center cursor-pointer">
                <NavLink to="/notifications" className="text-emerald-600 text-sm">
                  عرض جميع الإشعارات
                </NavLink>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User Profile */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="gap-2 pl-2 hover:bg-emerald-50"
              >
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center">
                  <span className="text-white text-sm font-bold">أ</span>
                </div>
                <div className="hidden md:flex flex-col items-start">
                  <span className="text-sm font-medium text-slate-700">أحمد العلي</span>
                  <span className="text-xs text-slate-400">مدير النظام</span>
                </div>
                <ChevronDown className="w-4 h-4 text-slate-400 hidden md:block" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>حسابي</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild className="cursor-pointer">
                <NavLink to="/profile" className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  <span>الملف الشخصي</span>
                </NavLink>
              </DropdownMenuItem>
              <DropdownMenuItem asChild className="cursor-pointer">
                <NavLink to="/settings" className="flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  <span>الإعدادات</span>
                </NavLink>
              </DropdownMenuItem>
              <DropdownMenuItem asChild className="cursor-pointer">
                <NavLink to="/company" className="flex items-center gap-2">
                  <Building2 className="w-4 h-4" />
                  <span>الشركة</span>
                </NavLink>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-600 cursor-pointer">
                <LogOut className="w-4 h-4 mr-2" />
                <span>تسجيل الخروج</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
