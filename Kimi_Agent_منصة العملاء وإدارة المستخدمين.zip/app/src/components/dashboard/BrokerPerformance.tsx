import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { 
  Trophy, 
  Home, 
  Handshake, 
  DollarSign,
  ArrowUpRight,
  Medal,
  Award,
  Star
} from 'lucide-react';
import { brokerPerformance } from '@/data/mockData';

interface BrokerPerformanceProps {
  className?: string;
}

const getRankIcon = (rank: number) => {
  switch (rank) {
    case 1:
      return <Trophy className="w-5 h-5 text-yellow-500" />;
    case 2:
      return <Medal className="w-5 h-5 text-slate-400" />;
    case 3:
      return <Award className="w-5 h-5 text-amber-600" />;
    default:
      return <Star className="w-5 h-5 text-slate-300" />;
  }
};

const getRankColor = (rank: number) => {
  switch (rank) {
    case 1:
      return 'bg-yellow-50 border-yellow-200';
    case 2:
      return 'bg-slate-50 border-slate-200';
    case 3:
      return 'bg-amber-50 border-amber-200';
    default:
      return 'bg-white border-slate-100';
  }
};

export function BrokerPerformanceList({ className }: BrokerPerformanceProps) {
  const formatCurrency = (value: number) => {
    if (value >= 1000000) {
      return `${(value / 1000000).toFixed(2)}M`;
    }
    if (value >= 1000) {
      return `${(value / 1000).toFixed(0)}K`;
    }
    return value.toString();
  };

  const maxCommission = Math.max(...brokerPerformance.map(b => b.totalCommission));

  return (
    <Card className={cn('overflow-hidden', className)}>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="text-lg font-bold text-slate-900">
              أداء الوسطاء
            </CardTitle>
            <p className="text-sm text-slate-500">
              أفضل الوسطاء حسب العمولات
            </p>
          </div>
          <Button variant="ghost" size="sm" className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50">
            عرض الكل
            <ArrowUpRight className="w-4 h-4 mr-1" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="divide-y divide-slate-100">
          {brokerPerformance.map((broker, index) => (
            <div 
              key={broker.brokerId}
              className={cn(
                'p-4 transition-colors hover:bg-slate-50',
                index === 0 && 'bg-yellow-50/50'
              )}
            >
              <div className="flex items-center gap-4">
                {/* Rank */}
                <div className="flex flex-col items-center justify-center w-10">
                  {getRankIcon(broker.rank)}
                  <span className="text-xs font-bold text-slate-500 mt-1">
                    #{broker.rank}
                  </span>
                </div>

                {/* Avatar */}
                <Avatar className="w-12 h-12 border-2 border-white shadow-sm">
                  <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-emerald-700 text-white font-bold">
                    {broker.brokerName.charAt(0)}
                  </AvatarFallback>
                </Avatar>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-slate-900 truncate">
                    {broker.brokerName}
                  </h4>
                  
                  {/* Stats Grid */}
                  <div className="grid grid-cols-3 gap-2 mt-2">
                    <div className="flex items-center gap-1.5 text-xs text-slate-500">
                      <Home className="w-3 h-3" />
                      <span>{broker.totalListings} إدراج</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-slate-500">
                      <Handshake className="w-3 h-3" />
                      <span>{broker.totalDeals} صفقة</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-slate-500">
                      <DollarSign className="w-3 h-3" />
                      <span>{formatCurrency(broker.totalSales)}</span>
                    </div>
                  </div>

                  {/* Commission Progress */}
                  <div className="mt-3">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-slate-500">العمولة</span>
                      <span className="font-medium text-emerald-600">
                        {formatCurrency(broker.totalCommission)} ر.س
                      </span>
                    </div>
                    <Progress 
                      value={(broker.totalCommission / maxCommission) * 100} 
                      className="h-1.5"
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// Compact version for dashboard
export function BrokerPerformanceCompact({ className }: BrokerPerformanceProps) {
  const formatCurrency = (value: number) => {
    if (value >= 1000000) {
      return `${(value / 1000000).toFixed(1)}M`;
    }
    if (value >= 1000) {
      return `${(value / 1000).toFixed(0)}K`;
    }
    return value.toString();
  };

  return (
    <Card className={cn('overflow-hidden', className)}>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-500" />
              أفضل الوسطاء
            </CardTitle>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          {brokerPerformance.slice(0, 3).map((broker) => (
            <div 
              key={broker.brokerId}
              className={cn(
                'flex items-center gap-3 p-3 rounded-xl border',
                getRankColor(broker.rank)
              )}
            >
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white shadow-sm">
                {getRankIcon(broker.rank)}
              </div>
              
              <Avatar className="w-10 h-10">
                <AvatarFallback className="bg-emerald-100 text-emerald-700 text-sm font-bold">
                  {broker.brokerName.charAt(0)}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0">
                <p className="font-medium text-slate-900 text-sm truncate">
                  {broker.brokerName}
                </p>
                <p className="text-xs text-slate-500">
                  {broker.totalDeals} صفقة • {broker.totalListings} إدراج
                </p>
              </div>
              
              <div className="text-left">
                <p className="font-bold text-emerald-600 text-sm">
                  {formatCurrency(broker.totalCommission)}
                </p>
                <p className="text-[10px] text-slate-400">ر.س</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
