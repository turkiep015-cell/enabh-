import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { 
  ArrowUpRight, 
  Handshake, 
  Clock, 
  CheckCircle2, 
  XCircle,
  TrendingUp
} from 'lucide-react';
import { deals } from '@/data/mockData';
import type { Deal } from '@/types';

interface DealStatusBadgeProps {
  status: Deal['status'];
}

function DealStatusBadge({ status }: DealStatusBadgeProps) {
  const config = {
    pending: {
      label: 'معلقة',
      className: 'bg-amber-100 text-amber-700 border-amber-200',
      icon: Clock,
    },
    approved: {
      label: 'معتمدة',
      className: 'bg-blue-100 text-blue-700 border-blue-200',
      icon: CheckCircle2,
    },
    completed: {
      label: 'مكتملة',
      className: 'bg-emerald-100 text-emerald-700 border-emerald-200',
      icon: CheckCircle2,
    },
    cancelled: {
      label: 'ملغاة',
      className: 'bg-red-100 text-red-700 border-red-200',
      icon: XCircle,
    },
  };

  const { label, className, icon: Icon } = config[status];

  return (
    <Badge variant="outline" className={cn('gap-1 font-medium', className)}>
      <Icon className="w-3 h-3" />
      {label}
    </Badge>
  );
}

interface RecentDealsProps {
  className?: string;
}

export function RecentDeals({ className }: RecentDealsProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <Card className={cn('overflow-hidden', className)}>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="text-lg font-bold text-slate-900">
              آخر الصفقات
            </CardTitle>
            <p className="text-sm text-slate-500">
              آخر 5 صفقات تم إبرامها
            </p>
          </div>
          <Button variant="ghost" size="sm" className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50">
            عرض الكل
            <ArrowUpRight className="w-4 h-4 mr-1" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]">
          <div className="divide-y divide-slate-100">
            {deals.map((deal) => (
              <div 
                key={deal.id} 
                className="p-4 hover:bg-slate-50 transition-colors group"
              >
                <div className="flex items-start justify-between gap-4">
                  {/* Left - Deal Info */}
                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-slate-900">
                        {deal.dealNumber}
                      </span>
                      <DealStatusBadge status={deal.status} />
                    </div>
                    
                    <p className="text-sm text-slate-600 line-clamp-1">
                      {deal.property?.titleAr}
                    </p>
                    
                    <div className="flex items-center gap-4 text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <Handshake className="w-3 h-3" />
                        {deal.listingAgentId === deal.sellingAgentId 
                          ? 'وسيط واحد' 
                          : 'وسيطان'
                        }
                      </span>
                      <span>
                        {new Date(deal.createdAt).toLocaleDateString('ar-SA', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                        })}
                      </span>
                    </div>
                  </div>

                  {/* Right - Financial Info */}
                  <div className="text-left space-y-1">
                    <p className="text-lg font-bold text-emerald-600">
                      {formatCurrency(deal.salePrice)}
                    </p>
                    <div className="flex items-center gap-1 text-xs text-slate-500">
                      <TrendingUp className="w-3 h-3" />
                      <span>عمولة: {formatCurrency(deal.totalCommission)}</span>
                    </div>
                  </div>
                </div>

                {/* Agents */}
                <div className="flex items-center gap-4 mt-3 pt-3 border-t border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500">وسيط الإدراج:</span>
                    <Avatar className="w-6 h-6">
                      <AvatarFallback className="bg-emerald-100 text-emerald-700 text-[10px]">
                        م
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  {deal.sellingAgentId && deal.sellingAgentId !== deal.listingAgentId && (
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-500">وسيط البيع:</span>
                      <Avatar className="w-6 h-6">
                        <AvatarFallback className="bg-blue-100 text-blue-700 text-[10px]">
                          خ
                        </AvatarFallback>
                      </Avatar>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
