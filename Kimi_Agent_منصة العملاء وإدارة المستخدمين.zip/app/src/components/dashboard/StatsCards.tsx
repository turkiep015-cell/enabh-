import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  TrendingUp,
  TrendingDown,
  Home,
  Handshake,
  DollarSign,
  Users,
  Clock,
  CheckCircle2,
  type LucideIcon,
} from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  icon: LucideIcon;
  iconColor?: string;
  iconBgColor?: string;
  className?: string;
}

function StatCard({ 
  title, 
  value, 
  subtitle, 
  trend, 
  icon: Icon,
  iconColor = 'text-emerald-600',
  iconBgColor = 'bg-emerald-100',
  className 
}: StatCardProps) {
  return (
    <Card className={cn(
      'group overflow-hidden transition-all duration-300',
      'hover:shadow-lg hover:-translate-y-0.5',
      'border-slate-200 hover:border-emerald-200',
      className
    )}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="space-y-3">
            <p className="text-sm font-medium text-slate-500">{title}</p>
            <div className="space-y-1">
              <h3 className="text-2xl font-bold text-slate-900">{value}</h3>
              {subtitle && (
                <p className="text-xs text-slate-400">{subtitle}</p>
              )}
            </div>
            {trend && (
              <div className="flex items-center gap-1.5">
                <Badge 
                  variant="secondary" 
                  className={cn(
                    'text-xs font-medium',
                    trend.isPositive 
                      ? 'bg-emerald-100 text-emerald-700' 
                      : 'bg-red-100 text-red-700'
                  )}
                >
                  {trend.isPositive ? (
                    <TrendingUp className="w-3 h-3 ml-1" />
                  ) : (
                    <TrendingDown className="w-3 h-3 ml-1" />
                  )}
                  {Math.abs(trend.value)}%
                </Badge>
                <span className="text-xs text-slate-400">من الشهر الماضي</span>
              </div>
            )}
          </div>
          
          <div className={cn(
            'w-12 h-12 rounded-xl flex items-center justify-center',
            'transition-transform duration-300 group-hover:scale-110',
            iconBgColor
          )}>
            <Icon className={cn('w-6 h-6', iconColor)} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface StatsCardsProps {
  stats: {
    totalProperties: number;
    activeProperties: number;
    totalDeals: number;
    pendingDeals: number;
    totalCommission: number;
    pendingCommission: number;
    totalBrokers: number;
    totalClients: number;
    monthlyGrowth: number;
  };
}

export function StatsCards({ stats }: StatsCardsProps) {
  const formatCurrency = (value: number) => {
    if (value >= 1000000) {
      return `${(value / 1000000).toFixed(1)}M`;
    }
    if (value >= 1000) {
      return `${(value / 1000).toFixed(0)}K`;
    }
    return value.toString();
  };

  const cards = [
    {
      title: 'إجمالي العقارات',
      value: stats.totalProperties.toLocaleString('ar-SA'),
      subtitle: `${stats.activeProperties} عقار نشط`,
      trend: { value: 12.5, isPositive: true },
      icon: Home,
      iconColor: 'text-blue-600',
      iconBgColor: 'bg-blue-100',
    },
    {
      title: 'الصفقات',
      value: stats.totalDeals.toLocaleString('ar-SA'),
      subtitle: `${stats.pendingDeals} بانتظار الموافقة`,
      trend: { value: 8.2, isPositive: true },
      icon: Handshake,
      iconColor: 'text-emerald-600',
      iconBgColor: 'bg-emerald-100',
    },
    {
      title: 'إجمالي العمولات',
      value: `${formatCurrency(stats.totalCommission)} ر.س`,
      subtitle: `${formatCurrency(stats.pendingCommission)} مستحقة`,
      trend: { value: 23.5, isPositive: true },
      icon: DollarSign,
      iconColor: 'text-amber-600',
      iconBgColor: 'bg-amber-100',
    },
    {
      title: 'الوسطاء النشطين',
      value: stats.totalBrokers.toLocaleString('ar-SA'),
      subtitle: `${stats.totalClients} عميل مسجل`,
      trend: { value: 15.3, isPositive: true },
      icon: Users,
      iconColor: 'text-purple-600',
      iconBgColor: 'bg-purple-100',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((card, index) => (
        <StatCard key={index} {...card} />
      ))}
    </div>
  );
}

// Extended Stats for detailed dashboard
export function ExtendedStatsCards({ stats }: StatsCardsProps) {
  const formatCurrency = (value: number) => {
    if (value >= 1000000) {
      return `${(value / 1000000).toFixed(2)} مليون`;
    }
    if (value >= 1000) {
      return `${(value / 1000).toFixed(0)} ألف`;
    }
    return value.toString();
  };

  const extendedCards = [
    {
      title: 'العقارات المدرجة',
      value: stats.totalProperties,
      subtitle: `${((stats.activeProperties / stats.totalProperties) * 100).toFixed(0)}% نشطة`,
      trend: { value: 12.5, isPositive: true },
      icon: Home,
      iconColor: 'text-blue-600',
      iconBgColor: 'bg-blue-100',
    },
    {
      title: 'الصفقات المكتملة',
      value: stats.totalDeals - stats.pendingDeals,
      subtitle: `${stats.pendingDeals} معلقة`,
      trend: { value: 8.2, isPositive: true },
      icon: CheckCircle2,
      iconColor: 'text-emerald-600',
      iconBgColor: 'bg-emerald-100',
    },
    {
      title: 'العمولات المدفوعة',
      value: formatCurrency(stats.totalCommission - stats.pendingCommission),
      subtitle: `${formatCurrency(stats.pendingCommission)} معلقة`,
      trend: { value: 18.7, isPositive: true },
      icon: DollarSign,
      iconColor: 'text-amber-600',
      iconBgColor: 'bg-amber-100',
    },
    {
      title: 'طلبات العملاء',
      value: '24',
      subtitle: '8 جديدة هذا الأسبوع',
      trend: { value: 5.4, isPositive: true },
      icon: Clock,
      iconColor: 'text-purple-600',
      iconBgColor: 'bg-purple-100',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {extendedCards.map((card, index) => (
        <StatCard key={index} {...card} />
      ))}
    </div>
  );
}
