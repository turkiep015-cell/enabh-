import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  Bed,
  Bath,
  Maximize,
  MapPin,
  Heart,
  Share2,
  Eye,
  Phone,
  MessageSquare,
  Star,
} from 'lucide-react';
import type { Property } from '@/types';

interface PropertyCardProps {
  property: Property;
  variant?: 'default' | 'compact' | 'featured' | 'horizontal';
  showActions?: boolean;
  className?: string;
}

const statusConfig = {
  active: { label: 'متاح', className: 'bg-emerald-100 text-emerald-700' },
  reserved: { label: 'محجوز', className: 'bg-amber-100 text-amber-700' },
  sold: { label: 'مباع', className: 'bg-red-100 text-red-700' },
  inactive: { label: 'غير نشط', className: 'bg-slate-100 text-slate-600' },
};

export function PropertyCard({ 
  property, 
  variant = 'default',
  showActions = true,
  className 
}: PropertyCardProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  const formatPrice = (price: number) => {
    if (price >= 1000000) {
      return `${(price / 1000000).toFixed(price % 1000000 === 0 ? 0 : 2)} مليون`;
    }
    if (price >= 1000) {
      return `${(price / 1000).toFixed(0)} ألف`;
    }
    return price.toString();
  };

  const mainImage = property.images?.find(img => img.isMain)?.imageUrl 
    || property.images?.[0]?.imageUrl 
    || 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600&h=400&fit=crop';

  if (variant === 'horizontal') {
    return (
      <Card className={cn(
        'overflow-hidden transition-all duration-300',
        'hover:shadow-lg hover:border-emerald-200',
        className
      )}>
        <div className="flex flex-col sm:flex-row">
          {/* Image */}
          <div className="relative w-full sm:w-48 h-48 sm:h-auto flex-shrink-0">
            <img
              src={mainImage}
              alt={property.titleAr}
              className="w-full h-full object-cover"
              onLoad={() => setImageLoaded(true)}
            />
            {!imageLoaded && (
              <div className="absolute inset-0 bg-slate-200 animate-pulse" />
            )}
            
            {/* Badges */}
            <div className="absolute top-3 right-3 flex flex-col gap-2">
              {property.isFeatured && (
                <Badge className="bg-amber-500 text-white gap-1">
                  <Star className="w-3 h-3" />
                  مميز
                </Badge>
              )}
              <Badge className={cn(statusConfig[property.status].className)}>
                {statusConfig[property.status].label}
              </Badge>
            </div>

            {/* Listing Type */}
            <div className="absolute top-3 left-3">
              <Badge variant="secondary" className="bg-white/90 text-slate-700">
                {property.listingType === 'sale' ? 'للبيع' : 'للإيجار'}
              </Badge>
            </div>
          </div>

          {/* Content */}
          <CardContent className="flex-1 p-4">
            <div className="flex flex-col h-full">
              <div className="flex-1">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-bold text-slate-900 line-clamp-1">
                    {property.titleAr}
                  </h3>
                  <p className="text-lg font-bold text-emerald-600 whitespace-nowrap">
                    {formatPrice(property.price)} <span className="text-sm">ر.س</span>
                  </p>
                </div>

                <div className="flex items-center gap-1 text-slate-500 text-sm mt-2">
                  <MapPin className="w-4 h-4" />
                  <span className="line-clamp-1">{property.address}</span>
                </div>

                {/* Features */}
                <div className="flex items-center gap-4 mt-3">
                  {property.bedrooms && (
                    <div className="flex items-center gap-1 text-sm text-slate-600">
                      <Bed className="w-4 h-4" />
                      <span>{property.bedrooms}</span>
                    </div>
                  )}
                  {property.bathrooms && (
                    <div className="flex items-center gap-1 text-sm text-slate-600">
                      <Bath className="w-4 h-4" />
                      <span>{property.bathrooms}</span>
                    </div>
                  )}
                  {property.area && (
                    <div className="flex items-center gap-1 text-sm text-slate-600">
                      <Maximize className="w-4 h-4" />
                      <span>{property.area} م²</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Actions */}
              {showActions && (
                <div className="flex items-center gap-2 mt-4 pt-4 border-t border-slate-100">
                  <Button size="sm" className="flex-1 bg-emerald-600 hover:bg-emerald-700">
                    <Phone className="w-4 h-4 mr-1" />
                    اتصال
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1">
                    <MessageSquare className="w-4 h-4 mr-1" />
                    رسالة
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => setIsLiked(!isLiked)}
                    className={cn(
                      'transition-colors',
                      isLiked && 'text-red-500 hover:text-red-600'
                    )}
                  >
                    <Heart className={cn('w-5 h-5', isLiked && 'fill-current')} />
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </div>
      </Card>
    );
  }

  if (variant === 'compact') {
    return (
      <Card className={cn(
        'overflow-hidden transition-all duration-300',
        'hover:shadow-lg hover:border-emerald-200',
        className
      )}>
        <div className="relative h-32">
          <img
            src={mainImage}
            alt={property.titleAr}
            className="w-full h-full object-cover"
          />
          <div className="absolute top-2 right-2">
            <Badge className={cn('text-xs', statusConfig[property.status].className)}>
              {statusConfig[property.status].label}
            </Badge>
          </div>
        </div>
        <CardContent className="p-3">
          <h4 className="font-medium text-slate-900 text-sm line-clamp-1">
            {property.titleAr}
          </h4>
          <p className="text-emerald-600 font-bold text-sm mt-1">
            {formatPrice(property.price)} ر.س
          </p>
        </CardContent>
      </Card>
    );
  }

  // Default variant
  return (
    <Card className={cn(
      'overflow-hidden transition-all duration-300 group',
      'hover:shadow-xl hover:-translate-y-1 hover:border-emerald-200',
      variant === 'featured' && 'ring-2 ring-amber-400 ring-offset-2',
      className
    )}>
      {/* Image */}
      <div className="relative h-56 overflow-hidden">
        <img
          src={mainImage}
          alt={property.titleAr}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          onLoad={() => setImageLoaded(true)}
        />
        {!imageLoaded && (
          <div className="absolute inset-0 bg-slate-200 animate-pulse" />
        )}

        {/* Overlay Gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

        {/* Badges */}
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          {property.isFeatured && (
            <Badge className="bg-amber-500 text-white gap-1 shadow-lg">
              <Star className="w-3 h-3" />
              مميز
            </Badge>
          )}
          <Badge className={cn(statusConfig[property.status].className)}>
            {statusConfig[property.status].label}
          </Badge>
        </div>

        {/* Listing Type */}
        <div className="absolute top-4 left-4">
          <Badge variant="secondary" className="bg-white/90 text-slate-700 shadow-lg">
            {property.listingType === 'sale' ? 'للبيع' : 'للإيجار'}
          </Badge>
        </div>

        {/* Price */}
        <div className="absolute bottom-4 right-4">
          <p className="text-2xl font-bold text-white drop-shadow-lg">
            {formatPrice(property.price)}
            <span className="text-sm font-normal mr-1">ر.س</span>
          </p>
        </div>

        {/* Actions */}
        {showActions && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              size="icon"
              variant="secondary"
              className="bg-white/90 hover:bg-white shadow-lg"
              onClick={() => setIsLiked(!isLiked)}
            >
              <Heart className={cn('w-5 h-5', isLiked && 'fill-red-500 text-red-500')} />
            </Button>
            <Button
              size="icon"
              variant="secondary"
              className="bg-white/90 hover:bg-white shadow-lg"
            >
              <Share2 className="w-5 h-5" />
            </Button>
          </div>
        )}
      </div>

      {/* Content */}
      <CardContent className="p-5">
        <h3 className="font-bold text-slate-900 text-lg line-clamp-1 mb-2">
          {property.titleAr}
        </h3>

        <div className="flex items-center gap-1 text-slate-500 text-sm mb-4">
          <MapPin className="w-4 h-4 flex-shrink-0" />
          <span className="line-clamp-1">{property.city?.nameAr} {property.address && `- ${property.address}`}</span>
        </div>

        {/* Features */}
        <div className="flex items-center justify-between py-3 border-y border-slate-100">
          {property.bedrooms ? (
            <div className="flex flex-col items-center gap-1">
              <Bed className="w-5 h-5 text-slate-400" />
              <span className="text-sm text-slate-600">{property.bedrooms} غرف</span>
            </div>
          ) : (
            <div />
          )}
          {property.bathrooms ? (
            <div className="flex flex-col items-center gap-1">
              <Bath className="w-5 h-5 text-slate-400" />
              <span className="text-sm text-slate-600">{property.bathrooms} حمام</span>
            </div>
          ) : (
            <div />
          )}
          {property.area ? (
            <div className="flex flex-col items-center gap-1">
              <Maximize className="w-5 h-5 text-slate-400" />
              <span className="text-sm text-slate-600">{property.area} م²</span>
            </div>
          ) : (
            <div />
          )}
        </div>

        {/* Footer */}
        {showActions && (
          <div className="flex items-center justify-between mt-4">
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <Eye className="w-4 h-4" />
              <span>{property.viewCount}</span>
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline">
                التفاصيل
              </Button>
              <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700">
                <Phone className="w-4 h-4 mr-1" />
                اتصال
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
