// ============================================
// Inabah Real Estate Platform - TypeScript Types
// ============================================

// User & Authentication Types
export interface User {
  id: string;
  email: string;
  phone?: string;
  fullName: string;
  fullNameEn?: string;
  avatarUrl?: string;
  role: UserRole;
  companyId?: string;
  company?: Company;
  isActive: boolean;
  emailVerified: boolean;
  phoneVerified: boolean;
  lastLoginAt?: string;
  preferredLanguage: 'ar' | 'en' | 'id';
  createdAt: string;
}

export type UserRole = 'super_admin' | 'admin' | 'broker' | 'client' | 'developer' | 'owner';

export interface Role {
  id: string;
  name: UserRole;
  nameAr: string;
  nameEn: string;
  permissions: Permission[];
  description?: string;
  isSystem: boolean;
}

export interface Permission {
  resource: string;
  actions: ('create' | 'read' | 'update' | 'delete' | 'approve' | 'pay')[];
}

// Company Types
export interface Company {
  id: string;
  name: string;
  nameEn?: string;
  type: CompanyType;
  crNumber?: string;
  licenseNumber?: string;
  taxNumber?: string;
  address?: string;
  phone?: string;
  email?: string;
  logoUrl?: string;
  website?: string;
  status: 'pending' | 'active' | 'suspended';
  verifiedAt?: string;
  createdBy?: string;
  createdAt: string;
}

export type CompanyType = 'developer' | 'brokerage' | 'owner';

// Property Types
export interface Property {
  id: string;
  titleAr: string;
  titleEn?: string;
  descriptionAr?: string;
  descriptionEn?: string;
  type: PropertyType;
  typeId: string;
  
  // Location
  city: City;
  cityId: string;
  district?: District;
  districtId?: string;
  address?: string;
  latitude?: number;
  longitude?: number;
  
  // Details
  price: number;
  area?: number;
  bedrooms?: number;
  bathrooms?: number;
  floorNumber?: number;
  totalFloors?: number;
  yearBuilt?: number;
  furnishingStatus?: 'furnished' | 'semi_furnished' | 'unfurnished';
  
  // Features
  features?: PropertyFeature[];
  images?: PropertyImage[];
  
  // Status
  status: PropertyStatus;
  listingType: 'sale' | 'rent';
  
  // Relations
  listedBy: string;
  listedByUser?: User;
  companyId?: string;
  company?: Company;
  projectId?: string;
  project?: Project;
  
  // Approval
  isApproved: boolean;
  approvedBy?: string;
  approvedAt?: string;
  
  // Featured
  isFeatured: boolean;
  featuredUntil?: string;
  
  // Stats
  viewCount: number;
  inquiryCount: number;
  
  createdAt: string;
  updatedAt: string;
}

export type PropertyStatus = 'active' | 'reserved' | 'sold' | 'inactive';

export interface PropertyType {
  id: string;
  nameAr: string;
  nameEn: string;
  icon?: string;
  isActive: boolean;
}

export interface PropertyFeature {
  id: string;
  propertyId: string;
  featureName: string;
  featureValue: string;
}

export interface PropertyImage {
  id: string;
  propertyId: string;
  imageUrl: string;
  isMain: boolean;
  sortOrder: number;
}

export interface City {
  id: string;
  nameAr: string;
  nameEn: string;
  regionId?: string;
  isActive: boolean;
}

export interface District {
  id: string;
  nameAr: string;
  nameEn: string;
  cityId: string;
  isActive: boolean;
}

// Project Types
export interface Project {
  id: string;
  name: string;
  nameEn?: string;
  description?: string;
  descriptionEn?: string;
  developerId: string;
  developer?: User;
  companyId?: string;
  company?: Company;
  
  // Location
  cityId: string;
  city?: City;
  districtId?: string;
  district?: District;
  address?: string;
  latitude?: number;
  longitude?: number;
  
  // Media
  images?: string[];
  videoUrl?: string;
  pdfFiles?: string[];
  
  // Status
  status: ProjectStatus;
  
  // Features
  amenities?: string[];
  
  // Stats
  totalUnits?: number;
  availableUnits?: number;
  soldUnits?: number;
  
  createdAt: string;
  updatedAt: string;
}

export type ProjectStatus = 'selling' | 'completed' | 'closed';

// Deal & Commission Types
export interface Deal {
  id: string;
  dealNumber: string;
  propertyId: string;
  property?: Property;
  
  // Parties
  buyerId?: string;
  buyer?: User;
  sellerId?: string;
  seller?: User;
  listingAgentId?: string;
  listingAgent?: User;
  sellingAgentId?: string;
  sellingAgent?: User;
  
  // Financial Details
  salePrice: number;
  commissionRate: number;
  totalCommission: number;
  
  // Commissions
  commissions?: DealCommission[];
  
  // Status
  status: DealStatus;
  
  // Approval
  approvedBy?: string;
  approvedAt?: string;
  
  // Dates
  expectedCloseDate?: string;
  actualCloseDate?: string;
  
  notes?: string;
  createdAt: string;
}

export type DealStatus = 'pending' | 'approved' | 'completed' | 'cancelled';

export interface DealCommission {
  id: string;
  dealId: string;
  userId: string;
  user?: User;
  roleType: 'listing_agent' | 'selling_agent';
  percentage: number;
  amount: number;
  status: 'pending' | 'approved' | 'paid';
  paidAt?: string;
  paidBy?: string;
  paymentReference?: string;
  createdAt: string;
}

export interface CommissionRule {
  id: string;
  name: string;
  description?: string;
  baseRate: number;
  listingPercentage: number;
  sellingPercentage: number;
  appliesTo: 'all' | 'project' | 'property_type' | 'user';
  projectId?: string;
  propertyTypeId?: string;
  userId?: string;
  isActive: boolean;
  validFrom?: string;
  validUntil?: string;
  priority: number;
  createdBy?: string;
  createdAt: string;
}

// Client Request Types
export interface ClientRequest {
  id: string;
  requestNumber: string;
  clientId: string;
  client?: User;
  
  // Details
  requestType: 'buy' | 'rent' | 'invest';
  budgetMin?: number;
  budgetMax?: number;
  
  // Location
  cityId?: string;
  city?: City;
  districtIds?: string[];
  
  // Property Type
  propertyTypeIds?: string[];
  
  // Requirements
  minArea?: number;
  maxArea?: number;
  bedroomsMin?: number;
  bedroomsMax?: number;
  
  // Status
  status: RequestStatus;
  
  // Related Property (if request is for a specific property)
  propertyId?: string;
  property?: Property;
  
  // Feedback
  satisfactionRating?: number;
  feedback?: string;
  
  assignedTo?: string;
  assignedToUser?: User;
  
  // Matches
  matches?: RequestMatch[];
  
  // Notes
  notes?: string;
  
  createdAt: string;
}

export type RequestStatus = 'open' | 'in_progress' | 'closed' | 'cancelled';

export interface RequestMatch {
  id: string;
  requestId: string;
  propertyId: string;
  property?: Property;
  matchScore: number;
  status: 'suggested' | 'viewed' | 'contacted' | 'rejected';
  createdAt: string;
}

// Advertisement Types
export interface Advertisement {
  id: string;
  title: string;
  subtitle?: string;
  imageUrl: string;
  imageMobileUrl?: string;
  linkUrl?: string;
  positionId: string;
  position?: AdPosition;
  targetAudience: 'all' | 'brokers' | 'clients';
  targetPages?: string[];
  startDate: string;
  endDate: string;
  priority: number;
  status: AdStatus;
  impressions: number;
  clicks: number;
  createdBy?: string;
  createdAt: string;
}

export interface AdPosition {
  id: string;
  name: string;
  location: string;
  sizeWidth: number;
  sizeHeight: number;
  priceDaily: number;
  isActive: boolean;
}

export type AdStatus = 'pending' | 'active' | 'paused' | 'expired';

// Corporate Profile Types
export interface Certificate {
  id: string;
  name: string;
  issuer: string;
  imageUrl?: string;
  pdfUrl?: string;
  issueDate?: string;
  expiryDate?: string;
  isPublic: boolean;
  createdAt: string;
}

export interface License {
  id: string;
  licenseNumber: string;
  issuer: string;
  issueDate?: string;
  expiryDate?: string;
  status: 'active' | 'expired' | 'pending_renewal';
  alertDays: number;
  isPublic: boolean;
  createdAt: string;
}

export interface Partner {
  id: string;
  name: string;
  logoUrl?: string;
  type: string;
  description?: string;
  website?: string;
  isActive: boolean;
  createdAt: string;
}

export interface Achievement {
  id: string;
  title: string;
  value: string;
  metric: string;
  year?: number;
  isPublic: boolean;
  createdAt: string;
}

// File Management Types
export interface FileItem {
  id: string;
  fileName: string;
  originalName: string;
  fileUrl: string;
  fileType: string;
  fileSize: number;
  mimeType: string;
  entityType: 'property' | 'deal' | 'client' | 'request';
  entityId: string;
  uploadedBy: string;
  uploadedByUser?: User;
  permissions?: FilePermission[];
  createdAt: string;
}

export interface FilePermission {
  id: string;
  fileId: string;
  userId?: string;
  roleId?: string;
  canView: boolean;
  canDownload: boolean;
  createdAt: string;
}

// Notification Types
export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  data?: Record<string, unknown>;
  isRead: boolean;
  createdAt: string;
}

export type NotificationType = 
  | 'deal_created' 
  | 'deal_approved' 
  | 'commission_paid' 
  | 'property_approved' 
  | 'request_assigned'
  | 'new_message'
  | 'system';

// Report Types
export interface DashboardStats {
  totalProperties: number;
  activeProperties: number;
  totalDeals: number;
  pendingDeals: number;
  totalCommission: number;
  pendingCommission: number;
  totalBrokers: number;
  totalClients: number;
  monthlyGrowth: number;
}

export interface BrokerPerformance {
  brokerId: string;
  brokerName: string;
  totalListings: number;
  totalDeals: number;
  totalSales: number;
  totalCommission: number;
  listingCommission: number;
  sellingCommission: number;
  rank: number;
}

export interface RevenueReport {
  month: string;
  totalRevenue: number;
  commissionRevenue: number;
  subscriptionRevenue: number;
  adRevenue: number;
  listingFees: number;
}

// Filter & Pagination Types
export interface PaginationParams {
  page: number;
  limit: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface PropertyFilters {
  cityId?: string;
  districtId?: string;
  typeId?: string;
  minPrice?: number;
  maxPrice?: number;
  minArea?: number;
  maxArea?: number;
  bedrooms?: number;
  status?: PropertyStatus;
  listingType?: 'sale' | 'rent';
  isFeatured?: boolean;
}

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
  errors?: Record<string, string[]>;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

// Map Types
export interface MapBounds {
  north: number;
  south: number;
  east: number;
  west: number;
}

export interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  title: string;
  price: number;
  imageUrl?: string;
  type: string;
}
