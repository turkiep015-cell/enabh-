# البنية التقنية لمنصة إنابة المستقبل العقارية

---

## 🏗️ نظرة عامة على البنية

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              CLIENT LAYER                                            │
├─────────────────────────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐            │
│  │  Web App     │  │  Mobile App  │  │  Admin Panel │  │  Partner API │            │
│  │  (React)     │  │  (React      │  │  (React)     │  │  (REST)      │            │
│  │              │  │   Native)    │  │              │  │              │            │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘            │
└─────────┼─────────────────┼─────────────────┼─────────────────┼────────────────────┘
          │                 │                 │                 │
          └─────────────────┴────────┬────────┴─────────────────┘
                                   │
                              ┌────┴────┐
                              │  CDN    │
                              │ (AWS    │
                              │ CloudFront)
                              └────┬────┘
                                   │
┌──────────────────────────────────┼──────────────────────────────────────────────────┐
│                         API GATEWAY LAYER                                          │
├──────────────────────────────────┼──────────────────────────────────────────────────┤
│                          ┌───────┴───────┐                                         │
│                          │  AWS API      │                                         │
│                          │  Gateway      │                                         │
│                          │  + WAF        │                                         │
│                          └───────┬───────┘                                         │
│                                  │                                                  │
│                    ┌─────────────┼─────────────┐                                   │
│                    │             │             │                                   │
│              ┌─────┴─────┐ ┌─────┴─────┐ ┌─────┴─────┐                            │
│              │   Rate    │ │   Auth    │ │   Cache   │                            │
│              │   Limit   │ │   Verify  │ │   Layer   │                            │
│              └───────────┘ └───────────┘ └───────────┘                            │
└──────────────────────────────────┼──────────────────────────────────────────────────┘
                                   │
┌──────────────────────────────────┼──────────────────────────────────────────────────┐
│                         APPLICATION LAYER (Kubernetes)                             │
├──────────────────────────────────┼──────────────────────────────────────────────────┤
│                                  │                                                  │
│  ┌───────────────────────────────┴───────────────────────────────┐                 │
│  │                    Load Balancer (NGINX)                      │                 │
│  └───────────────────────────────┬───────────────────────────────┘                 │
│                                  │                                                  │
│  ┌───────────────────────────────┼───────────────────────────────┐                 │
│  │                               │                               │                 │
│  ▼                               ▼                               ▼                 │
│ ┌─────────────┐           ┌─────────────┐           ┌─────────────┐                │
│ │  API        │◀─────────▶│  API        │◀─────────▶│  API        │                │
│ │  Server 1   │           │  Server 2   │           │  Server N   │                │
│ │  (Node.js)  │           │  (Node.js)  │           │  (Node.js)  │                │
│ └──────┬──────┘           └──────┬──────┘           └──────┬──────┘                │
│        │                         │                         │                        │
│        └─────────────────────────┼─────────────────────────┘                        │
│                                  │                                                   │
│  ┌───────────────────────────────┴───────────────────────────────┐                  │
│  │              Background Workers (Bull Queue)                  │                  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐      │                  │
│  │  │  Email   │  │  SMS     │  │  Notif   │  │  Report  │      │                  │
│  │  │  Worker  │  │  Worker  │  │  Worker  │  │  Worker  │      │                  │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘      │                  │
│  └──────────────────────────────────────────────────────────────┘                  │
└──────────────────────────────────┼─────────────────────────────────────────────────┘
                                   │
┌──────────────────────────────────┼─────────────────────────────────────────────────┐
│                         DATA LAYER                                                 │
├──────────────────────────────────┼─────────────────────────────────────────────────┤
│                                  │                                                  │
│  ┌───────────────────────────────┴───────────────────────────────┐                 │
│  │              PostgreSQL (Primary + Replicas)                  │                 │
│  │  ┌─────────────┐      ┌─────────────┐      ┌─────────────┐   │                 │
│  │  │   Primary   │◀────▶│  Replica 1  │◀────▶│  Replica 2  │   │                 │
│  │  │   (Write)   │      │   (Read)    │      │   (Read)    │   │                 │
│  │  └─────────────┘      └─────────────┘      └─────────────┘   │                 │
│  └──────────────────────────────────────────────────────────────┘                 │
│                                                                                    │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                    │
│  │     Redis       │  │ Elasticsearch   │  │      MinIO      │                    │
│  │    (Cache +     │  │    (Search +    │  │   (File Storage)│                    │
│  │     Session)    │  │    Analytics)   │  │                 │                    │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘                    │
└────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 🛠️ Stack التقني

### Frontend

| التقنية | الاستخدام |
|---------|----------|
| **React 18** | إطار العمل الرئيسي |
| **TypeScript** | لغة البرمجة |
| **Vite** | أداة البناء |
| **Tailwind CSS** | تصميم الواجهات |
| **shadcn/ui** | مكونات واجهة المستخدم |
| **TanStack Query** | إدارة البيانات والكاش |
| **React Router v6** | التوجيه |
| **React Hook Form** | إدارة النماذج |
| **Zod** | التحقق من البيانات |
| **Recharts** | الرسوم البيانية |
| **React-Leaflet** | الخرائط التفاعلية |
| **i18next** | التعريب |
| **Socket.io-client** | الاتصال الفوري |

### Backend

| التقنية | الاستخدام |
|---------|----------|
| **Node.js 20** | بيئة التشغيل |
| **Express.js** | إطار العمل |
| **TypeScript** | لغة البرمجة |
| **Prisma ORM** | التعامل مع قاعدة البيانات |
| **PostgreSQL 15** | قاعدة البيانات الرئيسية |
| **Redis 7** | الكاش والجلسات |
| **Elasticsearch** | البحث المتقدم |
| **Bull Queue** | قوائم الانتظار |
| **Socket.io** | الاتصال الفوري |
| **JWT** | المصادقة |
| **bcrypt** | تشفير كلمات المرور |
| **Multer** | رفع الملفات |
| **Sharp** | معالجة الصور |

### DevOps & Infrastructure

| التقنية | الاستخدام |
|---------|----------|
| **AWS** | مزود الخدمة السحابية |
| **EKS (Kubernetes)** | إدارة الحاويات |
| **Docker** | حاويات التطبيق |
| **GitHub Actions** | CI/CD |
| **Terraform** | البنية التحتية ككود |
| **Prometheus + Grafana** | المراقبة |
| **ELK Stack** | تجميع السجلات |
| **AWS CloudFront** | CDN |
| **AWS S3** | تخزين الملفات |
| **AWS SES** | البريد الإلكتروني |
| **AWS SNS** | الإشعارات |

---

## 📁 هيكل المشروع

```
inabah-platform/
├── 📁 apps/
│   ├── 📁 web/                          # تطبيق الويب (React)
│   │   ├── 📁 src/
│   │   │   ├── 📁 components/           # المكونات المشتركة
│   │   │   │   ├── 📁 ui/              # مكونات أساسية
│   │   │   │   ├── 📁 forms/           # نماذج الإدخال
│   │   │   │   ├── 📁 layout/          # تخطيط الصفحات
│   │   │   │   └── 📁 charts/          # الرسوم البيانية
│   │   │   ├── 📁 pages/               # الصفحات
│   │   │   │   ├── 📁 auth/            # المصادقة
│   │   │   │   ├── 📁 admin/           # لوحة Super Admin
│   │   │   │   ├── 📁 broker/          # لوحة الوسطاء
│   │   │   │   ├── 📁 client/          # منصة العملاء
│   │   │   │   └── 📁 public/          # الصفحات العامة
│   │   │   ├── 📁 hooks/               # React Hooks
│   │   │   ├── 📁 lib/                 # مكتبات مساعدة
│   │   │   ├── 📁 services/            # خدمات API
│   │   │   ├── 📁 stores/              # إدارة الحالة (Zustand)
│   │   │   ├── 📁 types/               # أنواع TypeScript
│   │   │   ├── 📁 i18n/                # ملفات الترجمة
│   │   │   │   ├── 📁 ar/              # العربية
│   │   │   │   ├── 📁 en/              # الإنجليزية
│   │   │   │   └── 📁 id/              # الإندونيسية
│   │   │   └── 📁 styles/              # ملفات CSS
│   │   ├── 📄 index.html
│   │   ├── 📄 vite.config.ts
│   │   ├── 📄 tsconfig.json
│   │   └── 📄 package.json
│   │
│   ├── 📁 api/                          # خادم API (Node.js)
│   │   ├── 📁 src/
│   │   │   ├── 📁 config/              # الإعدادات
│   │   │   ├── 📁 controllers/         # المتحكمات
│   │   │   ├── 📁 middleware/          # الوسطاء
│   │   │   ├── 📁 models/              # النماذج
│   │   │   ├── 📁 routes/              # المسارات
│   │   │   ├── 📁 services/            # الخدمات
│   │   │   ├── 📁 utils/               # أدوات مساعدة
│   │   │   ├── 📁 jobs/                # المهام المجدولة
│   │   │   ├── 📁 tests/               # الاختبارات
│   │   │   └── 📄 app.ts               # نقطة الدخول
│   │   ├── 📄 Dockerfile
│   │   ├── 📄 docker-compose.yml
│   │   └── 📄 package.json
│   │
│   └── 📁 mobile/                       # تطبيق الموبايل (React Native)
│
├── 📁 packages/
│   ├── 📁 shared-types/                 # الأنواع المشتركة
│   ├── 📁 ui-components/                # مكونات واجهة مشتركة
│   └── 📁 config/                       # إعدادات مشتركة
│
├── 📁 infrastructure/
│   ├── 📁 terraform/                    # بنية تحتية ككود
│   ├── 📁 kubernetes/                   # ملفات K8s
│   └── 📁 docker/                       # Dockerfiles
│
├── 📁 docs/                             # التوثيق
│   ├── 📄 API.md
│   ├── 📄 DEPLOYMENT.md
│   └── 📄 SECURITY.md
│
├── 📄 docker-compose.yml               # تطوير محلي
├── 📄 turbo.json                       # إعدادات Monorepo
└── 📄 package.json                     # جذر المشروع
```

---

## 🔐 نظام المصادقة والأمان

```
┌─────────────────────────────────────────────────────────────────┐
│                    AUTHENTICATION FLOW                          │
└─────────────────────────────────────────────────────────────────┘

┌─────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────┐
│  Client │────▶│   Login     │────▶│   Verify    │────▶│  JWT    │
│         │     │   Request   │     │  Password   │     │ Token   │
└─────────┘     └─────────────┘     └─────────────┘     └────┬────┘
                                                             │
                        ┌────────────────────────────────────┘
                        │
                        ▼
┌─────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────┐
│  Client │◀────│   Access    │◀────│   Verify    │◀────│  Redis  │
│         │     │   Token     │     │    JWT      │     │ Session │
└─────────┘     └─────────────┘     └─────────────┘     └─────────┘

┌─────────────────────────────────────────────────────────────────┐
│                    AUTHORIZATION (RBAC)                         │
└─────────────────────────────────────────────────────────────────┘

                    ┌─────────────┐
                    │    User     │
                    │   Request   │
                    └──────┬──────┘
                           │
                           ▼
                    ┌─────────────┐
                    │   Extract   │
                    │    Role     │
                    └──────┬──────┘
                           │
                           ▼
                    ┌─────────────┐
                    │   Check     │
                    │ Permissions │
                    └──────┬──────┘
                           │
              ┌────────────┴────────────┐
              │                         │
              ▼                         ▼
       ┌─────────────┐           ┌─────────────┐
       │   Allow     │           │    Deny     │
       │   Access    │           │   Access    │
       └─────────────┘           └─────────────┘
```

### هيكل JWT Token

```json
{
  "header": {
    "alg": "RS256",
    "typ": "JWT"
  },
  "payload": {
    "sub": "user-uuid",
    "email": "user@example.com",
    "role": "broker",
    "company_id": "company-uuid",
    "permissions": ["properties:read", "properties:create"],
    "iat": 1700000000,
    "exp": 1700086400
  }
}
```

---

## 📡 API Architecture

### RESTful Endpoints Structure

```
/api/v1/
├── /auth
│   ├── POST /login
│   ├── POST /register
│   ├── POST /logout
│   ├── POST /refresh
│   ├── POST /forgot-password
│   └── POST /reset-password
│
├── /users
│   ├── GET    /              (list - admin)
│   ├── POST   /              (create - admin)
│   ├── GET    /:id           (read)
│   ├── PUT    /:id           (update)
│   ├── DELETE /:id           (delete - admin)
│   └── GET    /me            (current user)
│
├── /properties
│   ├── GET    /              (list)
│   ├── POST   /              (create - broker)
│   ├── GET    /:id           (read)
│   ├── PUT    /:id           (update - owner)
│   ├── DELETE /:id           (delete - owner)
│   ├── POST   /:id/approve   (approve - admin)
│   └── GET    /map           (map search)
│
├── /deals
│   ├── GET    /              (list)
│   ├── POST   /              (create)
│   ├── GET    /:id           (read)
│   ├── PUT    /:id           (update)
│   ├── POST   /:id/approve   (approve - admin)
│   └── GET    /:id/commissions
│
├── /commissions
│   ├── GET    /              (list)
│   ├── GET    /summary       (summary)
│   └── GET    /export        (export - admin)
│
├── /requests
│   ├── GET    /              (list)
│   ├── POST   /              (create - client)
│   ├── GET    /:id           (read)
│   └── PUT    /:id/assign    (assign - admin)
│
├── /reports
│   ├── GET    /dashboard     (dashboard stats)
│   ├── GET    /brokers       (broker reports)
│   ├── GET    /deals         (deal reports)
│   └── GET    /revenue       (revenue reports)
│
└── /admin
    ├── GET    /stats         (system stats)
    ├── GET    /logs          (audit logs)
    └── POST   /settings      (update settings)
```

---

## 🗄️ استراتيجية الكاش

```
┌─────────────────────────────────────────────────────────────────┐
│                     CACHING STRATEGY                            │
└─────────────────────────────────────────────────────────────────┘

Layer 1: Browser Cache
├── Static Assets (1 year)
├── API Responses (ETag)
└── Images (1 month)

Layer 2: CDN Cache (CloudFront)
├── Static Files (24 hours)
├── API Responses (5 minutes)
└── Images (1 hour)

Layer 3: Application Cache (Redis)
├── User Sessions (24 hours)
├── Property Listings (10 minutes)
├── Search Results (5 minutes)
├── Dashboard Stats (1 minute)
└── Commission Calculations (1 hour)

Layer 4: Database Cache
├── Query Results (PostgreSQL)
└── Connection Pooling (PgBouncer)
```

### Cache Keys Structure

```
# المستخدمين
user:session:{user_id}
user:profile:{user_id}

# العقارات
properties:list:{page}:{limit}:{filters_hash}
property:{property_id}
property:featured

# الإحصائيات
dashboard:stats:{date}
reports:brokers:{month}:{year}

# البحث
search:{query_hash}:{page}
```

---

## 📊 المراقبة والتتبع

```
┌─────────────────────────────────────────────────────────────────┐
│                   MONITORING STACK                              │
└─────────────────────────────────────────────────────────────────┘

┌─────────────┐   ┌─────────────┐   ┌─────────────┐   ┌─────────┐
│ Prometheus  │   │   Grafana   │   │    ELK      │   │  Pager  │
│  (Metrics)  │──▶│ (Dashboard) │   │  (Logs)     │   │  Duty   │
└─────────────┘   └─────────────┘   └─────────────┘   └─────────┘

Metrics:
├── Application
│   ├── Request Rate (RPS)
│   ├── Response Time (p50, p95, p99)
│   ├── Error Rate
│   └── Active Connections
│
├── Business
│   ├── Properties Listed
│   ├── Deals Closed
│   ├── Commission Amount
│   └── User Registrations
│
└── Infrastructure
    ├── CPU Usage
    ├── Memory Usage
    ├── Disk I/O
    └── Network Traffic
```

---

## 🚀 CI/CD Pipeline

```
┌─────────────────────────────────────────────────────────────────┐
│                    DEPLOYMENT PIPELINE                          │
└─────────────────────────────────────────────────────────────────┘

Developer Push
      │
      ▼
┌─────────────┐
│   GitHub    │
│   Actions   │
└──────┬──────┘
       │
       ├──▶ Lint & Test
       │
       ├──▶ Build Docker Image
       │
       ├──▶ Security Scan (Trivy)
       │
       ├──▶ Push to ECR
       │
       └──▶ Deploy to EKS
                │
                ├──▶ Staging (Auto)
                │
                └──▶ Production (Manual Approval)
```

---

## 💰 تقديرات التكلفة الشهرية (AWS)

| الخدمة | المواصفات | التكلفة الشهرية |
|--------|-----------|----------------|
| **EKS** | 3 Nodes (t3.large) | $300 |
| **RDS PostgreSQL** | db.r5.large + Multi-AZ | $400 |
| **ElastiCache Redis** | cache.r5.large | $150 |
| **Elasticsearch** | 2x t3.medium | $200 |
| **S3** | 500GB + Transfer | $50 |
| **CloudFront** | 1TB Transfer | $100 |
| **ALB** | 2 Load Balancers | $40 |
| **CloudWatch** | Logs + Metrics | $100 |
| **SES** | 100k Emails | $50 |
| **WAF** | + Shield Advanced | $300 |
| **الإجمالي** | | **~$1,690/شهر** |

---

*تم إعداد هذا المخطط بتاريخ: 2026-03-01*
