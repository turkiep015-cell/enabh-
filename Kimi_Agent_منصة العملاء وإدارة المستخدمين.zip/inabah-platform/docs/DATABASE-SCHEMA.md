# تصميم قاعدة بيانات منصة إنابة المستقبل العقارية

---

## 🗄️ نظرة عامة

| البند | التفاصيل |
|-------|----------|
| **نوع قاعدة البيانات** | PostgreSQL (Primary) + Redis (Cache) |
| **ORM** | Prisma |
| **التخزين** | AWS S3 (للملفات) |
| **البحث** | Elasticsearch (للبحث المتقدم) |

---

## 📊 مخطط قاعدة البيانات (ERD)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           CORE ENTITIES                                      │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│    users     │────▶│    roles     │     │  companies   │◀────│  user_company│
├──────────────┤     ├──────────────┤     ├──────────────┤     ├──────────────┤
│ id (PK)      │     │ id (PK)      │     │ id (PK)      │     │ id (PK)      │
│ email        │     │ name         │     │ name         │     │ user_id (FK) │
│ password     │     │ permissions  │     │ type         │     │ company_id   │
│ phone        │     │ created_at   │     │ license_no   │     │ role         │
│ full_name    │     └──────────────┘     │ cr_number    │     │ created_at   │
│ role_id (FK) │                          │ status       │     └──────────────┘
│ avatar       │                          │ created_at   │
│ is_active    │                          └──────────────┘
│ last_login   │
│ created_at   │
└──────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                        PROPERTIES MODULE                                     │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│  properties  │────▶│ prop_types   │     │   cities     │◀────│  districts   │
├──────────────┤     ├──────────────┤     ├──────────────┤     ├──────────────┤
│ id (PK)      │     │ id (PK)      │     │ id (PK)      │     │ id (PK)      │
│ title_ar     │     │ name_ar      │     │ name_ar      │     │ name_ar      │
│ title_en     │     │ name_en      │     │ name_en      │     │ name_en      │
│ description  │     │ icon         │     │ region_id    │     │ city_id (FK) │
│ type_id (FK) │     │ is_active    │     │ is_active    │     │ is_active    │
│ city_id (FK) │     └──────────────┘     └──────────────┘     └──────────────┘
│ district_id  │
│ price        │     ┌──────────────┐     ┌──────────────┐
│ area         │────▶│prop_features │     │prop_images   │
│ bedrooms     │     ├──────────────┤     ├──────────────┤
│ bathrooms    │     │ id (PK)      │     │ id (PK)      │
│ lat          │     │ property_id  │     │ property_id  │
│ lng          │     │ feature_name │     │ image_url    │
│ status       │     │ feature_value│     │ is_main      │
│ listed_by    │     │ created_at   │     │ sort_order   │
│ is_featured  │     └──────────────┘     └──────────────┘
│ is_approved  │
│ created_at   │
└──────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                      COMMISSIONS MODULE                                      │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   deals      │────▶│deal_commission│    │commission_rules│
├──────────────┤     ├──────────────┤     ├──────────────┤
│ id (PK)      │     │ id (PK)      │     │ id (PK)      │
│ property_id  │     │ deal_id (FK) │     │ name         │
│ buyer_id     │     │ user_id (FK) │     │ base_rate    │
│ seller_id    │     │ role_type    │     │ listing_pct  │
│ listing_agent│     │ amount       │     │ selling_pct  │
│ selling_agent│     │ percentage   │     │ project_id   │
│ sale_price   │     │ status       │     │ prop_type_id │
│ status       │     │ paid_at      │     │ is_active    │
│ approved_by  │     │ created_at   │     │ created_at   │
│ approved_at  │     └──────────────┘     └──────────────┘
│ created_at   │
└──────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                       CLIENT REQUESTS MODULE                                 │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   requests   │────▶│req_documents │     │request_matches│
├──────────────┤     ├──────────────┤     ├──────────────┤
│ id (PK)      │     │ id (PK)      │     │ id (PK)      │
│ client_id    │     │ request_id   │     │ request_id   │
│ type         │     │ doc_type     │     │ property_id  │
│ budget_min   │     │ file_url     │     │ match_score  │
│ budget_max   │     │ status       │     │ status       │
│ city_id      │     │ uploaded_at  │     │ created_at   │
│ district_ids │     └──────────────┘     └──────────────┘
│ prop_type_ids│
│ status       │
│ notes        │
│ created_at   │
└──────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                      ADVERTISING MODULE                                      │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│    ads       │     │ ad_positions │     │ ad_analytics │
├──────────────┤     ├──────────────┤     ├──────────────┤
│ id (PK)      │     │ id (PK)      │     │ id (PK)      │
│ title        │     │ name         │     │ ad_id (FK)   │
│ image_url    │     │ location     │     │ impressions  │
│ link_url     │     │ size_width   │     │ clicks       │
│ position_id  │     │ size_height  │     │ date         │
│ target_type  │     │ price_daily  │     └──────────────┘
│ start_date   │     │ is_active    │
│ end_date     │     └──────────────┘
│ status       │
│ created_by   │
│ created_at   │
└──────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                    CORPORATE PROFILE MODULE                                  │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│ certificates │     │   licenses   │     │  partners    │     │achievements  │
├──────────────┤     ├──────────────┤     ├──────────────┤     ├──────────────┤
│ id (PK)      │     │ id (PK)      │     │ id (PK)      │     │ id (PK)      │
│ name         │     │ license_no   │     │ name         │     │ title        │
│ issuer       │     │ issuer       │     │ logo_url     │     │ value        │
│ image_url    │     │ issue_date   │     │ type         │     │ metric       │
│ pdf_url      │     │ expiry_date  │     │ description  │     │ year         │
│ issue_date   │     │ status       │     │ website      │     │ is_public    │
│ expiry_date  │     │ alert_days   │     │ is_active    │     │ created_at   │
│ is_public    │     │ is_public    │     │ created_at   │     └──────────────┘
│ created_at   │     │ created_at   │     └──────────────┘
└──────────────┘     └──────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                       FILE MANAGEMENT MODULE                                 │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────┐     ┌──────────────┐
│    files     │     │ file_permissions│
├──────────────┤     ├──────────────┤
│ id (PK)      │     │ id (PK)      │
│ file_name    │     │ file_id (FK) │
│ original_name│     │ user_id (FK) │
│ file_url     │     │ role_id (FK) │
│ file_type    │     │ can_view     │
│ file_size    │     │ can_download │
│ mime_type    │     │ created_at   │
│ entity_type  │     └──────────────┘
│ entity_id    │
│ uploaded_by  │
│ created_at   │
└──────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                      NOTIFICATIONS MODULE                                    │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────┐     ┌──────────────┐
│notifications │     │notification_prefs│
├──────────────┤     ├──────────────┤
│ id (PK)      │     │ id (PK)      │
│ user_id (FK) │     │ user_id (FK) │
│ type         │     │ email_notif  │
│ title        │     │ push_notif   │
│ message      │     │ sms_notif    │
│ data         │     │ created_at   │
│ is_read      │     └──────────────┘
│ created_at   │
└──────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                       AUDIT LOG MODULE                                       │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────┐
│  audit_logs  │
├──────────────┤
│ id (PK)      │
│ user_id (FK) │
│ action       │
│ entity_type  │
│ entity_id    │
│ old_values   │
│ new_values   │
│ ip_address   │
│ user_agent   │
│ created_at   │
└──────────────┘
```

---

## 📝 تفاصيل الجداول

### 1. users - المستخدمون

```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20) UNIQUE,
    full_name VARCHAR(255) NOT NULL,
    full_name_en VARCHAR(255),
    avatar_url VARCHAR(500),
    role_id UUID REFERENCES roles(id),
    company_id UUID REFERENCES companies(id),
    is_active BOOLEAN DEFAULT true,
    email_verified BOOLEAN DEFAULT false,
    phone_verified BOOLEAN DEFAULT false,
    last_login_at TIMESTAMP,
    preferred_language VARCHAR(10) DEFAULT 'ar',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**الفهارس:**
```sql
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_users_role ON users(role_id);
CREATE INDEX idx_users_company ON users(company_id);
CREATE INDEX idx_users_active ON users(is_active);
```

---

### 2. roles - الأدوار والصلاحيات

```sql
CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) UNIQUE NOT NULL, -- super_admin, admin, broker, client
    name_ar VARCHAR(100),
    name_en VARCHAR(100),
    permissions JSONB NOT NULL DEFAULT '{}',
    description TEXT,
    is_system BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**الصلاحيات المبدئية:**
```json
{
  "super_admin": {
    "users": ["create", "read", "update", "delete"],
    "companies": ["create", "read", "update", "delete"],
    "properties": ["create", "read", "update", "delete", "approve"],
    "deals": ["create", "read", "update", "delete", "approve"],
    "commissions": ["read", "update", "pay"],
    "reports": ["read", "export"],
    "settings": ["read", "update"]
  },
  "broker": {
    "properties": ["create", "read", "update", "delete_own"],
    "deals": ["create", "read", "update_own"],
    "commissions": ["read_own"]
  },
  "client": {
    "properties": ["read"],
    "requests": ["create", "read", "update_own"]
  }
}
```

---

### 3. companies - الشركات

```sql
CREATE TABLE companies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    name_en VARCHAR(255),
    type VARCHAR(50) NOT NULL, -- developer, brokerage, owner
    cr_number VARCHAR(50),
    license_number VARCHAR(50),
    tax_number VARCHAR(50),
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(255),
    logo_url VARCHAR(500),
    website VARCHAR(255),
    status VARCHAR(50) DEFAULT 'pending', -- pending, active, suspended
    verified_at TIMESTAMP,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

### 4. properties - العقارات

```sql
CREATE TABLE properties (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title_ar VARCHAR(500) NOT NULL,
    title_en VARCHAR(500),
    description_ar TEXT,
    description_en TEXT,
    type_id UUID REFERENCES property_types(id),
    
    -- الموقع
    city_id UUID REFERENCES cities(id),
    district_id UUID REFERENCES districts(id),
    address TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    
    -- التفاصيل
    price DECIMAL(15, 2) NOT NULL,
    area DECIMAL(10, 2),
    bedrooms INTEGER,
    bathrooms INTEGER,
    floor_number INTEGER,
    total_floors INTEGER,
    year_built INTEGER,
    furnishing_status VARCHAR(50), -- furnished, semi_furnished, unfurnished
    
    -- الحالة
    status VARCHAR(50) DEFAULT 'active', -- active, reserved, sold, inactive
    listing_type VARCHAR(50), -- sale, rent
    
    -- العلاقات
    listed_by UUID REFERENCES users(id),
    company_id UUID REFERENCES companies(id),
    
    -- الموافقة
    is_approved BOOLEAN DEFAULT false,
    approved_by UUID REFERENCES users(id),
    approved_at TIMESTAMP,
    
    -- التمييز
    is_featured BOOLEAN DEFAULT false,
    featured_until TIMESTAMP,
    
    -- العدادات
    view_count INTEGER DEFAULT 0,
    inquiry_count INTEGER DEFAULT 0,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**الفهارس:**
```sql
CREATE INDEX idx_properties_type ON properties(type_id);
CREATE INDEX idx_properties_city ON properties(city_id);
CREATE INDEX idx_properties_status ON properties(status);
CREATE INDEX idx_properties_price ON properties(price);
CREATE INDEX idx_properties_location ON properties(latitude, longitude);
CREATE INDEX idx_properties_listed_by ON properties(listed_by);
CREATE INDEX idx_properties_featured ON properties(is_featured) WHERE is_featured = true;
```

---

### 5. deals - الصفقات

```sql
CREATE TABLE deals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deal_number VARCHAR(50) UNIQUE NOT NULL,
    property_id UUID REFERENCES properties(id),
    
    -- الأطراف
    buyer_id UUID REFERENCES users(id),
    seller_id UUID REFERENCES users(id),
    listing_agent_id UUID REFERENCES users(id),
    selling_agent_id UUID REFERENCES users(id),
    
    -- التفاصيل المالية
    sale_price DECIMAL(15, 2) NOT NULL,
    commission_rate DECIMAL(5, 2) DEFAULT 2.5,
    total_commission DECIMAL(15, 2),
    
    -- الحالة
    status VARCHAR(50) DEFAULT 'pending', -- pending, approved, completed, cancelled
    
    -- الموافقة
    approved_by UUID REFERENCES users(id),
    approved_at TIMESTAMP,
    
    -- التواريخ
    expected_close_date DATE,
    actual_close_date DATE,
    
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

### 6. deal_commissions - عمولات الصفقات

```sql
CREATE TABLE deal_commissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deal_id UUID REFERENCES deals(id),
    user_id UUID REFERENCES users(id),
    role_type VARCHAR(50) NOT NULL, -- listing_agent, selling_agent
    
    -- المبلغ
    percentage DECIMAL(5, 2) NOT NULL, -- نسبة من العمولة الكلية
    amount DECIMAL(15, 2) NOT NULL,
    
    -- الحالة
    status VARCHAR(50) DEFAULT 'pending', -- pending, approved, paid
    
    -- الدفع
    paid_at TIMESTAMP,
    paid_by UUID REFERENCES users(id),
    payment_reference VARCHAR(255),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

### 7. commission_rules - قواعد العمولات

```sql
CREATE TABLE commission_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- النسب الأساسية
    base_rate DECIMAL(5, 2) DEFAULT 2.5,
    listing_percentage DECIMAL(5, 2) DEFAULT 50.0,
    selling_percentage DECIMAL(5, 2) DEFAULT 50.0,
    
    -- التطبيق
    applies_to VARCHAR(50), -- all, project, property_type, user
    project_id UUID REFERENCES projects(id),
    property_type_id UUID REFERENCES property_types(id),
    user_id UUID REFERENCES users(id),
    
    -- الفعالية
    is_active BOOLEAN DEFAULT true,
    valid_from DATE,
    valid_until DATE,
    
    priority INTEGER DEFAULT 0,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

### 8. client_requests - طلبات العملاء

```sql
CREATE TABLE client_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    request_number VARCHAR(50) UNIQUE NOT NULL,
    client_id UUID REFERENCES users(id),
    
    -- التفاصيل
    request_type VARCHAR(50), -- buy, rent, invest
    budget_min DECIMAL(15, 2),
    budget_max DECIMAL(15, 2),
    
    -- الموقع
    city_id UUID REFERENCES cities(id),
    district_ids UUID[],
    
    -- نوع العقار
    property_type_ids UUID[],
    
    -- المتطلبات
    min_area DECIMAL(10, 2),
    max_area DECIMAL(10, 2),
    bedrooms_min INTEGER,
    bedrooms_max INTEGER,
    
    -- الحالة
    status VARCHAR(50) DEFAULT 'open', -- open, in_progress, closed, cancelled
    
    -- التقييم
    satisfaction_rating INTEGER,
    feedback TEXT,
    
    assigned_to UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

### 9. advertisements - الإعلانات

```sql
CREATE TABLE advertisements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(255) NOT NULL,
    subtitle VARCHAR(255),
    
    -- المحتوى
    image_url VARCHAR(500) NOT NULL,
    image_mobile_url VARCHAR(500),
    link_url VARCHAR(500),
    
    -- الموقع
    position_id UUID REFERENCES ad_positions(id),
    
    -- الاستهداف
    target_audience VARCHAR(50), -- all, brokers, clients
    target_pages VARCHAR(50)[], -- الصفحات المستهدفة
    
    -- التواريخ
    start_date TIMESTAMP NOT NULL,
    end_date TIMESTAMP NOT NULL,
    
    -- الأولوية
    priority INTEGER DEFAULT 0,
    
    -- الحالة
    status VARCHAR(50) DEFAULT 'pending', -- pending, active, paused, expired
    
    -- الإحصائيات
    impressions INTEGER DEFAULT 0,
    clicks INTEGER DEFAULT 0,
    
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

### 10. audit_logs - سجل المراجعة

```sql
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL, -- create, update, delete, login, logout
    entity_type VARCHAR(100) NOT NULL,
    entity_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**الفهارس:**
```sql
CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_action ON audit_logs(action);
CREATE INDEX idx_audit_created ON audit_logs(created_at);
```

---

## 🔗 العلاقات بين الجداول

```
users ||--o{ companies : "يعمل في"
users ||--o{ properties : "يدرج"
users ||--o{ deals : "يشارك في"
users ||--|| roles : "يملك دور"

companies ||--o{ properties : "تمتلك"
companies ||--o{ certificates : "تمتلك"
companies ||--o{ licenses : "تمتلك"
companies ||--o{ partners : "تتعاون مع"
companies ||--o{ achievements : "تحقق"

properties ||--o{ property_images : "تحتوي"
properties ||--o{ property_features : "تحتوي"
properties ||--|| property_types : "من نوع"
properties ||--|| cities : "تقع في"
properties ||--o{ deals : "تباع في"

cities ||--o{ districts : "تحتوي"

deals ||--o{ deal_commissions : "تولد"
deals ||--|| users : "المشتري"
deals ||--|| users : "البائع"
deals ||--|| users : "وسيط الإدراج"
deals ||--|| users : "وسيط البيع"

users ||--o{ client_requests : "يطلب"
client_requests ||--o{ request_matches : "تطابق"
request_matches ||--|| properties : "مع عقار"
```

---

## 📈 استراتيجية التوسع

### Partitioning (التقسيم)

```sql
-- تقسيم جدول audit_logs حسب التاريخ
CREATE TABLE audit_logs_2026 PARTITION OF audit_logs
    FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');

-- تقسيم جدول deals حسب الحالة
CREATE TABLE deals_active PARTITION OF deals
    FOR VALUES IN ('pending', 'approved');
```

### Read Replicas (نُسخ القراءة)

| الجدول | الاستخدام |
|--------|----------|
| properties | 1 Primary + 2 Replicas |
| users | 1 Primary + 1 Replica |
| deals | 1 Primary + 1 Replica |

---

## 🔒 الأمان

### Row Level Security (RLS)

```sql
-- تفعيل RLS على جدول properties
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;

-- سياسة: المستخدم يرى العقارات المعتمدة فقط
CREATE POLICY properties_select_policy ON properties
    FOR SELECT
    USING (is_approved = true OR listed_by = current_user_id());

-- سياسة: المستخدم يعدل عقاراته فقط
CREATE POLICY properties_update_policy ON properties
    FOR UPDATE
    USING (listed_by = current_user_id());
```

---

*تم إعداد هذا المخطط بتاريخ: 2026-03-01*
