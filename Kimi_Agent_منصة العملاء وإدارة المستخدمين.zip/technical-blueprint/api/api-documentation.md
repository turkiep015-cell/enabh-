# API Documentation
## منصة إنابة المستقبل العقارية

## Base URL
```
Production: https://api.inabah.sa/v1
Staging: https://api-staging.inabah.sa/v1
```

## Authentication

جميع الطلبات تتطلب توكن المصادقة في الهيدر:
```
Authorization: Bearer {access_token}
```

## Response Format

```json
{
  "success": true,
  "data": {},
  "message": "Operation successful",
  "meta": {
    "page": 1,
    "limit": 20,
    "total": 100
  }
}
```

---

## 1. Authentication APIs

### تسجيل الدخول
```http
POST /auth/login
```

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "deviceId": "optional-device-id"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiIs...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIs...",
    "expiresIn": 3600,
    "user": {
      "id": "uuid",
      "email": "user@example.com",
      "fullName": "محمد أحمد",
      "role": "broker",
      "permissions": ["properties.read", "deals.read"]
    }
  }
}
```

### تسجيل مستخدم جديد
```http
POST /auth/register
```

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "fullNameAr": "محمد أحمد",
  "fullNameEn": "Mohammed Ahmed",
  "phone": "+966501234567",
  "role": "client"
}
```

---

## 2. Properties APIs

### قائمة العقارات
```http
GET /properties
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| page | integer | رقم الصفحة |
| limit | integer | عدد النتائج |
| city | string | المدينة |
| district | string | الحي |
| minPrice | number | الحد الأدنى للسعر |
| maxPrice | number | الحد الأقصى للسعر |
| propertyType | string | نوع العقار |
| listingType | string | sale/rent |
| status | string | available/reserved/sold |

**Response:**
```json
{
  "success": true,
  "data": {
    "properties": [
      {
        "id": "uuid",
        "titleAr": "فيلا فاخرة في الرياض",
        "titleEn": "Luxury Villa in Riyadh",
        "price": 2500000,
        "currency": "SAR",
        "area": 450,
        "bedrooms": 5,
        "bathrooms": 6,
        "city": "الرياض",
        "district": "النرجس",
        "propertyType": "villa",
        "listingType": "sale",
        "status": "available",
        "mainImage": "https://cdn.inabah.sa/property-1.jpg",
        "location": {
          "latitude": 24.7136,
          "longitude": 46.6753
        },
        "owner": {
          "id": "uuid",
          "fullName": "شركة الرياض العقارية",
          "type": "developer"
        },
        "isFeatured": true,
        "viewCount": 1250,
        "createdAt": "2024-01-15T10:30:00Z"
      }
    ]
  },
  "meta": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "totalPages": 8
  }
}
```

### تفاصيل العقار
```http
GET /properties/:id
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "titleAr": "فيلا فاخرة في الرياض",
    "titleEn": "Luxury Villa in Riyadh",
    "descriptionAr": "وصف تفصيلي للعقار...",
    "descriptionEn": "Detailed description...",
    "price": 2500000,
    "area": 450,
    "bedrooms": 5,
    "bathrooms": 6,
    "floorNumber": 0,
    "totalFloors": 2,
    "yearBuilt": 2023,
    "images": [
      {
        "id": "uuid",
        "url": "https://cdn.inabah.sa/property-1.jpg",
        "isMain": true
      }
    ],
    "amenities": ["مسبح", "نادي رياضي", "موقف سيارات"],
    "features": ["غرفة سائق", "غرفة خادمة"],
    "nearbyPlaces": ["مسجد", "مدرسة", "مستشفى"],
    "location": {
      "latitude": 24.7136,
      "longitude": 46.6753
    },
    "owner": {
      "id": "uuid",
      "fullName": "شركة الرياض العقارية",
      "phone": "+966501234567",
      "email": "info@riyadhdev.sa",
      "company": {
        "id": "uuid",
        "name": "شركة الرياض العقارية",
        "licenseNumber": "12345"
      }
    },
    "project": {
      "id": "uuid",
      "name": "مشروع الواحة",
      "completionDate": "2024-12-01"
    },
    "isFavorite": false,
    "similarProperties": []
  }
}
```

### إنشاء عقار جديد
```http
POST /properties
```

**Request Body:**
```json
{
  "titleAr": "فيلا فاخرة",
  "titleEn": "Luxury Villa",
  "descriptionAr": "وصف العقار",
  "propertyType": "villa",
  "listingType": "sale",
  "price": 2500000,
  "area": 450,
  "bedrooms": 5,
  "bathrooms": 6,
  "city": "الرياض",
  "district": "النرجس",
  "address": "شارع الملك فهد",
  "location": {
    "latitude": 24.7136,
    "longitude": 46.6753
  },
  "amenities": ["مسبح", "نادي رياضي"],
  "images": ["image-url-1", "image-url-2"]
}
```

### البحث على الخريطة
```http
GET /properties/map
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| latitude | number | خط العرض |
| longitude | number | خط الطول |
| radius | number | نصف القطر بالمتر |
| minPrice | number | الحد الأدنى للسعر |
| maxPrice | number | الحد الأقصى للسعر |
| propertyType | string | نوع العقار |

**Response:**
```json
{
  "success": true,
  "data": {
    "type": "FeatureCollection",
    "features": [
      {
        "type": "Feature",
        "geometry": {
          "type": "Point",
          "coordinates": [46.6753, 24.7136]
        },
        "properties": {
          "id": "uuid",
          "title": "فيلا فاخرة",
          "price": 2500000,
          "type": "villa",
          "image": "https://cdn.inabah.sa/property-1.jpg"
        }
      }
    ]
  }
}
```

---

## 3. Deals APIs

### قائمة الصفقات
```http
GET /deals
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| status | string | pending/approved/paid/cancelled |
| startDate | date | تاريخ البداية |
| endDate | date | تاريخ النهاية |

**Response:**
```json
{
  "success": true,
  "data": {
    "deals": [
      {
        "id": "uuid",
        "dealNumber": "DEAL-2403-00001",
        "property": {
          "id": "uuid",
          "title": "فيلا فاخرة",
          "price": 2500000
        },
        "salePrice": 2400000,
        "totalCommission": 60000,
        "commissionRate": 2.5,
        "listingAgent": {
          "id": "uuid",
          "fullName": "أحمد محمد",
          "commission": 12000
        },
        "sellingAgent": {
          "id": "uuid",
          "fullName": "خالد عبدالله",
          "commission": 12000
        },
        "status": "approved",
        "dealDate": "2024-03-15",
        "createdAt": "2024-03-15T10:30:00Z"
      }
    ]
  }
}
```

### إنشاء صفقة جديدة
```http
POST /deals
```

**Request Body:**
```json
{
  "propertyId": "uuid",
  "listingAgentId": "uuid",
  "sellingAgentId": "uuid",
  "buyerId": "uuid",
  "salePrice": 2400000,
  "dealDate": "2024-03-15",
  "notes": "ملاحظات على الصفقة"
}
```

### الموافقة على صفقة
```http
PATCH /deals/:id/approve
```

**Request Body:**
```json
{
  "notes": "تمت الموافقة بعد التحقق"
}
```

### حساب العمولة
```http
POST /deals/calculate
```

**Request Body:**
```json
{
  "salePrice": 2500000,
  "commissionRuleId": "uuid"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "totalCommission": 62500,
    "listingAgentCommission": 12500,
    "sellingAgentCommission": 12500,
    "platformCommission": 37500,
    "vatAmount": 9375,
    "totalWithVat": 71875,
    "breakdown": {
      "baseRate": 2.5,
      "listingAgentShare": 20,
      "sellingAgentShare": 20,
      "vatRate": 15
    }
  }
}
```

---

## 4. Wallet APIs

### رصيد المحفظة
```http
GET /wallet/balance
```

**Response:**
```json
{
  "success": true,
  "data": {
    "availableBalance": 150000,
    "pendingBalance": 25000,
    "totalEarned": 500000,
    "totalWithdrawn": 350000,
    "currency": "SAR"
  }
}
```

### سجل المعاملات
```http
GET /wallet/transactions
```

**Response:**
```json
{
  "success": true,
  "data": {
    "transactions": [
      {
        "id": "uuid",
        "type": "commission",
        "amount": 12500,
        "currency": "SAR",
        "status": "completed",
        "description": "عمولة من صفقة DEAL-2403-00001",
        "deal": {
          "id": "uuid",
          "dealNumber": "DEAL-2403-00001"
        },
        "createdAt": "2024-03-15T10:30:00Z"
      }
    ]
  }
}
```

---

## 5. CRM APIs

### قائمة Leads
```http
GET /crm/leads
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| status | string | new/contacted/qualified/converted |
| assignedTo | uuid | معرف المستخدم |
| priority | string | low/medium/high/urgent |

**Response:**
```json
{
  "success": true,
  "data": {
    "leads": [
      {
        "id": "uuid",
        "leadNumber": "LEAD-2403-00001",
        "fullName": "فهد عبدالله",
        "phone": "+966501234567",
        "email": "fahd@example.com",
        "source": "website",
        "interestType": "buy",
        "budgetMin": 1500000,
        "budgetMax": 2500000,
        "preferredCity": "الرياض",
        "status": "contacted",
        "priority": "high",
        "assignedTo": {
          "id": "uuid",
          "fullName": "أحمد محمد"
        },
        "nextFollowUpDate": "2024-03-20T10:00:00Z",
        "createdAt": "2024-03-15T10:30:00Z"
      }
    ]
  }
}
```

### إنشاء Lead
```http
POST /crm/leads
```

**Request Body:**
```json
{
  "fullName": "فهد عبدالله",
  "phone": "+966501234567",
  "email": "fahd@example.com",
  "source": "website",
  "interestType": "buy",
  "budgetMin": 1500000,
  "budgetMax": 2500000,
  "preferredCity": "الرياض",
  "notes": "يبحث عن فيلا في الرياض"
}
```

### تخصيص Lead لوسيط
```http
POST /crm/leads/:id/assign
```

**Request Body:**
```json
{
  "userId": "uuid",
  "notes": "تم التخصيص للمتابعة"
}
```

### سجل التواصل
```http
GET /crm/leads/:id/activities
```

**Response:**
```json
{
  "success": true,
    "data": {
    "activities": [
      {
        "id": "uuid",
        "activityType": "call",
        "direction": "outbound",
        "subject": "مكالمة أولى",
        "description": "تم الاتصال بالعميل ومناقشة احتياجاته",
        "performedBy": {
          "id": "uuid",
          "fullName": "أحمد محمد"
        },
        "activityDate": "2024-03-15T11:00:00Z"
      },
      {
        "id": "uuid",
        "activityType": "email",
        "direction": "outbound",
        "subject": "إرسال عروض",
        "description": "تم إرسال قائمة بالعقارات المتاحة",
        "performedBy": {
          "id": "uuid",
          "fullName": "أحمد محمد"
        },
        "activityDate": "2024-03-15T14:00:00Z"
      }
    ]
  }
}
```

---

## 6. Admin APIs

### إحصائيات المنصة
```http
GET /admin/dashboard/stats
```

**Response:**
```json
{
  "success": true,
  "data": {
    "users": {
      "total": 1500,
      "brokers": 150,
      "developers": 25,
      "clients": 1200,
      "newToday": 15
    },
    "properties": {
      "total": 3500,
      "available": 2800,
      "sold": 500,
      "featured": 50
    },
    "deals": {
      "total": 850,
      "thisMonth": 45,
      "totalValue": 850000000,
      "totalCommission": 21250000
    },
    "revenue": {
      "thisMonth": 1500000,
      "lastMonth": 1200000,
      "growth": 25
    }
  }
}
```

### إعدادات المنصة
```http
GET /admin/settings
```

```http
PATCH /admin/settings
```

**Request Body:**
```json
{
  "platformName": "إنابة المستقبل",
  "primaryColor": "#047857",
  "commissionRate": 2.5,
  "vatRate": 15
}
```

---

## 7. Notifications APIs

### قائمة الإشعارات
```http
GET /notifications
```

**Response:**
```json
{
  "success": true,
  "data": {
    "notifications": [
      {
        "id": "uuid",
        "type": "commission",
        "title": "تم إضافة عمولة جديدة",
        "body": "تم إضافة عمولة بقيمة 12,500 ريال",
        "isRead": false,
        "entityType": "deal",
        "entityId": "uuid",
        "createdAt": "2024-03-15T10:30:00Z"
      }
    ],
    "unreadCount": 5
  }
}
```

### تحديد الإشعار كمقروء
```http
PATCH /notifications/:id/read
```

---

## Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": {
      "email": ["Email is required"],
      "password": ["Password must be at least 8 characters"]
    }
  }
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "error": {
    "code": "UNAUTHORIZED",
    "message": "Invalid or expired token"
  }
}
```

### 403 Forbidden
```json
{
  "success": false,
  "error": {
    "code": "FORBIDDEN",
    "message": "You don't have permission to access this resource"
  }
}
```

### 404 Not Found
```json
{
  "success": false,
  "error": {
    "code": "NOT_FOUND",
    "message": "Resource not found"
  }
}
```

---

## Rate Limiting

| Endpoint | Limit |
|----------|-------|
| Auth | 5 requests/minute |
| Properties | 100 requests/minute |
| Deals | 50 requests/minute |
| Map Search | 30 requests/minute |

---

## Webhooks

### Events
- `deal.created` - عند إنشاء صفقة جديدة
- `deal.approved` - عند موافقة الصفقة
- `commission.paid` - عند دفع العمولة
- `property.sold` - عند بيع عقار
- `lead.assigned` - عند تخصيص Lead

### Payload Example
```json
{
  "event": "deal.approved",
  "timestamp": "2024-03-15T10:30:00Z",
  "data": {
    "dealId": "uuid",
    "dealNumber": "DEAL-2403-00001",
    "salePrice": 2400000,
    "totalCommission": 60000
  }
}
```
