/**
 * ============================================================
 * Commission Service - NestJS
 * Inabah Real Estate Platform
 * ============================================================
 * 
 * هذا الملف يحتوي على المنطق المالي لنظام توزيع العمولات
 * وفق الخوارزمية المحددة:
 * - العمولة = 2.5% من قيمة الصفقة
 * - 20% من العمولة لوسيط الإدراج
 * - 20% من العمولة لوسيط البيع
 * - 40% إذا كان الوسيط واحد (مدرج وبائع)
 * - الأتمتة عند تغيير حالة الوحدة إلى "مباع"
 */

import { Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { Deal, DealStatus } from './entities/deal.entity';
import { CommissionRule } from './entities/commission-rule.entity';
import { WalletTransaction, TransactionType, TransactionStatus } from '../wallet/entities/wallet-transaction.entity';
import { UserWallet } from '../wallet/entities/user-wallet.entity';
import { Property, PropertyStatus } from '../property/entities/property.entity';
import { CreateDealDto } from './dto/create-deal.dto';
import { UpdateDealStatusDto } from './dto/update-deal-status.dto';
import { CommissionBreakdownDto } from './dto/commission-breakdown.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';

/**
 * واجهة نتيجة حساب العمولة
 */
interface CommissionCalculationResult {
  totalCommission: number;
  listingAgentCommission: number;
  sellingAgentCommission: number;
  platformCommission: number;
  vatAmount: number;
  totalWithVat: number;
  breakdown: CommissionBreakdownDto;
}

/**
 * واجهة توزيع العمولة
 */
interface CommissionDistribution {
  listingAgentId: string | null;
  listingAgentAmount: number;
  sellingAgentId: string | null;
  sellingAgentAmount: number;
  platformAmount: number;
  isSingleAgent: boolean;
}

@Injectable()
export class CommissionService {
  private readonly logger = new Logger(CommissionService.name);

  constructor(
    @InjectRepository(Deal)
    private readonly dealRepository: Repository<Deal>,
    
    @InjectRepository(CommissionRule)
    private readonly commissionRuleRepository: Repository<CommissionRule>,
    
    @InjectRepository(WalletTransaction)
    private readonly walletTransactionRepository: Repository<WalletTransaction>,
    
    @InjectRepository(UserWallet)
    private readonly userWalletRepository: Repository<UserWallet>,
    
    @InjectRepository(Property)
    private readonly propertyRepository: Repository<Property>,
    
    private readonly dataSource: DataSource,
    private readonly eventEmitter: EventEmitter2,
  ) {}

  // ============================================================
  // 1. حساب العمولة الأساسي
  // ============================================================

  /**
   * حساب العمولة بناءً على قيمة الصفقة وقاعدة العمولة
   * 
   * @param salePrice - سعر البيع
   * @param ruleId - معرف قاعدة العمولة (اختياري)
   * @returns CommissionCalculationResult
   */
  async calculateCommission(
    salePrice: number,
    ruleId?: string,
  ): Promise<CommissionCalculationResult> {
    // جلب قاعدة العمولة
    let rule: CommissionRule;
    
    if (ruleId) {
      rule = await this.commissionRuleRepository.findOne({
        where: { id: ruleId, isActive: true },
      });
      if (!rule) {
        throw new NotFoundException('قاعدة العمولة غير موجودة');
      }
    } else {
      // استخدام القاعدة الافتراضية
      rule = await this.commissionRuleRepository.findOne({
        where: { isActive: true, effectiveUntil: null },
        order: { effectiveFrom: 'DESC' },
      });
      if (!rule) {
        throw new NotFoundException('لا توجد قاعدة عمولة نشطة');
      }
    }

    // حساب العمولة الإجمالية
    const totalCommission = (salePrice * rule.baseRate) / 100;
    
    // حساب الضريبة
    const vatAmount = rule.vatEnabled 
      ? (totalCommission * rule.vatRate) / 100 
      : 0;

    // توزيع العمولة
    const listingAgentCommission = (totalCommission * rule.listingAgentShare) / 100;
    const sellingAgentCommission = (totalCommission * rule.sellingAgentShare) / 100;
    const platformCommission = totalCommission - listingAgentCommission - sellingAgentCommission;

    const result: CommissionCalculationResult = {
      totalCommission: this.roundToTwo(totalCommission),
      listingAgentCommission: this.roundToTwo(listingAgentCommission),
      sellingAgentCommission: this.roundToTwo(sellingAgentCommission),
      platformCommission: this.roundToTwo(platformCommission),
      vatAmount: this.roundToTwo(vatAmount),
      totalWithVat: this.roundToTwo(totalCommission + vatAmount),
      breakdown: {
        baseRate: rule.baseRate,
        listingAgentShare: rule.listingAgentShare,
        sellingAgentShare: rule.sellingAgentShare,
        platformShare: rule.platformShare,
        vatRate: rule.vatRate,
        vatEnabled: rule.vatEnabled,
      },
    };

    this.logger.log(`حساب العمولة: ${JSON.stringify(result)}`);
    return result;
  }

  // ============================================================
  // 2. إنشاء صفقة جديدة
  // ============================================================

  /**
   * إنشاء صفقة جديدة مع حساب العمولة
   * 
   * @param createDealDto - بيانات الصفقة
   * @param createdBy - معرف المستخدم المنشئ
   * @returns Deal
   */
  async createDeal(createDealDto: CreateDealDto, createdBy: string): Promise<Deal> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // التحقق من العقار
      const property = await this.propertyRepository.findOne({
        where: { id: createDealDto.propertyId },
        relations: ['listingAgent', 'owner'],
      });

      if (!property) {
        throw new NotFoundException('العقار غير موجود');
      }

      if (property.status === PropertyStatus.SOLD) {
        throw new BadRequestException('العقار مباع بالفعل');
      }

      // حساب العمولة
      const commissionCalc = await this.calculateCommission(
        createDealDto.salePrice,
        createDealDto.commissionRuleId,
      );

      // تحديد الوسطاء
      const listingAgentId = createDealDto.listingAgentId || property.listingAgent?.id;
      const sellingAgentId = createDealDto.sellingAgentId;

      // التحقق من وجود وسيط البيع
      if (!sellingAgentId) {
        throw new BadRequestException('يجب تحديد وسيط البيع');
      }

      // التحقق مما إذا كان الوسيط واحد (مدرج وبائع)
      const isSingleAgent = listingAgentId === sellingAgentId;

      // إنشاء الصفقة
      const deal = this.dealRepository.create({
        dealNumber: await this.generateDealNumber(),
        propertyId: createDealDto.propertyId,
        listingAgentId: isSingleAgent ? null : listingAgentId,
        sellingAgentId,
        sellerId: createDealDto.sellerId || property.ownerId,
        buyerId: createDealDto.buyerId,
        salePrice: createDealDto.salePrice,
        currency: createDealDto.currency || 'SAR',
        commissionRuleId: commissionCalc.breakdown.ruleId,
        totalCommission: commissionCalc.totalCommission,
        commissionRate: commissionCalc.breakdown.baseRate,
        listingAgentCommission: isSingleAgent 
          ? commissionCalc.listingAgentCommission + commissionCalc.sellingAgentCommission
          : commissionCalc.listingAgentCommission,
        sellingAgentCommission: isSingleAgent ? 0 : commissionCalc.sellingAgentCommission,
        platformCommission: commissionCalc.platformCommission,
        vatAmount: commissionCalc.vatAmount,
        dealDate: createDealDto.dealDate || new Date(),
        expectedPaymentDate: this.calculatePaymentDate(),
        status: DealStatus.PENDING,
        notes: createDealDto.notes,
        createdBy,
      });

      const savedDeal = await queryRunner.manager.save(deal);

      // إنشاء إشعار للإدارة
      this.eventEmitter.emit('deal.created', {
        dealId: savedDeal.id,
        dealNumber: savedDeal.dealNumber,
        salePrice: savedDeal.salePrice,
        totalCommission: savedDeal.totalCommission,
      });

      await queryRunner.commitTransaction();

      this.logger.log(`تم إنشاء الصفقة: ${savedDeal.dealNumber}`);
      return savedDeal;

    } catch (error) {
      await queryRunner.rollbackTransaction();
      this.logger.error(`خطأ في إنشاء الصفقة: ${error.message}`);
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  // ============================================================
  // 3. الموافقة على الصفقة وتوزيع العمولات
  // ============================================================

  /**
   * الموافقة على الصفقة وتوزيع العمولات تلقائياً
   * 
   * @param dealId - معرف الصفقة
   * @param updateDto - بيانات التحديث
   * @param approvedBy - معرف الموافق
   * @returns Deal
   */
  async approveDeal(
    dealId: string,
    updateDto: UpdateDealStatusDto,
    approvedBy: string,
  ): Promise<Deal> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const deal = await this.dealRepository.findOne({
        where: { id: dealId },
        relations: ['property', 'listingAgent', 'sellingAgent'],
      });

      if (!deal) {
        throw new NotFoundException('الصفقة غير موجودة');
      }

      if (deal.status !== DealStatus.PENDING) {
        throw new BadRequestException('الصفقة ليست في حالة الانتظار');
      }

      // تحديث حالة الصفقة
      deal.status = DealStatus.APPROVED;
      deal.approvedBy = approvedBy;
      deal.approvedAt = new Date();
      deal.notes = updateDto.notes || deal.notes;

      await queryRunner.manager.save(deal);

      // تحديث حالة العقار إلى مباع
      await queryRunner.manager.update(Property, deal.propertyId, {
        status: PropertyStatus.SOLD,
        updatedAt: new Date(),
      });

      // توزيع العمولات على المحافظ
      await this.distributeCommissions(deal, queryRunner);

      // إنشاء الإشعارات
      await this.createCommissionNotifications(deal);

      await queryRunner.commitTransaction();

      // إرسال الأحداث
      this.eventEmitter.emit('deal.approved', {
        dealId: deal.id,
        dealNumber: deal.dealNumber,
        listingAgentId: deal.listingAgentId,
        sellingAgentId: deal.sellingAgentId,
      });

      this.logger.log(`تمت الموافقة على الصفقة: ${deal.dealNumber}`);
      return deal;

    } catch (error) {
      await queryRunner.rollbackTransaction();
      this.logger.error(`خطأ في الموافقة على الصفقة: ${error.message}`);
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  // ============================================================
  // 4. توزيع العمولات على المحافظ
  // ============================================================

  /**
   * توزيع العمولات على محافظ الوسطاء
   * 
   * @param deal - الصفقة
   * @param queryRunner - QueryRunner للمعاملة
   */
  private async distributeCommissions(
    deal: Deal,
    queryRunner: any,
  ): Promise<void> {
    const distribution: CommissionDistribution[] = [];

    // وسيط الإدراج
    if (deal.listingAgentId && deal.listingAgentCommission > 0) {
      distribution.push({
        listingAgentId: deal.listingAgentId,
        listingAgentAmount: deal.listingAgentCommission,
        sellingAgentId: null,
        sellingAgentAmount: 0,
        platformAmount: 0,
        isSingleAgent: false,
      });
    }

    // وسيط البيع
    if (deal.sellingAgentId && deal.sellingAgentCommission > 0) {
      distribution.push({
        listingAgentId: null,
        listingAgentAmount: 0,
        sellingAgentId: deal.sellingAgentId,
        sellingAgentAmount: deal.sellingAgentCommission,
        platformAmount: 0,
        isSingleAgent: false,
      });
    }

    // إذا كان الوسيط واحد
    if (deal.listingAgentId === deal.sellingAgentId && deal.listingAgentCommission > 0) {
      distribution.length = 0;
      distribution.push({
        listingAgentId: deal.listingAgentId,
        listingAgentAmount: deal.listingAgentCommission,
        sellingAgentId: null,
        sellingAgentAmount: 0,
        platformAmount: 0,
        isSingleAgent: true,
      });
    }

    // معالجة كل توزيع
    for (const dist of distribution) {
      const agentId = dist.listingAgentId || dist.sellingAgentId;
      const amount = dist.listingAgentAmount || dist.sellingAgentAmount;
      const agentType = dist.listingAgentId ? 'listing' : 'selling';

      if (!agentId || amount <= 0) continue;

      // البحث عن المحفظة أو إنشاؤها
      let wallet = await queryRunner.manager.findOne(UserWallet, {
        where: { userId: agentId },
      });

      if (!wallet) {
        wallet = queryRunner.manager.create(UserWallet, {
          userId: agentId,
          availableBalance: 0,
          pendingBalance: 0,
          totalEarned: 0,
        });
        await queryRunner.manager.save(wallet);
      }

      // إنشاء معاملة المحفظة
      const transaction = queryRunner.manager.create(WalletTransaction, {
        walletId: wallet.id,
        type: TransactionType.COMMISSION,
        amount: amount,
        currency: deal.currency,
        dealId: deal.id,
        descriptionAr: `عمولة ${dist.isSingleAgent ? 'كاملة' : agentType === 'listing' ? 'إدراج' : 'بيع'} من صفقة ${deal.dealNumber}`,
        descriptionEn: `${dist.isSingleAgent ? 'Full' : agentType === 'listing' ? 'Listing' : 'Selling'} commission from deal ${deal.dealNumber}`,
        status: TransactionStatus.COMPLETED,
        processedAt: new Date(),
        metadata: {
          dealNumber: deal.dealNumber,
          propertyId: deal.propertyId,
          salePrice: deal.salePrice,
          commissionRate: deal.commissionRate,
          agentType,
          isSingleAgent: dist.isSingleAgent,
        },
      });

      await queryRunner.manager.save(transaction);

      // تحديث رصيد المحفظة
      await queryRunner.manager.increment(
        UserWallet,
        { id: wallet.id },
        'availableBalance',
        amount,
      );

      await queryRunner.manager.increment(
        UserWallet,
        { id: wallet.id },
        'totalEarned',
        amount,
      );

      this.logger.log(`تم توزيع عمولة ${amount} ${deal.currency} للمستخدم ${agentId}`);
    }
  }

  // ============================================================
  // 5. إنشاء الإشعارات
  // ============================================================

  /**
   * إنشاء إشعارات للوسطاء عند توزيع العمولات
   * 
   * @param deal - الصفقة
   */
  private async createCommissionNotifications(deal: Deal): Promise<void> {
    const notifications = [];

    // إشعار لوسيط الإدراج
    if (deal.listingAgentId && deal.listingAgentCommission > 0) {
      notifications.push({
        userId: deal.listingAgentId,
        type: 'commission',
        titleAr: 'تم إضافة عمولة جديدة',
        titleEn: 'New Commission Added',
        bodyAr: `تم إضافة عمولة بقيمة ${deal.listingAgentCommission} ${deal.currency} إلى محفظتك من صفقة ${deal.dealNumber}`,
        bodyEn: `Commission of ${deal.listingAgentCommission} ${deal.currency} added to your wallet from deal ${deal.dealNumber}`,
        entityType: 'deal',
        entityId: deal.id,
        channels: ['in_app', 'push', 'email'],
      });
    }

    // إشعار لوسيط البيع
    if (deal.sellingAgentId && deal.sellingAgentCommission > 0 && deal.sellingAgentId !== deal.listingAgentId) {
      notifications.push({
        userId: deal.sellingAgentId,
        type: 'commission',
        titleAr: 'تم إضافة عمولة جديدة',
        titleEn: 'New Commission Added',
        bodyAr: `تم إضافة عمولة بقيمة ${deal.sellingAgentCommission} ${deal.currency} إلى محفظتك من صفقة ${deal.dealNumber}`,
        bodyEn: `Commission of ${deal.sellingAgentCommission} ${deal.currency} added to your wallet from deal ${deal.dealNumber}`,
        entityType: 'deal',
        entityId: deal.id,
        channels: ['in_app', 'push', 'email'],
      });
    }

    // إرسال الأحداث لإنشاء الإشعارات
    for (const notification of notifications) {
      this.eventEmitter.emit('notification.create', notification);
    }
  }

  // ============================================================
  // 6. دوال مساعدة
  // ============================================================

  /**
   * توليد رقم صفقة فريد
   */
  private async generateDealNumber(): Promise<string> {
    const date = new Date();
    const year = date.getFullYear().toString().slice(-2);
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    
    // عدد الصفقات في هذا الشهر
    const count = await this.dealRepository.count({
      where: {
        createdAt: {
          $gte: new Date(date.getFullYear(), date.getMonth(), 1),
        } as any,
      },
    });

    return `DEAL-${year}${month}-${(count + 1).toString().padStart(5, '0')}`;
  }

  /**
   * حساب تاريخ الدفع المتوقع
   */
  private calculatePaymentDate(): Date {
    const date = new Date();
    date.setDate(date.getDate() + 14); // 14 يوم من الآن
    return date;
  }

  /**
   * تقريب الرقم إلى منزلتين عشريتين
   */
  private roundToTwo(num: number): number {
    return Math.round((num + Number.EPSILON) * 100) / 100;
  }

  // ============================================================
  // 7. استعلامات وإحصائيات
  // ============================================================

  /**
   * الحصول على إحصائيات العمولات للمستخدم
   */
  async getUserCommissionStats(userId: string): Promise<any> {
    const deals = await this.dealRepository.find({
      where: [
        { listingAgentId: userId, status: DealStatus.APPROVED },
        { sellingAgentId: userId, status: DealStatus.APPROVED },
      ],
    });

    const stats = {
      totalDeals: deals.length,
      totalCommission: 0,
      listingCommission: 0,
      sellingCommission: 0,
      thisMonth: 0,
      lastMonth: 0,
    };

    const now = new Date();
    const thisMonth = now.getMonth();
    const lastMonth = thisMonth === 0 ? 11 : thisMonth - 1;
    const thisYear = now.getFullYear();
    const lastMonthYear = thisMonth === 0 ? thisYear - 1 : thisYear;

    for (const deal of deals) {
      const isListing = deal.listingAgentId === userId;
      const isSelling = deal.sellingAgentId === userId;

      if (isListing) {
        stats.listingCommission += deal.listingAgentCommission;
        stats.totalCommission += deal.listingAgentCommission;
      }

      if (isSelling) {
        stats.sellingCommission += deal.sellingAgentCommission;
        stats.totalCommission += deal.sellingAgentCommission;
      }

      // حساب هذا الشهر
      const dealDate = new Date(deal.dealDate);
      if (dealDate.getMonth() === thisMonth && dealDate.getFullYear() === thisYear) {
        stats.thisMonth += isListing ? deal.listingAgentCommission : 0;
        stats.thisMonth += isSelling ? deal.sellingAgentCommission : 0;
      }

      // حساب الشهر الماضي
      if (dealDate.getMonth() === lastMonth && dealDate.getFullYear() === lastMonthYear) {
        stats.lastMonth += isListing ? deal.listingAgentCommission : 0;
        stats.lastMonth += isSelling ? deal.sellingAgentCommission : 0;
      }
    }

    return stats;
  }

  /**
   * الحصول على تقرير العمولات الشهري
   */
  async getMonthlyCommissionReport(year: number, month: number): Promise<any> {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);

    const deals = await this.dealRepository.find({
      where: {
        dealDate: {
          $gte: startDate,
          $lte: endDate,
        } as any,
        status: DealStatus.APPROVED,
      },
    });

    return {
      year,
      month,
      totalDeals: deals.length,
      totalSales: deals.reduce((sum, d) => sum + d.salePrice, 0),
      totalCommission: deals.reduce((sum, d) => sum + d.totalCommission, 0),
      totalVat: deals.reduce((sum, d) => sum + d.vatAmount, 0),
      listingAgentsCommission: deals.reduce((sum, d) => sum + d.listingAgentCommission, 0),
      sellingAgentsCommission: deals.reduce((sum, d) => sum + d.sellingAgentCommission, 0),
      platformCommission: deals.reduce((sum, d) => sum + d.platformCommission, 0),
    };
  }
}
