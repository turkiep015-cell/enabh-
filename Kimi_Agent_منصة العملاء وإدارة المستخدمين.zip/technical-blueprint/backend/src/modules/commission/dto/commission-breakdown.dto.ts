/**
 * Commission Breakdown DTO
 * Inabah Real Estate Platform
 */

import { ApiProperty } from '@nestjs/swagger';

export class CommissionBreakdownDto {
  @ApiProperty({ description: 'معرف قاعدة العمولة' })
  ruleId?: string;

  @ApiProperty({ description: 'نسبة العمولة الأساسية' })
  baseRate: number;

  @ApiProperty({ description: 'نصيب وسيط الإدراج' })
  listingAgentShare: number;

  @ApiProperty({ description: 'نصيب وسيط البيع' })
  sellingAgentShare: number;

  @ApiProperty({ description: 'نصيب المنصة' })
  platformShare: number;

  @ApiProperty({ description: 'نسبة الضريبة' })
  vatRate: number;

  @ApiProperty({ description: 'تفعيل الضريبة' })
  vatEnabled: boolean;
}
