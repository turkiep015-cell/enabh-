/**
 * Create Deal DTO
 * Inabah Real Estate Platform
 */

import { IsUUID, IsNumber, IsOptional, IsString, IsDateString, Min, IsEnum } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateDealDto {
  @ApiProperty({ description: 'معرف العقار' })
  @IsUUID()
  propertyId: string;

  @ApiProperty({ description: 'معرف وسيط الإدراج', required: false })
  @IsUUID()
  @IsOptional()
  listingAgentId?: string;

  @ApiProperty({ description: 'معرف وسيط البيع' })
  @IsUUID()
  sellingAgentId: string;

  @ApiProperty({ description: 'معرف البائع', required: false })
  @IsUUID()
  @IsOptional()
  sellerId?: string;

  @ApiProperty({ description: 'معرف المشتري' })
  @IsUUID()
  buyerId: string;

  @ApiProperty({ description: 'سعر البيع' })
  @IsNumber()
  @Min(0)
  salePrice: number;

  @ApiProperty({ description: 'العملة', default: 'SAR', required: false })
  @IsString()
  @IsOptional()
  currency?: string = 'SAR';

  @ApiProperty({ description: 'معرف قاعدة العمولة', required: false })
  @IsUUID()
  @IsOptional()
  commissionRuleId?: string;

  @ApiProperty({ description: 'تاريخ الصفقة', required: false })
  @IsDateString()
  @IsOptional()
  dealDate?: Date;

  @ApiProperty({ description: 'ملاحظات', required: false })
  @IsString()
  @IsOptional()
  notes?: string;
}
