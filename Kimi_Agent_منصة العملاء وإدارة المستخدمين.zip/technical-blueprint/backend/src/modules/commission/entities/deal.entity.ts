/**
 * Deal Entity - NestJS TypeORM
 * Inabah Real Estate Platform
 */

import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn, Index } from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Property } from '../../property/entities/property.entity';
import { Company } from '../../companies/entities/company.entity';
import { CommissionRule } from './commission-rule.entity';

export enum DealStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  PAID = 'paid',
  CANCELLED = 'cancelled',
  DISPUTED = 'disputed',
  REFUNDED = 'refunded',
}

@Entity('deals')
@Index(['propertyId'])
@Index(['listingAgentId'])
@Index(['sellingAgentId'])
@Index(['status'])
@Index(['dealDate'])
export class Deal {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 100, unique: true })
  dealNumber: string;

  // العقار
  @Column({ type: 'uuid' })
  propertyId: string;

  @ManyToOne(() => Property, property => property.deals)
  @JoinColumn({ name: 'propertyId' })
  property: Property;

  // الوسطاء
  @Column({ type: 'uuid', nullable: true })
  listingAgentId: string;

  @ManyToOne(() => User, user => user.listingDeals)
  @JoinColumn({ name: 'listingAgentId' })
  listingAgent: User;

  @Column({ type: 'uuid', nullable: true })
  sellingAgentId: string;

  @ManyToOne(() => User, user => user.sellingDeals)
  @JoinColumn({ name: 'sellingAgentId' })
  sellingAgent: User;

  // الشركات
  @Column({ type: 'uuid', nullable: true })
  listingCompanyId: string;

  @ManyToOne(() => Company)
  @JoinColumn({ name: 'listingCompanyId' })
  listingCompany: Company;

  @Column({ type: 'uuid', nullable: true })
  sellingCompanyId: string;

  @ManyToOne(() => Company)
  @JoinColumn({ name: 'sellingCompanyId' })
  sellingCompany: Company;

  // البائع والمشتري
  @Column({ type: 'uuid' })
  sellerId: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'sellerId' })
  seller: User;

  @Column({ type: 'uuid' })
  buyerId: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'buyerId' })
  buyer: User;

  // تفاصيل الصفقة
  @Column({ type: 'decimal', precision: 20, scale: 2 })
  salePrice: number;

  @Column({ type: 'varchar', length: 10, default: 'SAR' })
  currency: string;

  // العمولة
  @Column({ type: 'uuid', nullable: true })
  commissionRuleId: string;

  @ManyToOne(() => CommissionRule)
  @JoinColumn({ name: 'commissionRuleId' })
  commissionRule: CommissionRule;

  @Column({ type: 'decimal', precision: 20, scale: 2 })
  totalCommission: number;

  @Column({ type: 'decimal', precision: 5, scale: 2 })
  commissionRate: number;

  // توزيع العمولة
  @Column({ type: 'decimal', precision: 20, scale: 2, default: 0 })
  listingAgentCommission: number;

  @Column({ type: 'decimal', precision: 20, scale: 2, default: 0 })
  sellingAgentCommission: number;

  @Column({ type: 'decimal', precision: 20, scale: 2, default: 0 })
  platformCommission: number;

  @Column({ type: 'decimal', precision: 20, scale: 2, default: 0 })
  vatAmount: number;

  // الحالة
  @Column({
    type: 'enum',
    enum: DealStatus,
    default: DealStatus.PENDING,
  })
  status: DealStatus;

  // التواريخ
  @Column({ type: 'date' })
  dealDate: Date;

  @Column({ type: 'date', nullable: true })
  expectedPaymentDate: Date;

  @Column({ type: 'timestamptz', nullable: true })
  actualPaymentDate: Date;

  // المستندات
  @Column({ type: 'text', nullable: true })
  contractUrl: string;

  @Column({ type: 'jsonb', default: [] })
  documents: any[];

  // الملاحظات
  @Column({ type: 'text', nullable: true })
  notes: string;

  // الموافقة
  @Column({ type: 'uuid', nullable: true })
  approvedBy: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'approvedBy' })
  approver: User;

  @Column({ type: 'timestamptz', nullable: true })
  approvedAt: Date;

  // البيانات الوصفية
  @Column({ type: 'jsonb', default: {} })
  metadata: Record<string, any>;

  // التتبع
  @Column({ type: 'uuid', nullable: true })
  createdBy: string;

  @CreateDateColumn({ type: 'timestamptz' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz' })
  updatedAt: Date;
}
