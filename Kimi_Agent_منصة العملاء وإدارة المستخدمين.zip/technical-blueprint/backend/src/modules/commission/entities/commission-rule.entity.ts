/**
 * Commission Rule Entity - NestJS TypeORM
 * Inabah Real Estate Platform
 */

import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('commission_rules')
export class CommissionRule {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 255 })
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  // نسبة العمولة الأساسية
  @Column({ type: 'decimal', precision: 5, scale: 2, default: 2.5 })
  baseRate: number;

  // توزيع العمولة (بالنسبة المئوية من إجمالي العمولة)
  @Column({ type: 'decimal', precision: 5, scale: 2, default: 20.0 })
  listingAgentShare: number;

  @Column({ type: 'decimal', precision: 5, scale: 2, default: 20.0 })
  sellingAgentShare: number;

  @Column({ type: 'decimal', precision: 5, scale: 2, default: 60.0 })
  platformShare: number;

  // شروط خاصة
  @Column({ type: 'decimal', precision: 20, scale: 2, nullable: true })
  minPropertyValue: number;

  @Column({ type: 'decimal', precision: 20, scale: 2, nullable: true })
  maxPropertyValue: number;

  @Column({ type: 'jsonb', nullable: true })
  propertyTypes: string[];

  // الضريبة
  @Column({ type: 'boolean', default: true })
  vatEnabled: boolean;

  @Column({ type: 'decimal', precision: 5, scale: 2, default: 15.0 })
  vatRate: number;

  // الحالة
  @Column({ type: 'boolean', default: true })
  isActive: boolean;

  @Column({ type: 'date' })
  effectiveFrom: Date;

  @Column({ type: 'date', nullable: true })
  effectiveUntil: Date;

  @CreateDateColumn({ type: 'timestamptz' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz' })
  updatedAt: Date;
}
