# ربط الخريطة التفاعلية (Interactive Map Integration)
## منصة إنابة المستقبل العقارية

## نظرة عامة

نظام الخريطة التفاعلية مبني على **Mapbox GL JS** مع دمج **PostGIS** في قاعدة البيانات للتعامل مع البيانات الجغرافية.

## المكونات الرئيسية

### 1. هيكلية النظام

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              نظام الخريطة التفاعلية                                      │
└─────────────────────────────────────────────────────────────────────────────────────────┘

    ┌─────────────────┐         ┌─────────────────┐         ┌─────────────────┐
    │   Frontend      │         │    Backend      │         │   Database      │
    │  (Next.js)      │         │   (NestJS)      │         │  (PostgreSQL)   │
    │                 │         │                 │         │   + PostGIS     │
    └────────┬────────┘         └────────┬────────┘         └────────┬────────┘
             │                           │                           │
             │  1. طلب العقارات          │                           │
             │  GET /api/properties/map  │                           │
             │──────────────────────────>│                           │
             │                           │                           │
             │                           │  2. استعلام PostGIS       │
             │                           │  SELECT * FROM properties │
             │                           │  WHERE ST_DWithin(...)    │
             │                           │──────────────────────────>│
             │                           │                           │
             │                           │  3. نتائج جغرافية         │
             │                           │<──────────────────────────│
             │                           │                           │
             │  4. GeoJSON               │                           │
             │<──────────────────────────│                           │
             │                           │                           │
             ▼                           ▼                           ▼
    ┌─────────────────────────────────────────────────────────────────────────────────┐
    │                              Mapbox GL JS                                        │
    │  • عرض العقارات كـ Markers                                                      │
    │  • Clusters للتجميع                                                            │
    │  • Popup للتفاصيل                                                              │
    │  • Filtration حسب السعر والمساحة                                               │
    └─────────────────────────────────────────────────────────────────────────────────┘
```

### 2. إعداد Mapbox

```typescript
// lib/mapbox.ts
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';

// تعيين مفتاح API
mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN;

// الألوان المخصصة حسب هوية المنصة
export const MAP_COLORS = {
  primary: '#047857',      // Emerald 700
  secondary: '#10b981',    // Emerald 500
  accent: '#34d399',       // Emerald 400
  project: '#065f46',      // Dark Green
  private: '#6ee7b7',      // Light Green
  cluster: '#059669',      // Cluster color
  selected: '#f59e0b',     // Amber for selection
};

// تخصيص مظهر الخريطة
export const MAP_STYLE = {
  version: 8,
  name: 'Inabah Custom',
  sources: {
    'mapbox': {
      type: 'vector',
      url: 'mapbox://mapbox.mapbox-streets-v8',
    },
  },
  layers: [
    // طبقة الخلفية
    {
      id: 'background',
      type: 'background',
      paint: {
        'background-color': '#f8fafc',
      },
    },
    // تخصيص ألوان المباني
    {
      id: 'building',
      type: 'fill',
      source: 'mapbox',
      'source-layer': 'building',
      paint: {
        'fill-color': '#e2e8f0',
        'fill-opacity': 0.5,
      },
    },
    // تخصيص الطرق
    {
      id: 'road',
      type: 'line',
      source: 'mapbox',
      'source-layer': 'road',
      paint: {
        'line-color': '#cbd5e1',
        'line-width': 1,
      },
    },
  ],
};
```

### 3. مكون الخريطة الرئيسي

```typescript
// components/map/PropertyMap.tsx
'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import mapboxgl from 'mapbox-gl';
import { MAP_COLORS } from '@/lib/mapbox';
import { useMapFilters } from '@/hooks/useMapFilters';
import { Property } from '@/types/property';

interface PropertyMapProps {
  properties: Property[];
  onPropertySelect?: (property: Property) => void;
  selectedPropertyId?: string;
  filters: {
    minPrice?: number;
    maxPrice?: number;
    minArea?: number;
    maxArea?: number;
    propertyType?: string;
  };
}

export function PropertyMap({
  properties,
  onPropertySelect,
  selectedPropertyId,
  filters,
}: PropertyMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markersRef = useRef<mapboxgl.Marker[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // تهيئة الخريطة
  useEffect(() => {
    if (!mapContainer.current) return;

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/light-v11',
      center: [46.6753, 24.7136], // الرياض
      zoom: 11,
      language: 'ar',
    });

    // إضافة عناصر التحكم
    map.current.addControl(new mapboxgl.NavigationControl(), 'top-right');
    map.current.addControl(new mapboxgl.FullscreenControl(), 'top-right');
    map.current.addControl(
      new mapboxgl.GeolocateControl({
        positionOptions: { enableHighAccuracy: true },
        trackUserLocation: true,
      }),
      'top-right'
    );

    map.current.on('load', () => {
      setIsLoading(false);
      initializeClusters();
    });

    return () => {
      map.current?.remove();
    };
  }, []);

  // إعداد Clusters
  const initializeClusters = useCallback(() => {
    if (!map.current) return;

    const mapInstance = map.current;

    // إضافة مصدر البيانات
    mapInstance.addSource('properties', {
      type: 'geojson',
      data: {
        type: 'FeatureCollection',
        features: [],
      },
      cluster: true,
      clusterMaxZoom: 14,
      clusterRadius: 50,
    });

    // طبقة Clusters
    mapInstance.addLayer({
      id: 'clusters',
      type: 'circle',
      source: 'properties',
      filter: ['has', 'point_count'],
      paint: {
        'circle-color': [
          'step',
          ['get', 'point_count'],
          MAP_COLORS.cluster,
          10,
          MAP_COLORS.secondary,
          30,
          MAP_COLORS.primary,
        ],
        'circle-radius': [
          'step',
          ['get', 'point_count'],
          20,
          10,
          30,
          30,
          40,
        ],
        'circle-stroke-width': 2,
        'circle-stroke-color': '#fff',
      },
    });

    // طبقة عدد العقارات في Cluster
    mapInstance.addLayer({
      id: 'cluster-count',
      type: 'symbol',
      source: 'properties',
      filter: ['has', 'point_count'],
      layout: {
        'text-field': '{point_count_abbreviated}',
        'text-font': ['DIN Offc Pro Medium', 'Arial Unicode MS Bold'],
        'text-size': 14,
      },
      paint: {
        'text-color': '#fff',
      },
    });

    // طبقة العقارات غير المجمعة
    mapInstance.addLayer({
      id: 'unclustered-point',
      type: 'circle',
      source: 'properties',
      filter: ['!', ['has', 'point_count']],
      paint: {
        'circle-color': ['get', 'color'],
        'circle-radius': 10,
        'circle-stroke-width': 2,
        'circle-stroke-color': '#fff',
      },
    });

    // أحداث النقر
    mapInstance.on('click', 'clusters', (e) => {
      const features = mapInstance.queryRenderedFeatures(e.point, {
        layers: ['clusters'],
      });
      const clusterId = features[0].properties?.cluster_id;
      const source = mapInstance.getSource('properties') as mapboxgl.GeoJSONSource;
      
      source.getClusterExpansionZoom(clusterId, (err, zoom) => {
        if (err) return;
        mapInstance.easeTo({
          center: (features[0].geometry as any).coordinates,
          zoom: zoom,
        });
      });
    });

    // نقر على عقار
    mapInstance.on('click', 'unclustered-point', (e) => {
      const feature = e.features?.[0];
      if (feature) {
        const property = feature.properties as Property;
        onPropertySelect?.(property);
        
        // عرض Popup
        new mapboxgl.Popup()
          .setLngLat((feature.geometry as any).coordinates)
          .setHTML(createPopupHTML(property))
          .addTo(mapInstance);
      }
    });

    // تغيير المؤشر عند المرور
    mapInstance.on('mouseenter', 'clusters', () => {
      mapInstance.getCanvas().style.cursor = 'pointer';
    });
    mapInstance.on('mouseleave', 'clusters', () => {
      mapInstance.getCanvas().style.cursor = '';
    });
  }, [onPropertySelect]);

  // تحديث البيانات عند تغيير العقارات أو الفلاتر
  useEffect(() => {
    if (!map.current) return;

    const filteredProperties = filterProperties(properties, filters);
    const geojson = convertToGeoJSON(filteredProperties);

    const source = map.current.getSource('properties') as mapboxgl.GeoJSONSource;
    if (source) {
      source.setData(geojson);
    }
  }, [properties, filters]);

  // تحديث لون العقار المحدد
  useEffect(() => {
    if (!map.current || !selectedPropertyId) return;

    map.current.setPaintProperty('unclustered-point', 'circle-color', [
      'case',
      ['==', ['get', 'id'], selectedPropertyId],
      MAP_COLORS.selected,
      ['get', 'color'],
    ]);
  }, [selectedPropertyId]);

  return (
    <div className="relative w-full h-full">
      <div ref={mapContainer} className="w-full h-full rounded-lg" />
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-100 rounded-lg">
          <div className="animate-spin w-8 h-8 border-4 border-emerald-600 border-t-transparent rounded-full" />
        </div>
      )}
    </div>
  );
}

// تحويل العقارات إلى GeoJSON
function convertToGeoJSON(properties: Property[]): GeoJSON.FeatureCollection {
  return {
    type: 'FeatureCollection',
    features: properties.map((property) => ({
      type: 'Feature',
      geometry: {
        type: 'Point',
        coordinates: [property.longitude, property.latitude],
      },
      properties: {
        id: property.id,
        title: property.titleAr,
        price: property.price,
        type: property.propertyType,
        color: property.projectId ? MAP_COLORS.project : MAP_COLORS.private,
        image: property.mainImage,
      },
    })),
  };
}

// فلترة العقارات
function filterProperties(
  properties: Property[],
  filters: PropertyMapProps['filters']
): Property[] {
  return properties.filter((property) => {
    if (filters.minPrice && property.price < filters.minPrice) return false;
    if (filters.maxPrice && property.price > filters.maxPrice) return false;
    if (filters.minArea && property.area < filters.minArea) return false;
    if (filters.maxArea && property.area > filters.maxArea) return false;
    if (filters.propertyType && property.propertyType !== filters.propertyType) return false;
    return true;
  });
}

// إنشاء HTML للـ Popup
function createPopupHTML(property: Property): string {
  return `
    <div class="p-2 min-w-[200px]">
      <img src="${property.mainImage}" class="w-full h-24 object-cover rounded-lg mb-2" />
      <h3 class="font-bold text-sm">${property.titleAr}</h3>
      <p class="text-emerald-600 font-bold">${property.price.toLocaleString()} ريال</p>
      <p class="text-slate-500 text-xs">${property.area} م² • ${property.propertyType}</p>
    </div>
  `;
}
```

### 4. API للبحث الجغرافي

```typescript
// backend/src/modules/property/property.controller.ts

import { Controller, Get, Query } from '@nestjs/common';
import { PropertyService } from './property.service';
import { SearchPropertiesDto } from './dto/search-properties.dto';

@Controller('properties')
export class PropertyController {
  constructor(private readonly propertyService: PropertyService) {}

  /**
   * البحث عن العقارات على الخريطة
   */
  @Get('map')
  async searchOnMap(
    @Query() query: SearchPropertiesDto,
    @CurrentUser() user: User,
  ) {
    return this.propertyService.searchOnMap(query, user);
  }
}

// backend/src/modules/property/property.service.ts

import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Property } from './entities/property.entity';

@Injectable()
export class PropertyService {
  constructor(
    @InjectRepository(Property)
    private readonly propertyRepository: Repository<Property>,
  ) {}

  /**
   * البحث عن العقارات على الخريطة مع PostGIS
   */
  async searchOnMap(
    query: SearchPropertiesDto,
    user: User,
  ): Promise<Property[]> {
    const {
      latitude,
      longitude,
      radius = 5000, // 5km افتراضياً
      minPrice,
      maxPrice,
      minArea,
      maxArea,
      propertyType,
    } = query;

    // بناء الاستعلام
    const qb = this.propertyRepository.createQueryBuilder('property')
      .select([
        'property.id',
        'property.titleAr',
        'property.titleEn',
        'property.price',
        'property.area',
        'property.propertyType',
        'property.listingType',
        'property.status',
        'property.location',
        'ST_X(property.location) as longitude',
        'ST_Y(property.location) as latitude',
      ])
      .where('property.isApproved = :isApproved', { isApproved: true })
      .andWhere('property.status = :status', { status: 'available' });

    // البحث بالنطاق الجغرافي (PostGIS)
    if (latitude && longitude) {
      qb.andWhere(
        `ST_DWithin(
          property.location::geography,
          ST_SetSRID(ST_MakePoint(:longitude, :latitude), 4326)::geography,
          :radius
        )`,
        { latitude, longitude, radius },
      );
    }

    // فلترة السعر
    if (minPrice !== undefined) {
      qb.andWhere('property.price >= :minPrice', { minPrice });
    }
    if (maxPrice !== undefined) {
      qb.andWhere('property.price <= :maxPrice', { maxPrice });
    }

    // فلترة المساحة
    if (minArea !== undefined) {
      qb.andWhere('property.area >= :minArea', { minArea });
    }
    if (maxArea !== undefined) {
      qb.andWhere('property.area <= :maxArea', { maxArea });
    }

    // فلترة نوع العقار
    if (propertyType) {
      qb.andWhere('property.propertyType = :propertyType', { propertyType });
    }

    // تطبيق صلاحيات المستخدم
    this.applyUserPermissions(qb, user);

    // الترتيب حسب الأقرب
    if (latitude && longitude) {
      qb.addSelect(
        `ST_Distance(
          property.location::geography,
          ST_SetSRID(ST_MakePoint(:longitude, :latitude), 4326)::geography
        )`,
        'distance',
      )
        .orderBy('distance', 'ASC');
    }

    return qb.getMany();
  }

  /**
   * تطبيق صلاحيات المستخدم على الاستعلام
   */
  private applyUserPermissions(qb: any, user: User): void {
    switch (user.role) {
      case 'broker':
        // الوسيط يرى عقاراته + العقارات المتاحة
        qb.andWhere(
          '(property.ownerId = :userId OR property.listingAgentId = :userId)',
          { userId: user.id },
        );
        break;
      case 'developer':
        // المطور يرى فقط مشاريعه
        qb.andWhere('property.ownerId = :userId', { userId: user.id });
        break;
      case 'owner':
        // المالك يرى فقط عقاراته
        qb.andWhere('property.ownerId = :userId', { userId: user.id });
        break;
      case 'client':
        // العميل يرى العقارات المتاحة فقط
        // لا يوجد قيد إضافي
        break;
      case 'admin':
      case 'super_admin':
        // الإدارة ترى كل شيء
        break;
    }
  }
}
```

### 5. مكون الفلاتر

```typescript
// components/map/MapFilters.tsx
'use client';

import { useState } from 'react';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface MapFiltersProps {
  onFilterChange: (filters: FilterState) => void;
}

interface FilterState {
  minPrice: number;
  maxPrice: number;
  minArea: number;
  maxArea: number;
  propertyType: string;
}

export function MapFilters({ onFilterChange }: MapFiltersProps) {
  const [filters, setFilters] = useState<FilterState>({
    minPrice: 0,
    maxPrice: 5000000,
    minArea: 0,
    maxArea: 1000,
    propertyType: 'all',
  });

  const handleChange = (key: keyof FilterState, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-lg space-y-4">
      <h3 className="font-bold text-lg">فلترة النتائج</h3>

      {/* نوع العقار */}
      <div>
        <label className="text-sm text-slate-600">نوع العقار</label>
        <Select
          value={filters.propertyType}
          onValueChange={(value) => handleChange('propertyType', value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="اختر النوع" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">الكل</SelectItem>
            <SelectItem value="apartment">شقة</SelectItem>
            <SelectItem value="villa">فيلا</SelectItem>
            <SelectItem value="land">أرض</SelectItem>
            <SelectItem value="office">مكتب</SelectItem>
            <SelectItem value="shop">محل</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* نطاق السعر */}
      <div>
        <label className="text-sm text-slate-600">
          نطاق السعر: {filters.minPrice.toLocaleString()} - {filters.maxPrice.toLocaleString()} ريال
        </label>
        <Slider
          min={0}
          max={5000000}
          step={100000}
          value={[filters.minPrice, filters.maxPrice]}
          onValueChange={([min, max]) => {
            handleChange('minPrice', min);
            handleChange('maxPrice', max);
          }}
          className="mt-2"
        />
      </div>

      {/* نطاق المساحة */}
      <div>
        <label className="text-sm text-slate-600">
          نطاق المساحة: {filters.minArea} - {filters.maxArea} م²
        </label>
        <Slider
          min={0}
          max={1000}
          step={10}
          value={[filters.minArea, filters.maxArea]}
          onValueChange={([min, max]) => {
            handleChange('minArea', min);
            handleChange('maxArea', max);
          }}
          className="mt-2"
        />
      </div>

      <Button
        variant="outline"
        className="w-full"
        onClick={() => {
          setFilters({
            minPrice: 0,
            maxPrice: 5000000,
            minArea: 0,
            maxArea: 1000,
            propertyType: 'all',
          });
          onFilterChange({
            minPrice: 0,
            maxPrice: 5000000,
            minArea: 0,
            maxArea: 1000,
            propertyType: 'all',
          });
        }}
      >
        إعادة الضبط
      </Button>
    </div>
  );
}
```

### 6. صفحة الخريطة الكاملة

```typescript
// app/map/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { PropertyMap } from '@/components/map/PropertyMap';
import { MapFilters } from '@/components/map/MapFilters';
import { PropertyList } from '@/components/map/PropertyList';
import { useProperties } from '@/hooks/useProperties';
import { Property } from '@/types/property';

export default function MapPage() {
  const { properties, isLoading } = useProperties();
  const [filteredProperties, setFilteredProperties] = useState<Property[]>([]);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [filters, setFilters] = useState({
    minPrice: 0,
    maxPrice: 5000000,
    minArea: 0,
    maxArea: 1000,
    propertyType: 'all',
  });

  useEffect(() => {
    setFilteredProperties(properties);
  }, [properties]);

  const handleFilterChange = (newFilters: typeof filters) => {
    setFilters(newFilters);
    // الفلترة تتم داخل مكون الخريطة
  };

  return (
    <div className="h-screen flex">
      {/* Sidebar */}
      <div className="w-96 bg-white border-l overflow-y-auto">
        <div className="p-4 border-b">
          <h1 className="text-xl font-bold">البحث على الخريطة</h1>
          <p className="text-slate-500 text-sm">
            {filteredProperties.length} عقار متاح
          </p>
        </div>

        <div className="p-4">
          <MapFilters onFilterChange={handleFilterChange} />
        </div>

        <div className="border-t">
          <PropertyList
            properties={filteredProperties}
            selectedId={selectedProperty?.id}
            onSelect={setSelectedProperty}
          />
        </div>
      </div>

      {/* Map */}
      <div className="flex-1 relative">
        <PropertyMap
          properties={filteredProperties}
          onPropertySelect={setSelectedProperty}
          selectedPropertyId={selectedProperty?.id}
          filters={filters}
        />

        {/* Legend */}
        <div className="absolute bottom-4 left-4 bg-white p-3 rounded-lg shadow-lg">
          <h4 className="font-bold text-sm mb-2">دليل الألوان</h4>
          <div className="space-y-1 text-sm">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-800" />
              <span>مشاريع المطورين</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-300" />
              <span>عقارات خاصة</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-amber-500" />
              <span>محدد</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
```

## ملخص الميزات

| الميزة | الوصف |
|--------|-------|
| **Clusters** | تجميع العقارات القريبة عند التصغير |
| **فلترة فورية** | تغيير الفلاتر دون إعادة تحميل الصفحة |
| **Popup** | عرض تفاصيل العقار عند النقر |
| **PostGIS** | بحث جغرافي دقيق بالنطاق والمسافة |
| **ألوان مخصصة** | تمييز المشاريع عن العقارات الخاصة |
| **RTL** | دعم كامل للغة العربية |
